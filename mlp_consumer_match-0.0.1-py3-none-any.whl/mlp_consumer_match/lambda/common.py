import requests
import json
import yaml
import boto3
import base64
from datetime import datetime
from typing import Any, List, Dict, Optional


# Initialize boto3 S3 client
s3_client = boto3.client('s3')

def get_status_code(key: str) -> int:
    """
    Returns the status code based on the key.

    Args:
        key (str): The key to get the status code from.

    Returns:
        int: The status code.
    """
    status_codes_dict = {
        "success": 200,
        "temp_failure": 409,
        "perm_failure": 500
    }
    return status_codes_dict.get(key, 500)


def get_parent_dir_path(path: str, extension: str) -> str:
    """
    Returns the parent directory path of the given path.

    Args:
        path (str): The path to get the parent directory from.
        extension (str): The extension of the file to check.

    Returns:
        str: The parent directory path.
    """
    if path.endswith(extension):
        path = "/".join(path.split('/')[:-1])
        return path + '/' if not path.endswith('/') else path
    return path

def get_yaml_content(path: str) -> Optional[Dict[str, Any]]:
    """
    Returns the content of the given YAML file.

    Args:
        path (str): The path to the YAML file.

    Returns:
        dict[str, Any]: The content of the YAML file or None if not found.
    """
    try:
        bucket, key = path.replace('s3://', '').split('/', 1)
        response = s3_client.get_object(Bucket=bucket, Key=key)
        data = response['Body'].read().decode('utf-8')
        print(f"Read YAML Content for {path}")
        return yaml.safe_load(data)
    except Exception as e:
        print(f"Error reading YAML file: {str(e)}")
        return None

def get_files_param_in_yaml(yaml_content: Dict[str, Any]) -> List[str]:
    """
    Returns the list of source file paths from the given YAML content.

    Args:
        yaml_content (dict[str, Any]): The content of the YAML file.

    Returns:
        list[str]: The list of file paths.
    """
    source = yaml_content.get('source') or {}
    files = source.get('files', [])
    file_paths = []
    for file_obj in files:
        file = file_obj.get('file')
        file_path = file.get('path', '')
        file_paths.append(file_path if not file_path.endswith('.parquet') else get_parent_dir_path(file_path, '.parquet'))
    print(f"Source Files in YAML: {file_paths}")
    return file_paths

def get_link_type_in_yaml(yaml_content: dict[str, Any]):
    """
    Returns the link type from the given Train YAML content.

    Args:
        yaml_content (dict[str, Any]): The content of the YAML file.

    Returns:
        str | None: The link type.
    """
    link_type = yaml_content.get('link_type', None)
    return link_type

def do_files_exist_at_paths(paths: List[str]) -> bool:
    """
    Returns True if all files exist at the given paths.

    Args:
        paths (list[str]): The list of paths to check.

    Returns:
        bool: True if all files exist at the given paths, False otherwise.
    """
    for path in paths:
        try:
            if path.startswith("s3://"):
                bucket, prefix = path.replace('s3://', '').split('/', 1)
                response = s3_client.list_objects_v2(
                    Bucket=bucket,
                    Prefix=prefix
                )
                if not response.get('Contents'):
                    return False
            elif len(path.split('.')) == 4: # Delta Share Path
                print("Skipping Path Checking for Delta Share Paths")
                continue
        except Exception as e:
            print(f"Error checking path {path}: {str(e)}")
            return False
    print(f"Files exist at paths: {paths}")
    return True

def do_files_exists_in_dir(dir_path: str, files_to_check: List[str]) -> bool:
    """
    Returns True if all files exist in the given directory.

    Args:
        dir_path (str): The path to the directory.
        files_to_check (list[str]): The list of files to check.

    Returns:
        bool: True if all files exist in the given directory, False otherwise.
    """
    try:
        bucket, prefix = dir_path.replace('s3://', '').split('/', 1)
        response = s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix=prefix
        )
        files_found = []
        for obj in response.get('Contents', []):
            file_name = obj['Key'].split('/')[-1]
            if file_name in files_to_check:
                files_found.append(file_name)
        
        yamls_found = sorted(files_found) == sorted(files_to_check)
        files_not_found = [file for file in files_to_check if file not in files_found]
        
        if files_not_found:
            print(f"YAMLs {'found' if yamls_found else 'not found'} in {dir_path}:\nYAML needed: {files_to_check}\t|\tYAML not found: {files_not_found}")
        else:
            print(f"All required YAMLs {files_to_check} found in {dir_path}")
        return yamls_found
    except Exception as e:
        print(f"Error checking directory {dir_path}: {str(e)}")
        return False

def get_current_username(databricks_instance: str, databricks_token: str):
    """
    Returns the current username from Databricks.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.

    Returns:
        str | False: The current username or False if failed.
    """
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    response = requests.get(
        f"https://{databricks_instance}/api/2.0/preview/scim/v2/Me",
        headers=headers
    )
    if response.status_code == 200:
        user_info = response.json()
        username = user_info.get("userName")
        print(f"Retrieved username: {username}")
        return username
    else:
        print(f"Failed to retrieve user info: {response.status_code} - {response.text}")
        return False
    

def upload_file_to_dbfs(databricks_instance: str, databricks_token: str, dbfs_path: str, file_path: str):
    """
    Uploads a file to DBFS using the Databricks REST API.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        dbfs_path (str): The DBFS path where the file should be uploaded.
        file_path (str): The local path of the file to upload.

    Returns:
        None
    """
    base_url = f'https://{databricks_instance}/api/2.0/dbfs/'

    def dbfs_api(action, body):
        response = requests.post(
            base_url + action,
            headers={'Authorization': f'Bearer {databricks_token}', 'Content-Type': 'application/json'},
            json=body
        )
        response.raise_for_status()
        print(f"Response Content: {response.content}")
        return response.json()

    # Step 1: Create a handle for the file upload
    handle_response = dbfs_api('create', {'path': dbfs_path, 'overwrite': True})
    handle = handle_response['handle']

    # Step 2: Read the local file and upload in chunks
    with open(file_path, 'rb') as f:
        while True:
            block = f.read(1 << 20)  # Read in 1MB chunks
            if not block:
                break
            data = base64.b64encode(block).decode('utf-8')
            dbfs_api('add-block', {'handle': handle, 'data': data})

    # Step 3: Close the handle to finalize the upload
    dbfs_api('close', {'handle': handle})
    print(f"File '{file_path}' uploaded to DBFS at '{dbfs_path}'.")


def copy_yamls_to_local(databricks_instance: str, databricks_token: str, s3_path: str, local_folder: str) -> bool:
    """
    Copies the YAMLs from the S3 bucket to the local folder.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        s3_path (str): The path to the S3 bucket.
        local_folder (str): The local folder to copy the YAMLs to.

    Returns:
        bool: True if the YAMLs are successfully copied, False otherwise.
    """
    try:
        bucket, prefix = s3_path.replace('s3://', '').split('/', 1)
        response = s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix=prefix
        )

        for obj in response.get('Contents', []):
            if obj['Key'].endswith('.yaml'):
                file_name = obj['Key'].split('/')[-1]
                print("Transferring YAML: ", file_name)

                tmp_path = f'/tmp/{file_name}'
                s3_client.download_file(bucket, obj['Key'], tmp_path)

                local_file_path = f'{local_folder}{file_name}'
                upload_file_to_dbfs(databricks_instance, databricks_token, local_file_path, tmp_path)
                print(f"Copied {file_name} to local: {local_folder}")
        
        print("Finished copying all YAMLs to local")
        return True
    except Exception as e:
        print(f"Failed to copy YAMLs to local: {str(e)}")
        return False

def get_job_tasks(databricks_instance: str, databricks_token: str, job_id: str):
    """
    Returns the tasks from the given job.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_id (str): The job ID.

    Returns:
        list[dict[str, Any]] | False: The tasks or False if failed to fetch.
    """
    fetch_job_payload = {"job_id": job_id}
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    try:
        resp= requests.get(
            f'https://{databricks_instance}/api/2.1/jobs/get', 
            json=fetch_job_payload,
            headers=headers
        )
        response = json.loads(resp.content.decode("utf-8"))
        tasks = response.get("settings", {}).get("tasks", [])
        print(f"Fetched job tasks")
        return tasks
    except Exception as e:
        print(f"Failed to get job tasks: {str(e)}")
        return False

def modify_task_params(tasks: list[dict[str, Any]], task_name: str, override_params: dict[str, Any]):
    """
    Modifies the parameters of the given task.

    Args:
        tasks (list[dict[str, Any]]): The list of tasks.
        task_name (str): The name of the task to modify.
        override_params (dict[str, Any]): The parameters to override.

    Returns:
        list[dict[str, Any]] | False: The modified tasks or False if failed to modify.
    """
    try:
        for task in tasks:
            if task.get('task_key') == task_name:
                params = task.get('python_wheel_task', {}).get('parameters', {})
                for i in range(1, len(params)):
                    if params[i-1] == override_params['param_name']:
                        params[i] = override_params['param_value']
        print(f"Modified task params for task {task_name}: {params}")
        return tasks
    except Exception as e:
        print(f"Failed to modify task params: {str(e)}")
        return False

def add_or_override_hydra_parameter(tasks: list[dict[str, Any]], task_name: str, override_params: dict[str, Any]):
    """
    Adds or overrides a hydra parameter in the given task.

    Args:
        tasks (list[dict[str, Any]]): The list of tasks.
        task_name (str): The name of the task to modify.
        override_params (dict[str, Any]): The parameters to override.

    Returns:
        list[dict[str, Any]] | False: The modified tasks or False if failed to modify.
    """
    overrided = False
    for task in tasks:
      if task['task_key'] == task_name:
        paramaters = task.get('python_wheel_task', {}).get('parameters', [])
        for parameter_index in range(len(paramaters)):
          if override_params['param_key'] in paramaters[parameter_index]:
            paramaters[parameter_index] = f"++{override_params['param_key']}={override_params['param_value']}"
            overrided = True
        if not overrided:
          paramaters.append(f"++{override_params['param_key']}={override_params['param_value']}")
    return tasks

def update_job(databricks_instance: str, databricks_token: str, job_id: str, tasks: list[dict[str, Any]]):
    """
    Updates the given job with the new tasks.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_id (str): The job ID.
        tasks (list[dict[str, Any]]): The list of tasks.

    Returns:
        bool: True if the job is successfully updated, False otherwise.
    """
    update_job_payload = {
        "job_id": job_id,
        "new_settings": {
            "tasks": tasks
        }
    }
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    try:
        resp= requests.post(
            f'https://{databricks_instance}/api/2.1/jobs/update',
            json=update_job_payload,
            headers=headers
        )
        print(f"Job Updated: {resp.content}")
    except Exception as e:
        print(f"Failed to update job: {str(e)}")
        return False
    return True

def trigger_job(databricks_instance: str, databricks_token: str, job_id: str, timestamp: str = datetime.now().strftime("%Y%m%d%H%M%S")):
    """
    Triggers the given job.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_id (str): The job ID.
        timestamp (str): The timestamp to use for the job.

    Returns:
        bool: True if the job is successfully triggered, False otherwise.
    """
    job_payload = {
        "job_id": job_id,
        "idempotency_token": timestamp,
    }
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    try:
        resp = requests.post(
            f'https://{databricks_instance}/api/2.1/jobs/run-now',
            json=job_payload,
            headers=headers
        )
        print(f"Job Posted: {resp.content}")
    except Exception as e:
        print(f"Failed to trigger job: {str(e)}")
        return False
    return True


def override_job_params_and_run_job(databricks_instance: str, databricks_token: str, job_id: str, job_params: dict[str, Any]):
    """
    Overrides the parameters of the given job and runs it.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_id (str): The job ID.
        job_params (dict[str, Any]): The job parameters to override.

    Returns:
        bool: True if the job is successfully run, False otherwise.
    """
    job_payload = {
        "job_id": job_id,
        "job_parameters": job_params,
    }
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    try:
        resp = requests.post(
            f'https://{databricks_instance}/api/2.1/jobs/run-now',
            json=job_payload,
            headers=headers
        )
        print(f"Job Run Now: {resp.content}")
    except Exception as e:
        print(f"Failed to run job: {str(e)}")
        return False
    return True


def fetch_job_id_from_job_name(databricks_instance: str, databricks_token: str, job_name: str):
    """
    Fetches the job ID from the given job name.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_name (str): The job name.

    Returns:
        str | None: The job ID or None if not found.
    """
    headers = {
        "Authorization": f"Bearer {databricks_token}"
    }
    try:
        resp = requests.get(
            f'https://{databricks_instance}/api/2.1/jobs/list?name={job_name}',
            headers=headers
        )
        response = json.loads(resp.content.decode("utf-8"))
        jobs = response.get("jobs", [])
        if jobs[0]:
            job_id = jobs[0].get("job_id")
            print(f"Job ID found for job name: {job_name} -> {job_id}")
            return job_id
        print(f"Job ID not found for job name: {job_name}")
        return None
    except Exception as e:
        print(f"Failed to fetch job ID: {str(e)}")
        return None
    
