from common import (
    get_yaml_content,
    do_files_exists_in_dir,
    get_files_param_in_yaml,
    get_link_type_in_yaml,
    do_files_exist_at_paths,
    copy_yamls_to_local,
    get_job_tasks,
    add_or_override_hydra_parameter,
    update_job,
    get_status_code,
    override_job_params_and_run_job,
)
from database_api import DatabaseAPI

def trigger_training_workflow(
    databricks_instance: str, 
    databricks_token: str, 
    job_id: str, 
    s3_path: str, 
    local_folder: str, 
    match_config_id: str,
    hydra_override_params_list: list[dict[str, str]],
    database_api_url: str,
    idempotency_token: str,
    success_flag_filename: str = "SUCCESS.yaml",
):
    """
    Triggers the training workflow and updates the MatchConfig Record with the error message if any.
    """
    code, body = __train_workflow_trigger(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        job_id=job_id,
        s3_path=s3_path,
        local_folder=local_folder,
        hydra_override_params_list=hydra_override_params_list,
        idempotency_token=idempotency_token,
        success_flag_filename=success_flag_filename,
    )

    # Initialize DatabaseAPI
    database_api = DatabaseAPI(database_api_url)
    match_config_record = database_api.fetch(table_name="match_config", extension_id=match_config_id)
    workflow_type = match_config_record.get("workflow_type")
    print(f"workflow_type: {workflow_type}")
    
    if code == get_status_code("perm_failure"):
        print(f"Failed to trigger training workflow: {body}\nStatus Code: {code}")
        database_api.update_match_config(
            match_config_id=match_config_id,
            workflow_type=workflow_type,
            lambda_error=body,
        )
        print(f"Updated MatchConfig Record with lambda_error: {body}")
        return {
            "statusCode": code,
            "body": body,
            "triggered": False,
        }

    if code == get_status_code("temp_failure"):
        print(f"Failed to trigger training workflow: {body}\nStatus Code: {code}")
        print("No Database Record Updated")
        return {
            "statusCode": code,
            "body": body,
            "triggered": False,
        }
    
    database_api.update_match_config(
        match_config_id=match_config_id,
        workflow_type=workflow_type,
        lambda_error=None,
    )
    print("Updated MatchConfig Record with lambda_error with 'None'")

    return {
        "statusCode": code,
        "body": body,
        "triggered": True,
    }
    
    

def __train_workflow_trigger(
    databricks_instance: str, 
    databricks_token: str, 
    job_id: str, 
    s3_path: str, 
    local_folder: str, 
    hydra_override_params_list: list[dict[str, str]],
    idempotency_token: str,
    success_flag_filename: str,
):
    """
    Performs checks and triggers the training workflow.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        job_id (str): The job ID.
        s3_path (str): The path to the S3 directory.
        local_folder (str): The local folder path.
        hydra_override_params_list (list[dict[str, str]]): The list of hydra override parameters.
        idempotency_token (str): The idempotency token.
        success_flag_filename (str): The name of the success flag file.

    Returns:
        tuple: A tuple containing the status code, body, and triggered status.
    """
    # MatchAI Training Validation Details
    files_length_to_link_type_map = {1: "dedupe_only", 2: "link_only"}

    # Check if YAMLs exist in S3 Directory
    yaml_files = ['preprocess.yaml', 'train.yaml'] + [success_flag_filename]
    exists = do_files_exists_in_dir(s3_path, yaml_files)
    if not exists:
        body = f"One or more YAMLs from required {yaml_files} do not exist in {s3_path}\n\nPlease verify if the YAMLs are uploaded to the correct S3 path"
        return get_status_code("temp_failure"), body


    # Get YAML Content
    preprocess_yaml_content = get_yaml_content(f'{s3_path}preprocess.yaml')
    if not preprocess_yaml_content:
        body = "Failed to retrieve Preprocess YAML content"
        return get_status_code("perm_failure"), body


    train_yaml_content = get_yaml_content(f'{s3_path}train.yaml')
    if not train_yaml_content:
        body = "Failed to retrieve Train YAML content"
        return get_status_code("perm_failure"), body


    # Get link type from Train YAML
    link_type = get_link_type_in_yaml(train_yaml_content)
    if not link_type:
        body = "Failed to retrieve 'link_type' from Train YAML"
        return get_status_code("perm_failure"), body
      

    # Get source file paths from Preprocess YAML
    file_paths = get_files_param_in_yaml(preprocess_yaml_content)
    if not file_paths:
        body = "Failed to retrieve 'files' from Preprocess YAML"
        return get_status_code("perm_failure"), body
    

    # Check if link type is correct according to the number of source files
    if files_length_to_link_type_map.get(len(file_paths)) != link_type:
        body = f"`link_type` in Train YAML does not support the number of source files in Preprocess YAML"
        return get_status_code("perm_failure"), body
      

    # Check Existence of Source Files mentioned in Preprocess YAML at the specified S3 paths
    source_files_exist = do_files_exist_at_paths(file_paths)
    if not source_files_exist:
        body = f"One or more source files mentioned in the Preprocess YAML, do not exist at paths: {file_paths}\n\nPlease verify if the files are uploaded to the correct S3 path"
        return get_status_code("perm_failure"), body


    # Copy YAMLs to local
    copied = copy_yamls_to_local(
        databricks_instance,
        databricks_token,
        s3_path,
        local_folder
    )
    if not copied:
        body = "Failed to copy YAMLs from S3 to local folder in Databricks File System"
        return get_status_code("perm_failure"), body

    # Get job tasks
    tasks = get_job_tasks(databricks_instance, databricks_token, job_id)
    if not tasks:
        body = "Failed to get job tasks from Databricks Workflow"
        return get_status_code("perm_failure"), body

    # Modify job tasks
    task_keys = [task.get("task_key") for task in tasks]

    # Add or override hydra parameters
    for task_name in task_keys:
        for override_params in hydra_override_params_list:
            added_or_overriden = add_or_override_hydra_parameter(tasks, task_name, override_params)
            if not added_or_overriden:
                body = f"Failed to add or override hydra parameters with param_name: {override_params['param_name']} and param_value: {override_params['param_value']}"
                return get_status_code("perm_failure"), body

    # Update training job
    updated = update_job(databricks_instance, databricks_token, job_id, tasks)
    if not updated:
        body = "Failed to update training job"
        return get_status_code("perm_failure"), body

    # Override Job Parameters and Run Job
    job_override_param = {
        "conf_path": '/dbfs' + local_folder,
    }
    triggered = override_job_params_and_run_job(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        job_id=job_id,
        job_params=job_override_param,
    )
    if not triggered:
        body = "Failed to trigger training job"
        return get_status_code("perm_failure"), body

    # Successfully triggered training job
    return get_status_code("success"), "Training workflow triggered successfully"

