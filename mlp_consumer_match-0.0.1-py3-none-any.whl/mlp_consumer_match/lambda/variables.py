workspace_variables = {
    # Databricks Instance ("dbc-...cloud.databricks.com" without https://, without ending '/' after .com)
    "instance": "",

    # Databricks PAT of SP
    "token": "",
}