import requests

class DatabaseAPI:
    """
    Singleton class for database connection.
    """
    _instance = None

    def __new__(cls, host_url: str):
        """
        Returns the singleton instance of the DatabaseAPI class.

        Args:
            host_url (str): The host URL of the database.

        Returns:
            DatabaseAPI: The singleton instance of the DatabaseAPI class.
        """
        if cls._instance is None:
            inst = super().__new__(cls)
            inst.host_url = host_url
            cls._instance = inst
            cls._timeout = 30
        return cls._instance

    def table_to_api_endpoint_map(self, table_name: str, extension_id: str = "") -> str:
        """
        Maps table name to API endpoint.

        Args:
            table_name (str): The name of the table.
            extension_id (str, optional): The ID of the extension. Defaults to "".

        Returns:
            str: The API endpoint.
        """
        api_endpoint_map = {
            "match_config": f"api/match-config/{extension_id}",
            "match_run_detail": f"api/match-run-detail/{extension_id}",
            "match_run_event": f"api/match-run-event/{extension_id}",
        }
        tail = api_endpoint_map[table_name]
        return tail if tail.endswith("/") else tail + "/"

    def _create(self, table_name: str, record: dict) -> dict:
        """
        Creates a record in the database table.

        Args:
            table_name (str): The name of the table to create the record in.
            record (dict): The record to create.

        Returns:
            dict: The inserted record.
        """
        tail = self.table_to_api_endpoint_map(table_name)
        api_endpoint = f"{self.host_url}/{tail}"
        print(f"Performing [CREATE] at {api_endpoint}")
        response = requests.post(api_endpoint, json=record, timeout=self._timeout)
        if response.status_code != 201:
            print(f"Failed to create record: {response.text}")
            raise Exception(f"Failed to create record: {response.text}")
        return response.json()

    def _update(
        self,
        table_name: str,
        record: dict,
        extension_id: str,
        remove_end_slash: bool = False,
    ) -> dict:
        """
        Updates a record in the database table.

        Args:
            table_name (str): The name of the table to update the record in.
            record (dict): The record to update.
            extension_id (str): The ID of the extension.
            remove_end_slash (bool, optional): Whether to remove the end slash from the API endpoint. Defaults to False.

        Returns:
            dict: The updated record.
        """
        tail = self.table_to_api_endpoint_map(table_name, extension_id)
        tail = tail.rstrip("/") if remove_end_slash else tail
        api_endpoint = f"{self.host_url}/{tail}"
        print(f"Performing [UPDATE] at {api_endpoint}")
        response = requests.patch(api_endpoint, json=record, timeout=self._timeout)
        if response.status_code != 200:
            print(f"Failed to update record: {response.text}")
            raise Exception(f"Failed to update record: {response.text}")
        return response.json()

    def fetch(self, table_name: str, extension_id: str) -> dict:
        """
        Fetches record with extension_id from the database table.

        Args:
            table_name (str): The name of the table to fetch the record from.
            extension_id (str): The ID of the extension.

        Returns:
            dict: The record with the given extension_id.
        """
        tail = self.table_to_api_endpoint_map(table_name, extension_id)
        api_endpoint = f"{self.host_url}/{tail}"
        operation = "fetch" if extension_id else "fetch_all"
        print(f"Performing [{operation.upper()}] at {api_endpoint}")
        response = requests.get(api_endpoint, timeout=self._timeout)
        if response.status_code != 200:
            print(f"Failed to {operation} record: {response.text}")
            raise Exception(f"Failed to {operation} record: {response.text}")
        return response.json()

    def fetch_all(self, table_name: str) -> list[dict]:
        """
        Fetches all records from the database table.

        Args:
            table_name (str): The name of the table to fetch records from.

        Returns:
            list[dict]: All records from the table.
        """
        return self.fetch(table_name, "")

    def create_match_run_event(self, **kwargs) -> dict:
        """
        Creates a record in the match_run_event table.

        Args:
            record (dict): The record to create.

        Returns:
            dict: The inserted record.
        """
        match_run_event_record = {
            key: value for key, value in kwargs.items()
        }
        return self._create(table_name="match_run_event", record=match_run_event_record)
    
    def create_match_run_detail(self, **kwargs) -> dict:
        """
        Creates a record in the match_run_detail table.

        Args:
            record (dict): The record to create.

        Returns:
            dict: The inserted record.
        """
        match_run_detail_record = {
            key: value for key, value in kwargs.items()
        }
        return self._create(table_name="match_run_detail", record=match_run_detail_record)

    def update_match_run_event(self, remove_end_slash: bool = False, **kwargs) -> dict:
        """
        Updates a record in the match_run_event table.

        Args:
            record (dict): The record to update.

        Returns:
            dict: The updated record.
        """
        match_run_event_record = {
            key: value for key, value in kwargs.items() if key not in ["run_id", "task_id"]
        }
        return self._update(
            table_name="match_run_event",
            record=match_run_event_record,
            extension_id=f"update-by-ids/?run_id={kwargs.get('run_id')}&task_id={kwargs.get('task_id')}",
            remove_end_slash=remove_end_slash,
        )

    def update_match_run_detail(self, remove_end_slash: bool = False, **kwargs) -> dict:
        """
        Updates a record in the match_run_detail table.

        Args:
            record (dict): The record to update.

        Returns:
            dict: The updated record.
        """
        match_run_detail_record = {
            key: value for key, value in kwargs.items() if key != "run_id"
        }
        return self._update(
            table_name="match_run_detail",
            record=match_run_detail_record,
            extension_id=kwargs.get('run_id'),
            remove_end_slash=remove_end_slash,
        )
    
    def update_match_config(self, match_config_id: str, **kwargs) -> dict:
        """
        Updates a record in the match_config table.

        Args:
            record (dict): The record to update.

        Returns:
            dict: The updated record.
        """
        return self._update(
            table_name="match_config",
            record=kwargs,
            extension_id=match_config_id,
        )