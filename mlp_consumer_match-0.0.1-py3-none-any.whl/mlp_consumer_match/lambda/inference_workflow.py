from common import (
    get_yaml_content,
    get_files_param_in_yaml,
    do_files_exists_in_dir,
    do_files_exist_at_paths,
    copy_yamls_to_local,
    get_job_tasks,
    add_or_override_hydra_parameter,
    update_job,
    override_job_params_and_run_job,
    get_status_code,
)
from database_api import DatabaseAPI

def trigger_inference_workflow(
    databricks_instance: str, 
    databricks_token: str, 
    linkage_inference_job_id: str, 
    dedupe_inference_job_id: str, 
    parallel_inference_job_id: str, 
    parallel_cluster_job_id: str,
    s3_path: str,  
    local_folder: str, 
    match_config_id: str,
    hydra_override_params_list: list[dict[str, str]],
    database_api_url: str,
    idempotency_token: str,
    success_flag_filename: str = "SUCCESS.yaml",
):
    """
    Performs checks and triggers the inference workflow.
    """
    code, body = __inference_workflow_trigger(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        linkage_inference_job_id=linkage_inference_job_id,
        dedupe_inference_job_id=dedupe_inference_job_id,
        parallel_inference_job_id=parallel_inference_job_id,
        parallel_cluster_job_id=parallel_cluster_job_id,
        s3_path=s3_path,
        local_folder=local_folder,
        hydra_override_params_list=hydra_override_params_list,
        idempotency_token=idempotency_token,
        success_flag_filename=success_flag_filename,
    )

    # Initialize DatabaseAPI
    database_api = DatabaseAPI(database_api_url)
    match_config_record = database_api.fetch(table_name="match_config", extension_id=match_config_id)
    workflow_type = match_config_record.get("workflow_type")
    model_version = match_config_record.get("model_version")
    print(f"workflow_type: {workflow_type}")
    print(f"model_version: {model_version}")

    if code == get_status_code("perm_failure"):
        print(f"Failed to trigger inference workflow: {body}\nStatus Code: {code}")
        database_api.update_match_config(
            match_config_id=match_config_id,
            workflow_type=workflow_type,
            model_version=model_version,
            lambda_error=body,
        )
        print(f"Updated MatchConfig Record with lambda_error: {body}")
        return {
            "statusCode": code,
            "body": body,
            "triggered": False,
        }

    if code == get_status_code("temp_failure"):
        print(f"Failed to trigger inference workflow: {body}\nStatus Code: {code}")
        print(f"No Database Record Updated")
        return {
            "statusCode": code,
            "body": body,
            "triggered": False,
        }
    
    database_api.update_match_config(
        match_config_id=match_config_id,
        workflow_type=workflow_type,
        model_version=model_version,
        lambda_error=None,
    )
    print("Updated MatchConfig Record with lambda_error with 'None'")
    
    return {
        "statusCode": code,
        "body": body,
        "triggered": True,
    }
    


def __inference_workflow_trigger(
    databricks_instance: str, 
    databricks_token: str, 
    linkage_inference_job_id: str, 
    dedupe_inference_job_id: str, 
    parallel_inference_job_id: str, 
    parallel_cluster_job_id: str,
    s3_path: str,  
    local_folder: str, 
    hydra_override_params_list: list,
    idempotency_token: str,
    success_flag_filename: str,
):
    """
    Performs checks and triggers the inference workflow.

    Args:
        databricks_instance (str): The Databricks instance.
        databricks_token (str): The Databricks token.
        linkage_inference_job_id (str): The linkage inference job ID.
        dedupe_inference_job_id (str): The dedupe inference job ID.
        parallel_inference_job_id (str): The parallel inference job ID.
        parallel_cluster_job_id (str): The parallel cluster job ID.
        s3_path (str): The path to the S3 directory.
        local_folder (str): The local folder path.
        hydra_override_params_list (list): The list of hydra override parameters.
        idempotency_token (str): The idempotency token.
        success_flag_filename (str): The name of the success flag file.

    Returns:
        tuple: A tuple containing the status code, body, and triggered status.
    """

    # Check if YAMLs exist in S3 Directory
    yaml_files = ['preprocess.yaml', 'inference.yaml'] + [success_flag_filename]
    exists = do_files_exists_in_dir(s3_path, yaml_files)
    if not exists:
        body = f"One or more YAMLs from required {yaml_files} do not exist in {s3_path}\n\nPlease verify if the YAMLs are uploaded to the correct S3 path"
        return get_status_code("temp_failure"), body

    # Get YAML Content
    preprocess_yaml_content = get_yaml_content(f'{s3_path}preprocess.yaml')
    if not preprocess_yaml_content:
        body = "Failed to retrieve Preprocess YAML content"
        return get_status_code("perm_failure"), body

    inference_yaml_content = get_yaml_content(f'{s3_path}inference.yaml')
    if not inference_yaml_content:
        body = "Failed to retrieve Inference YAML content"
        return get_status_code("perm_failure"), body

    # Get source file paths from Preprocess YAML
    file_paths = get_files_param_in_yaml(preprocess_yaml_content)
    if not file_paths:
        body = "Failed to retrieve source file paths from Preprocess YAML"
        return get_status_code("perm_failure"), body

    # Check if its dedupe type problem
    if len(file_paths) == 1:
        print("MatchAI Problem Type is most likely dedupe, looking for cluster.yaml")
        cluster_yaml_exists = do_files_exists_in_dir(s3_path, ['cluster.yaml'])
        if not cluster_yaml_exists:
            body = f"Cluster YAML does not exist in {s3_path}"
            return get_status_code("temp_failure"), body

    # Check if source files exist
    files_exist = do_files_exist_at_paths(file_paths)
    if not files_exist:
        body = f"One or more source files do not exist at paths: {file_paths}"
        return get_status_code("perm_failure"), body

    # Copy YAMLs to local
    copied = copy_yamls_to_local(
        databricks_instance,
        databricks_token,
        s3_path,
        local_folder
    )
    if not copied:
        body = "Failed to copy YAMLs to local"
        return get_status_code("perm_failure"), body

    # Get job ID based on number of source files
    job_id = linkage_inference_job_id if len(file_paths) > 1 else dedupe_inference_job_id

    # Get job tasks
    tasks = get_job_tasks(databricks_instance, databricks_token, job_id)
    if not tasks:
        body = "Failed to get job tasks"
        return get_status_code("perm_failure"), body

    # Modify job tasks
    task_keys = [task.get("task_key") for task in tasks]

    # Add or override hydra parameters
    for task_name in task_keys:
        for override_params in hydra_override_params_list:
            added_or_overriden = add_or_override_hydra_parameter(tasks, task_name, override_params)
            if not added_or_overriden:
                body = "Failed to add or override hydra parameters"
                return get_status_code("perm_failure"), body

    # Update inference job
    updated = update_job(databricks_instance, databricks_token, job_id, tasks)
    if not updated:
        body = "Failed to update inference job"
        return get_status_code("perm_failure"), body

    # Override Job Parameters and Run Job
    job_override_param = {
        "conf_path": '/dbfs' + local_folder,
    }
    triggered = override_job_params_and_run_job(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        job_id=job_id,
        job_params=job_override_param,
    )
    if not triggered:
        body = "Failed to trigger inference job"
        return get_status_code("perm_failure"), body

    # Successfully triggered inference workflow
    return get_status_code("success"), "Inference workflow triggered successfully"
