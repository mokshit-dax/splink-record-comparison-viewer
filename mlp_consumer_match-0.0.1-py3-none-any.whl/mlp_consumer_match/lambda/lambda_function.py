import datetime as dt
from common import (
    get_current_username,
    get_parent_dir_path,
    fetch_job_id_from_job_name,
    get_status_code,
)
from training_workflow import trigger_training_workflow
from inference_workflow import trigger_inference_workflow
from profiling_workflow import trigger_profiling_workflow
from variables import workspace_variables


def lambda_handler(event, context):
# def lambda_handler():
    """
    This function is a lambda function that is triggered when a new file is added to an S3 bucket.
    
    Returns:
        dict: A dictionary containing the status code and body of the response.
    """

    # Event Details
    s3_bucket = "s3://" + str(event.get('Records')[0].get('s3').get('bucket').get('name'))
    # s3_bucket = "s3://ds-airflow-production"
    file_path = s3_bucket + '/' + str(event.get('Records')[0].get('s3').get('object').get('key'))
    # file_path = 's3://ds-airflow-production/MatchAI/generic_match/YAMLs/'

    # Databricks Details
    databricks_token = workspace_variables.get('token')
    databricks_instance = workspace_variables.get('instance')
    idempotency_token = dt.datetime.now().isoformat()

    # Job Details
    train_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_training_job")
    linkage_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_linkage_inference_job")
    dedupe_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_dedupe_inference_job")
    parallel_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_parallel_inference_job")
    parallel_cluster_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_parallel_cluster_job")
    profiling_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_profiling_job")

    # DatabaseAPI URL
    database_api_url = "http://match-ai-dev.data-axle.com"

    # Hydra Override Params
    hydra_override_params_list = [
        # {"param_key": "database_api_url", "param_value": database_api_url},
    ]

    # YAML Copy Details
    s3_path = get_parent_dir_path(file_path, '.yaml')
    print(f"S3 Path: {s3_path}")

    # Check if it was triggered by github integration test
    suffix = ""
    if "github_integration_test" in s3_path:
        print("Triggered staging wokflow, overriding databricks details")

        # Override Databricks Details
        databricks_token = ""
        databricks_instance = ""

        # Override Job Details
        train_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_training_job")
        linkage_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_linkage_inference_job")
        dedupe_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_dedupe_inference_job")
        parallel_inference_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_parallel_inference_job")
        parallel_cluster_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_parallel_cluster_job")
        profiling_job_id = fetch_job_id_from_job_name(databricks_instance, databricks_token, "matchai_profiling_job")

        # Hydra Override Params
        hydra_override_params_list = [
            # {"param_key": "database_api_url", "param_value": database_api_url},
        ]

        example = s3_path.split("github_integration_test/")[1].split("/")[0]
        model_name = s3_path.split("github_integration_test/")[1].split("/")[1]
        print(f"Example: {example}")
        print(f"Model Name: {model_name}")
        if f"github_integration_test/{example}/{model_name}/train" in s3_path:
            print("Github integration test has triggered a training workflow")
            suffix = f"github_integration_test/{example}/{model_name}/train/"
        elif f"github_integration_test/{example}/{model_name}/inference" in s3_path:
            print("Github integration test has triggered a inference workflow")
            suffix = f"github_integration_test/{example}/{model_name}/inference/"
        elif f"github_integration_test/{example}/{model_name}/profiling" in s3_path:
            print("Github integration test has triggered a profiling workflow")
            suffix = f"github_integration_test/{example}/{model_name}/profiling/"
        
    # Get current username
    username = get_current_username(databricks_instance, databricks_token)
    if not username:
        return {
            "statusCode": 500, 
            "body": "Failed to retrieve username",
        }

    # Get Timestamp from S3 Path
    timestamp = s3_path.split("/")[-3]
    if len(timestamp.split("_")) < 3:
        return {
            "statusCode": get_status_code("perm_failure"), 
            "body": f"Invalid timestamp format in the S3 path: {s3_path}",
        }
    date_partition = "_".join(timestamp.split("_")[0:3])
    print(f"Timestamp: {timestamp}")
    print(f"Date Partition: {date_partition}")
    hydra_override_params_list.append({"param_key": "date_partition", "param_value": f"'{date_partition}'"})

    # Get MatchConfigID from S3 Path
    match_config_id = s3_path.split("/")[-2]
    if not match_config_id.isnumeric():
        return {
            "statusCode": get_status_code("perm_failure"),
            "body": f"Invalid match_config_id in the S3 path: {s3_path}",
        }
    print(f"match_config_id: {match_config_id}")    
    hydra_override_params_list.append({"param_key": "match_config_id", "param_value": f"'{match_config_id}'"})
        
    local_folder = f"/FileStore/GenericMatch/{username}/yaml_files/{suffix}{timestamp}/"
    print(f"Local Path: {local_folder}")

    # Trigger Training Workflow if conditions are met
    triggered_train = trigger_training_workflow(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        job_id=train_job_id,
        s3_path=s3_path,
        local_folder=local_folder + f'train/{match_config_id}/',
        match_config_id=match_config_id,
        hydra_override_params_list=hydra_override_params_list,
        database_api_url=database_api_url,
        idempotency_token=idempotency_token,
    )
    if triggered_train["triggered"]:
        print("Training workflow triggered successfully")
        return {
            "statusCode": 200, 
            "body": "Training workflow triggered successfully",
        }


    # Trigger Inference Workflow if conditions are met
    triggered_inference = trigger_inference_workflow(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        linkage_inference_job_id=linkage_inference_job_id,
        dedupe_inference_job_id=dedupe_inference_job_id,
        parallel_inference_job_id=parallel_inference_job_id,
        parallel_cluster_job_id=parallel_cluster_job_id,
        s3_path=s3_path,
        local_folder=local_folder + f'inference/{match_config_id}/',
        match_config_id=match_config_id,
        hydra_override_params_list=hydra_override_params_list,
        database_api_url=database_api_url,
        idempotency_token=idempotency_token,
    )
    if triggered_inference["triggered"]:
        print("Inference workflow triggered successfully")
        return {
            "statusCode": 200, 
            "body": "Inference workflow triggered successfully",
        }

    # Trigger Profiling Workflow if conditions are met
    triggered_profiling = trigger_profiling_workflow(
        databricks_instance=databricks_instance,
        databricks_token=databricks_token,
        job_id=profiling_job_id,
        s3_path=s3_path,
        local_folder=local_folder + f'profiling/{match_config_id}/',
        match_config_id=match_config_id,
        hydra_override_params_list=hydra_override_params_list,
        database_api_url=database_api_url,
        idempotency_token=idempotency_token,
    )
    if triggered_profiling["triggered"]:
        print("Profiling workflow triggered successfully")
        return {
            "statusCode": 200, 
            "body": "Profiling workflow triggered successfully",
        }