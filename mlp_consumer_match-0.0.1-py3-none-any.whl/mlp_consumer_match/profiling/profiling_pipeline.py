import datetime as dt
import json
import time
from mlp_consumer_match.conf.config_loader import ConfigLoader
from pyspark.sql import DataFrame
from splink import SparkAPI

from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.save_json import save_json_file
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.profiling.profilers.completeness_chart_profiler import CompletenessChartProfiler
from mlp_consumer_match.profiling.profilers.column_profiler import ColumnProfiler
from mlp_consumer_match.profiling.profilers.generate_insights import GenerateInsights
from mlp_consumer_match.utils.metrics.profiling_metrics import ProfilingMetrics
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger


logger = get_logger(name="profiling_pipeline")

class ProfilingPipeline:
    """
    Pipeline for executing various data profiling functions.
    
    This class manages the execution of different profiling operations on a DataFrame,
    such as completeness charts and column profiles. It also generates insights using a LLM model.
    """
    
    # Registry of available profilers
    PROFILING_FUNCTIONS = {
        "completeness_chart": CompletenessChartProfiler(),
        "profile_columns": ColumnProfiler(),
    }
    
    def __init__(self, fn_list: list, spark_api: SparkAPI, save_path: str, model_name: str, run_id: str, api_key: str, llm_model: str, date_partition: str, metrics: ProfilingMetrics = None, chart_logger: ChartLogger = ChartLogger()):
        """
        Initialize ProfilingPipeline.
        
        Args:
            fn_list (list): List of profiling functions to be applied.
            spark_api (SparkAPI): Splink's SparkAPI instance for profiling.
            save_path (str): Base path for saving profiling results.
            model_name (str): Name of the model being profiled.
            run_id (str): Unique identifier for this profiling run.
            api_key (str): API key for accessing external services.
            llm_model (str): Language model to be used for generating insights.
            date_partition (str): Date partition for the profiling results.
            metrics (ProfilingMetrics, optional): Metrics tracker for profiling performance.
            chart_logger (ChartLogger, optional): Chart logger for logging profiling results.
        """
        self.fn_list = fn_list
        self.spark_api = spark_api
        self.save_path = save_path
        self.model_name = model_name
        self.run_id = run_id
        self.generate_insights = GenerateInsights(api_key=api_key, model=llm_model)
        self.date_partition = date_partition
        self.base_path = ConfigLoader().get_profiling_base_path()
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(self.base_path)
        self.metrics = metrics
        self.chart_logger = chart_logger

    def get_profiler(self, function_name: str):
        """
        Retrieve profiler instance by name.
        
        Args:
            function_name (str): Name of the profiling function to retrieve
            
        Returns:
            Profiler: Instance of the requested profiler.
        
        Raises:
            ValueError: If the profiling function is not found.
        """
    
        profiler = self.PROFILING_FUNCTIONS.get(function_name)
        if not profiler:
            logger.error(f"Profiling function '{function_name}' not found")
            raise
        return profiler
    
    def profiling_parser(self, function_list: list) -> dict:
        """
        Parse profiling configuration from function list.
        
        Args:
            function_list (list): List of function configurations.
            
        Returns:
            dict: Parsed profiling configuration with parameters.
        """
        profiling_config = {}
        for item in function_list:
            fn_name = item["function"]
            params_list = item.get("params", [])
            params = {list(param.keys())[0]: list(param.values())[0] for param in params_list}
            profiling_config[fn_name] = params    
        return profiling_config
    
    def list_files(self, output_dir: str, extension=".json"):
        """
        Lists files in both DBFS and local file systems, handling /FileStore/ paths.
        Includes error handling for missing directories and permission issues.
        
        Args:
            output_dir (str): Directory to list files from.
            extension (str): File extension to filter by (default is ".json").
        
        Returns:
            list: List of file paths with the specified extension.
        """
        try:
            # List all files with the given extension
            return [f.path for f in self.fs.ls(output_dir, extension)]
        
        except PermissionError:
            logger.error(f"Error: Permission denied for directory: {output_dir}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error while listing files in {output_dir}: {e}")
            raise
    
    def transform(self, df: DataFrame, file_name: str) -> int:
        """
        Execute profiling transformations on the input DataFrame.
        
        Args:
            df (DataFrame): Input DataFrame to profile.
            file_name (str): Name of the file being processed.
            
        Returns:
            int: 1 if successful.
            
        Raises:
            Exception: If any profiling operation fails.
        """
        profiling_config = self.profiling_parser(self.fn_list)
        logger.info(f"Executing profiling functions: {profiling_config}")

        # Construct the profiling_output_path from the base path 
        profiling_output_path = ConfigLoader().get_profiling_output_path(file_name)
        logger.info(f"Using base path: {profiling_output_path}")

        for fn_name, fn_params in profiling_config.items():
            logger.info(f"Applying profiling function: {fn_name} with params: {fn_params}")

            try:
                start_time = time.time()
                
                profiler_class = self.get_profiler(fn_name)

                if profiler_class is None:
                    logger.error(f"No profiler found for function: {fn_name}")
                    raise
                
                # Execute profiling with provided parameters
                profiler_class.profiling(
                    df=df,
                    spark_api=self.spark_api,
                    base_path=profiling_output_path,
                    chart_logger=self.chart_logger,
                    **fn_params
                )
                
                end_time = time.time()
                execution_time = end_time - start_time
                
                if self.metrics:
                    self.metrics.track_profiling_function(
                        fn_name,
                        execution_time
                    )
                
                logger.info(f"Successfully completed profiling for: {fn_name}")
                
            except Exception as e:
                logger.error(f"Error during profiling for {fn_name}: {str(e)}")
                raise

    def generate_llm_insights(self, file_name: str):
        """
        Reads saved profiling JSONs and generates insights using a language model (LLM).
        
        Args:
            file_name (str): Name of the file for which insights are generated.
        
        Returns:
            None
        """
        start_time = time.time()
        
        profiling_insights = {}
        profiling_dir = ConfigLoader().get_profiling_dir_path(file_name)
        insights_output_path = ConfigLoader().get_profiling_insights_path(file_name)
        
        profiling_files = self.list_files(profiling_dir, ".json")
        logger.info(f"Profiling files: {profiling_files}")

        for file in profiling_files:
            profiling_data = self.fs.read(file)

            column_name = file.split('/')[-1].replace("_profile.json","")
            profiling_insights[column_name] = self.generate_insights.generate_insights(column_name, profiling_data)

        logger.info(f"Profiling insights: {profiling_insights}")
        
        save_json_file(data=json.dumps(profiling_insights), path=insights_output_path)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # if self.metrics:
        #     self.metrics.track_insight_generation(
        #         dataset_name=file_name,
        #         column_count=len(profiling_files),
        #         execution_time_seconds=execution_time
        #     )
        
        logger.info(f"LLM insights for file {file_name} saved at {insights_output_path}")