class Profiler:
    """
    Abstract base class for profiling functions on dataframes.

    This class serves as a template for all profiling functions. 
    It defines a `profiling` method that must be implemented by subclasses.

    Methods:
        profiling(df, **kwargs): Applies profiling functions to the given dataframe.
    """
 
    def __init__(self):
        """
        Initializes the Profiler class.

        Since this is a base class, no attributes are defined here.
        Subclasses may extend this constructor if needed.
        """
        pass
    
    def profiling(self, df, **kwargs):
        """
        Applies profiling functions to the given dataframe.

        This method must be implemented by subclasses to define specific profiling functions.

        Args:
            df: The dataframe to be profiled.
            **kwargs: Additional arguments required for the specific profiling function.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        raise NotImplementedError("Not Implemented")


    