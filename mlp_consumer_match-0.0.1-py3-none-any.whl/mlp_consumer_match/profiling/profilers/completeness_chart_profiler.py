from splink.exploratory import completeness_chart
from mlp_consumer_match.profiling.profiler import Profiler
from mlp_consumer_match.utils.save_json import save_json_file
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger

logger = get_logger(name="completeness_chart_profiler")


class CompletenessChartProfiler(Profiler):
    """
    A profiling class that generates the completness chart showing the percentage of fill rate for the columns.


    This class extends the `Profiler` base class and implements the `profiling` method 
    to generate the chart.

    Methods:
        profiling(df, save_path)
    """

    def __init__(self):
        """
        Initializes the CompletenessChartProfiler class.

        This class does not require additional initialization parameters, 
        but it calls the parent `Profiler` constructor.
        """
        super().__init__()

    def profiling(self, df, spark_api, base_path: str, chart_logger: ChartLogger):
        """
        Generate completeness charts for all columns in the dataframe.

        Args:
            df: The input DataFrame
            spark_api: Splink's SparkAPI instance
            base_path: Pre-constructed base path (format: {save_path}/{model_name}/{run_id}/profiling/{file_name})
            chart_logger: Chart logger for logging profiling results
        """
        logger.info(f"Generating completeness chart for {len(df.columns)} columns")

        profile_data = completeness_chart(
            table_or_tables = df,
            cols = df.columns,
            db_api = spark_api
        )

        # Log charts
        chart_logger.log_chart_dict(chart=profile_data.to_dict(), chart_name="completeness_chart")
        logger.info("Logged completeness chart JSON")

        # Upload to Unity Catalog
        profile_data.save(f"{chart_logger.get_uc_destination_path()}/completeness_chart.html")
        chart_logger.log_uc_chart_path("completeness_chart.html")
        logger.info("Completeness chart saved to Unity Catalog")

        # Prepare the file path
        file_path = f"{base_path}/completeness/completeness_chart.json"

        # Save the chart data to DBFS
        save_json_file(data=profile_data.to_json(), path=file_path)

        logger.info("Completeness chart generated successfully")
