from splink.exploratory import profile_columns
from pyspark.sql import DataFrame
from splink import SparkAPI

from mlp_consumer_match.profiling.profiler import Profiler
from mlp_consumer_match.utils.save_json import save_json_file
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger

logger = get_logger(name="column_profiler")

class ColumnProfiler(Profiler):
    """
    A profiling class that generates detailed column profiles using Splink's profile_columns function.

    This class extends the `Profiler` base class and implements the `profiling` method 
    to generate profiles for each column, including top and bottom value distributions.

    Methods:
        profiling(df, spark_api, run_id, save_path, top_n=10, bottom_n=10)
    """

    def __init__(self):
        """
        Initializes the ColumnProfiler class.
        """
        super().__init__()

    def profiling(self, df: DataFrame, spark_api: SparkAPI, base_path: str, chart_logger: ChartLogger,
                    top_n: int = 10, bottom_n: int = 10) -> None:
            """
            Generate detailed profiles for each column in the dataframe.

            Args:
                df: The input DataFrame to profile
                spark_api: Splink's SparkAPI instance for database operations
                base_path: Pre-constructed base path (format: {save_path}/{model_name}/{run_id}/profiling/{file_name})
                chart_logger: Chart logger for logging profiling results
                top_n: Number of most frequent values to include (default: 10)
                bottom_n: Number of least frequent values to include (default: 10)

            Raises:
                Exception: If profiling or saving fails for any column
            """
            logger.info(f"Starting column profiling with top_n={top_n}, bottom_n={bottom_n}")
            
            for column in df.columns:
                try:
                    logger.debug("Profiling column", column=column)
                    
                    profile_result = profile_columns(
                        table_or_tables=df,
                        column_expressions=[f"`{column}`"],
                        db_api=spark_api,
                        top_n=top_n,
                        bottom_n=bottom_n
                    )

                    if profile_result is not None:
                        # Log charts
                        chart_logger.log_chart_dict(chart=profile_result.to_dict(), chart_name=f"profiled_{column}")
                        logger.info("Logged column profile JSON")
                        # Upload to Unity Catalog
                        profile_result.save(f"{chart_logger.get_uc_destination_path()}/profiled_{column}.html")
                        chart_logger.log_uc_chart_path(f"profiled_{column}.html")
                        logger.info("Column profile saved to Unity Catalog")

                        profile_json_data = profile_result.to_json()
                        # Prepare the file path for each column
                        file_path = f"{base_path}/column_profiles/profiled_{column}.json"

                        # Save the profile data to specified path
                        save_json_file(data=profile_json_data, path=file_path)
                        logger.info(f"Profile saved successfully for column {column} at path {file_path}")
                    else:
                        logger.warning(f"Skipping profile as data is None for column {column}")
                except Exception as e:
                    logger.error(f"Error profiling column {column} - {str(e)}")
                    raise
            logger.info(f"Column profiling completed successfully")
