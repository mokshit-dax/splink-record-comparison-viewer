import json
from typing import Dict, Any
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage
from mlp_consumer_match.utils.logging.base_logger import get_logger
import tiktoken 

logger = get_logger(name="generate_insights")

class GenerateInsights:
    """Class to generate insights using LLM on profiling data."""

    def __init__(self, api_key: str, model: str = "gpt-4"):
        """
        Initializes the LLM Insights Generator.

        :param api_key: OpenAI API Key
        :param model: LLM model name (default: GPT-4)
        """
        self.api_key = api_key
        self.model = model
        self.tokenizer = tiktoken.encoding_for_model(model)
        logger.info("LLM Insights Generator initialized")

    def count_tokens(self, text: str) -> int:
        """
        Count the number of tokens in the given text using tiktoken.

        :param text: Text to count tokens for
        :return: Number of tokens
        """
        return len(self.tokenizer.encode(text))
    
    def extract_common_fields(self, values):
        if not isinstance(values, list) or not values:
            return {}, []

        base = values[0]
        keys_to_check = ["distinct_value_count", "group_name", "total_non_null_rows", "total_rows_inc_nulls"]
        common_fields = {}

        for key in keys_to_check:
            if all(d.get(key) == base.get(key) for d in values):
                common_fields[key] = base.get(key)

        stripped_values = [
            {k: v for k, v in d.items() if k not in common_fields} for d in values
        ]
        return common_fields, stripped_values

    def preprocess_profiling_json(self, profiling_data, top_n_limit=5, bottom_m_limit=5, key_percentiles=[0.05, 0.25, 0.5, 0.75, 0.95]):
        column_details = {
            "distribution_title": {},
            "summary_stats": {},
            "distribution": [],
            "top_n": [],
            "bottom_m": []
        }

        distribution_common, top_common, bottom_common = {}, {}, {}
        distribution_data, top_data, bottom_data = [], [], []

        for chart in profiling_data.get("vconcat", []):
            for sub_chart in chart.get("hconcat", []):
                values = sub_chart.get("data", {}).get("values", [])
                title = sub_chart.get("title", {})
                title_text = title.get("text", "").lower() if isinstance(title, dict) else title.lower() if isinstance(title, str) else ""

                if "distribution" in title_text:
                    column_details["distribution_title"] = {
                        "text": title.get("text", "") if isinstance(title, dict) else title,
                        "subtitle": title.get("subtitle", "") if isinstance(title, dict) else ""
                    }
                    distribution_common, distribution_values = self.extract_common_fields(values)
                    
                    if distribution_values:
                        filtered_distribution = []
                        for p in key_percentiles:
                            closest = min(distribution_values, key=lambda x: abs(x["percentile_inc_nulls"] - p))
                            filtered_distribution.append({
                                "percentile_ex_nulls": closest["percentile_ex_nulls"],
                                "percentile_inc_nulls": closest["percentile_inc_nulls"],
                                "sum_tokens_in_value_count_group": closest["sum_tokens_in_value_count_group"],
                                "value_count": closest["value_count"]
                            })
                        distribution_data = filtered_distribution
                    else:
                        logger.warning("No distribution values found for filtering.")

                elif "top" in title_text:
                    top_common, top_data = self.extract_common_fields(values[:top_n_limit])

                elif "bottom" in title_text:
                    bottom_common, bottom_data = self.extract_common_fields(values[:bottom_m_limit])

        if distribution_common == top_common == bottom_common:
            column_details["summary_stats"] = distribution_common

        column_details["distribution"] = distribution_data
        column_details["top_n"] = top_data
        column_details["bottom_m"] = bottom_data
        return column_details

    def generate_prompt(self, profiling_data: Dict[str, Any]) -> str:
        """
        Creates a structured prompt for the LLM.

        :param profiling_data: JSON profiling data
        :return: Generated prompt
        """
        return f"""

        You are a data analyst specializing in entity resolution and data linkage using Splink. 
        Given the following column profiling data, generate **actionable** preprocessing insights to improve model performance. 
        
        **Data Cleaning & Standardization:**
        - Identify **common abbreviations, synonyms, or inconsistent values** (e.g., 'St.' vs 'Street', 'Avenue' vs 'Ave.') and suggest standardized formats.
        - Detect **extra spaces, special characters, or inconsistent casing**, and recommend cleaning strategies.
        - Identify **incorrect or non-standard formats** in phone numbers, dates, or addresses, suggesting fixes.
        
        **Feature Engineering & Transformation:**
        - Suggest **splitting or combining fields** if beneficial (e.g., full name into first and last, address into components).
        - Identify **fields with structured patterns** (e.g., ZIP codes, emails) and recommend validation checks.
        - Highlight **frequent duplicate values or common terms**, advising on term frequency adjustments for better matching.
        
        **Handling Imbalanced & Skewed Data:**
        - Detect **highly imbalanced categorical distributions** and suggest transformations to improve entity resolution.
        - Recommend **sampling or weighting strategies** for underrepresented categories.
        
        **Blocking & Indexing Strategies:**
        - Identify **potential blocking keys** (e.g., first + ZIP, email domain) for efficient record matching.
        - Recommend **hybrid blocking approaches** (e.g., exact + fuzzy match combinations) for better recall.
        
        Avoid generic statements; focus only on **specific, meaningful takeaways** that directly improve linkage quality.

        **Profiling Data:**
        {json.dumps(profiling_data, indent=4)}
        """

    def generate_insights(self, column_name:str, profiling_data: Dict[str, Any]) -> str:
        """
        Generates insights using the OpenAI LLM model.

        :param profiling_data: JSON profiling data
        :return: LLM-generated insights as a string
        """

        if not profiling_data:
            logger.warning("No profiling data provided.")
            return "No insights generated due to lack of profiling data."

        try:
            logger.info(f"Generating insights for column: {column_name}")
            preprocessed_profiling_json = self.preprocess_profiling_json(profiling_data)    
            prompt = self.generate_prompt(preprocessed_profiling_json) 
            
            input_tokens = self.count_tokens(prompt)
            logger.info(f"Input prompt token count: {input_tokens}")

            logger.debug(f"Sending request to LLM with prompt_length= {len(prompt)}")
            llm = ChatOpenAI(model_name=self.model, openai_api_key=self.api_key)
            response = llm([HumanMessage(content=prompt)])
            
            output_tokens = self.count_tokens(response.content)
            logger.info(f"Output response token count: {output_tokens}")

            logger.info(f"Successfully generated insights for column {column_name} with response_length={len(response.content)}")
            return response.content

        except Exception as e:
            logger.error(f"Failed to generate insights for column {column_name}- {str(e)}")
            raise
