from pyspark.dbutils import DBUtils
from splink import SparkAPI

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.profiling.profiling_pipeline import ProfilingPipeline
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.profiling_metrics import ProfilingMetrics
from mlp_consumer_match.service.secrets.secrets_service_factory import SecretsServiceFactory
from mlp_consumer_match.connection.database_api import DatabaseAPI
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger
from mlp_consumer_match.workflow_lifecycle.workflow_status import WorkflowStatus

logger = get_logger(name="profiling_main")

def main():
    """
    Executes the profiling pipeline using Splink and Spark as backend.

    This function performs the following steps:
      1. Initializes a Spark session and retrieves job metadata
      2. Loads preprocessed data file paths from the specified save path
      3. Configures ProfilingPipeline with the provided configuration, file paths, and job metadata
      4. Profiles the data

    Returns:
        int: Returns 1 upon successful completion of the profiling job.
    """
    # Load config
    cfg = ConfigLoader().get_or_load_config("profiling")

    # Initialize Spark and related utilities
    spark = SparkSessionFactory().get_or_create_spark_session()
    dbutils = DBUtils(spark)
    spark_api = SparkAPI(spark_session=spark)

    # Get file system
    fs = FileSystemFactory().create_file_system_from_path_prefix(cfg.save_path)
    
    # Extract configuration parameters
    job_run_id = cfg.job_run_id
    profiling_functions = cfg.profiling_functions
    save_path = cfg.save_path
    match_config_id = cfg.match_config_id
    
    # Setup Chart Logger
    uc_target_path = ConfigLoader().get_uc_destination_path(workflow_type="profiling")
    chart_logger = ChartLogger()
    chart_logger.set_uc_destination_path(uc_target_path)

    logger.info(f"Job Run ID: {job_run_id}")
    logger.info(f"Profiling Functions: {profiling_functions}")

    # Set job run ID in dbutils for tracking
    dbutils.jobs.taskValues.set(key="job_run_id", value=job_run_id)    
    logger.info("Starting Profiling Job")
    
    # Initialize metrics tracker
    metrics = ProfilingMetrics(job_run_id=job_run_id, event_type="Profiling")
    logger.info(f"Profiling started at: {metrics.start_time}")

    # Database API
    database_api = DatabaseAPI(cfg.database_api_url)

    # Create Match Run Detail Table Record with start_time, status, chartData, errorMessage
    database_api.create_match_run_detail(
        run_id=job_run_id,
        match_config_id=match_config_id,
        status=WorkflowStatus.RUNNING,
    )
    logger.info("Created Match Run Detail Table Record")
    
    # fetch api key from scope and also model from cfg
    secrets_service = SecretsServiceFactory().get_secrets_service(secret_scope=cfg.secret_scope, secret_key="OPENAI_API_KEY")
    dbx_secrets_key = secrets_service.get_secret()
    api_key = dbx_secrets_key or 'sk-'
    llm_model = 'gpt-4'

    profiler = ProfilingPipeline(
        fn_list=profiling_functions, 
        spark_api=spark_api,
        save_path= save_path,
        model_name = cfg.model_name,
        run_id=job_run_id,
        api_key=api_key,
        llm_model=llm_model,
        date_partition=cfg.date_partition,
        metrics=metrics,
        chart_logger=chart_logger
    )

    # Process each input file specified in the configuration
    for file in cfg.source.files:
        name = file.get('file').get('name')
        path = file.get('file').get('path')
        columns_to_profile = file.get('file').get('columns_to_profile')

        # Load the dataset and select the columns to profile
        df = spark.read.parquet(fs.format_path_as_spark_api_format(path)).select(*columns_to_profile)
        
        # Track dataset stats
        metrics.track_dataset_stats(
            dataset_name=name,
            row_count=df.count(),
            column_count=len(columns_to_profile)
        )
        
        logger.info(f"Successfully loaded {name} dataset from: {path}")

        profiler.transform(df, name)
        logger.info(f"Completed profiling for {name} dataset")

        logger.info(f"Starting Generating Insights for {name} dataset")
        profiler.generate_llm_insights(name)

    # End time
    metrics.track_total_execution_time_in_seconds()
    metrics.log_metrics_summary()

    chart_data_path=chart_logger.get_chart_paths(json_encode=True)
    chart_data=chart_logger.get_charts_data(json_encode=True)

    logger.info(f"Chart Data: {chart_data}")
    logger.info(f"Chart Data Path: {chart_data_path}")

    # Update Match Run Detail Table Record with status, chartData, errorMessage
    database_api.update_match_run_detail(
        run_id=job_run_id,
        status=WorkflowStatus.SUCCEEDED,
        chart_data_path=chart_data_path,
        chart_data=chart_data,
    )

    logger.info("Updated Match Run Detail Table Record")

    logger.info(f"Profiling completed at: {metrics.end_time}")
    logger.info(f"Total profiling time: {metrics.metrics.get('total_execution_in_seconds', None)}")
    logger.info("Profiling Job Completed Successfully")

if __name__ == "__main__":
    main()
