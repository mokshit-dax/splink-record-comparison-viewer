import hydra
import copy
import json

from hydra.core.config_store import ConfigStore
from hydra.core.hydra_config import HydraConfig

from mlp_consumer_match.conf.preprocess_config import PreprocessConfig
from mlp_consumer_match.conf.train_config import TrainConfig
from mlp_consumer_match.conf.inference_config import InferenceConfig
from mlp_consumer_match.conf.profiling_config import ProfilingConfig
from mlp_consumer_match.conf.cluster_config import ClusterConfig
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.dictionary_utils import DictionaryUtils

logger = get_logger(name="config_loader")

class ConfigLoader:
    """
    A singleton class for loading configuration files.
    
    This class provides a singleton interface for loading configuration files from YAML files.
    It uses Hydra to load the configuration files and stores them in a dictionary for later use.
    
    Attributes:
        _instance (ConfigLoader): The singleton instance of ConfigLoader.
        config_data_classes (dict): A dictionary mapping configuration names to their classes.
        configs (dict): A dictionary mapping configuration names to their loaded configurations.
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Returns the singleton instance of ConfigLoader.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Variable length keyword arguments.
        
        Returns:
            ConfigLoader: The singleton instance of ConfigLoader.
        """
        if not cls._instance:
            cls._instance = super(ConfigLoader, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """
        Initializes the ConfigLoader.
        
        This method sets up the configuration data classes and registers them with Hydra.
        It also initializes the configs dictionary to store loaded configurations.
        """
        if not hasattr(self, 'initialized'):
            self.config_data_classes = {
                "preprocess_config": PreprocessConfig,
                "train_config": TrainConfig,
                "inference_config": InferenceConfig,
                "profiling_config": ProfilingConfig,
                "cluster_config": ClusterConfig,
            }
            self.configs = {}
            self.config_path = None

            # Register configs with hydra
            cs = ConfigStore.instance()
            for config_name, config_class in self.config_data_classes.items():
                cs.store(name=config_name, node=config_class)
            
            self.initialized = True


    def get_or_load_config(self, config_name: str):
        """
        Loads a configuration from a YAML file or returns the existing configuration.
        
        Args:
            config_name (str): Name of the configuration to load (e.g., 'train', 'preprocess')
        
        Returns:
            Config: The loaded configuration object.
        """
        if not hasattr(self, 'initialized'):
            raise Exception("ConfigLoader must be initialized first")
        
        if f'{config_name}_config' not in self.config_data_classes:
            raise ValueError(f"Invalid config name: {config_name}")
        
        if config_name in self.configs:
            logger.info(f"Config '{config_name}' already loaded, returning existing config")
            return self.configs[config_name]
        
        @hydra.main(config_path=f"", config_name=config_name, version_base=None)
        def load_config(cfg):
            self.configs[config_name] = copy.deepcopy(cfg)
            logger.info(f"Config '{config_name}' loaded successfully")
            if self.config_path is None:
                logger.info("Fetching config path using HydraConfig")
                hc = HydraConfig.get()
                path = next(
                    (src["path"] for src in hc.runtime.config_sources if src.get("schema") == "file"),
                    None
                )
                self.config_path = path
            logger.info(f"Config path used by Hydra: {self.config_path}")
    
        load_config()    
        return self.configs[config_name]


    def get_hydra_config_path(self):
        """
        Returns the path to the config file used by Hydra.
        
        Returns:
            str: Path to the config file used by Hydra
        """
        return self.config_path

    def format_columns_for_selection(self) -> str:
        """
        Format a list of column names into a comma-separated string for SQL selection.
        
        Returns:
            str: Comma-separated string of column names
        """
        cfg = self.get_or_load_config("train")
        return ", ".join(cfg.cols_to_select)

    
    def get_read_path_and_function_for_sql(self, path: str, workflow_type: str = 'train') -> tuple[str, str]:
        """
        Returns the path to read the data from and function to read the data using.

        Args:
            path (str): Path to read the data from
            workflow_type (str, optional): Type of workflow. Defaults to 'train'.

        Returns:
            tuple[str, str]: Path to read the data from and function to read the data using
        """
        cfg = self.get_or_load_config(workflow_type)
        if len(cfg.save_path.split('.')) == 3:
            return "some-source-path-of-delta-table", "some-table-reading-function"
        return path + "*.parquet", "read_parquet"


    def get_uc_destination_path(self, workflow_type="train") -> str:
        """
        Returns Unity Catalog destination path.

        Args:
            workflow_type (str, optional): Type of workflow. Defaults to 'train'.

        Returns:
            str: Unity Catalog destination path
        """
        cfg = self.get_or_load_config(workflow_type)
        return f"/Volumes/{cfg.uc_catalog}/{cfg.uc_schema}/{cfg.uc_volume}/{cfg.job_run_id}"
        

    def get_mlflow_model_save_path(self, model_name: str, workflow_type: str = 'train') -> str:
        """
        Returns the save path to the mlflow model.

        Args:
            model_name (str): Name of the model
            workflow_type (str, optional): Type of workflow. Defaults to 'train'.

        Returns:
            str: Path to the mlflow model
        """
        cfg = self.get_or_load_config(workflow_type)
        return f"{cfg.model_save_path}.{model_name}"

    def get_preprocess_path(self, file_name: str = None) -> str:
        """
        Returns the path to the preprocessed data.

        Args:
            file_name (str, optional): Name of the file. Defaults to None.

        Returns:
            str: Path to the preprocessed data
        """
        cfg = self.get_or_load_config("preprocess")
        base = f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/preprocessed/{cfg.job_run_id}"
        return f"{base}/{file_name}" if file_name else base
        
    
    def get_salt_key_prediction_path(self, include_partition: bool = True) -> str:
        """
        Get the path to the prediction directory with salt key.
        
        Args:
            include_partition (bool, optional): Whether to include the partition in the path. Defaults to True.
        
        Returns:
            str: Path to the prediction directory with salt key
        """
        cfg = self.get_or_load_config("inference")

        # `cfg.salt_key` is a string of the form "{'left': 1},{'right': 2}" for linkage and "{'left': 1},{'left': 2}" for dedupe. 
        # So we're splitting on the comma to get the list of stringified dictionaries ["{'left': 1}", "{'right': 2}"] 
        # which is the input to merge_stringified_dicts_list().
        salt_keys_dict = DictionaryUtils.merge_stringified_dicts_list(cfg.salt_key.split(","))

        # `salt_keys_dict` is a dictionary like {"left": 1, "right": 2} for linkage, and {"left": [1, 2]} for dedupe. 
        # We're flattening all the values to [1, 2] to get the left and right salt keys.
        salt_keys_list = DictionaryUtils.flatten_dict_values_to_list(salt_keys_dict)
        if len(salt_keys_list) != 2:
            raise ValueError(f"Expected exactly 2 salt keys, got {len(salt_keys_list)}: {salt_keys_list}")
        left_salt_key, right_salt_key = salt_keys_list

        base = f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/predictions/{cfg.job_run_id}/salt_keys/{left_salt_key}_{right_salt_key}"
        return f"{base}/prediction_{cfg.partition}.parquet" if include_partition else base

    
    def get_prediction_path(self, include_salt_key_dir: bool = True, include_salt_key_glob_pattern: bool = True) -> str:
        """
        Get the path to the prediction directory.
        
        Args:
            include_salt_key_dir (bool, optional): Whether to include the salt key directory in the path. Defaults to True.
            include_salt_key_glob_pattern (bool, optional): Whether to include the salt key glob pattern in the path. Defaults to True.
        
        Returns:
            str: Path to the prediction directory
        """        
        cfg = self.get_or_load_config("inference")
        base = f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/predictions/{cfg.job_run_id}"
        base = f"{base}/salt_keys" if include_salt_key_dir else base
        final_path = f"{base}/**" if include_salt_key_glob_pattern else base
        return final_path


    def get_bucket_path(self, bucket_name: str = None) -> str:
        """
        Get the path to the bucket directory. Returns None if bucket_queries is not present in config.
        
        Args:
            bucket_name (str, optional): The name of the bucket. Defaults to None.
        
        Returns:
            str: Path to the bucket directory
        """        
        cfg = self.get_or_load_config("inference")
        if not cfg.bucket_queries:
            return None
        base = f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/predictions/{cfg.job_run_id}/buckets"
        return f"{base}/{bucket_name}" if bucket_name else base
        
    def get_comparison_viewer_bucket_path(self, bucket_name: str) -> str:
        """
        Get the path to the comparison viewer HTML file.
        
        Args:
            bucket_name (str): The name of the bucket.
        
        Returns:
            str: Path to the comparison viewer HTML file
        """        
        cfg = self.get_or_load_config("inference")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/predictions/{cfg.job_run_id}/buckets/{bucket_name}/charts/comparison_viewer.html"
    
    def get_profiling_base_path(self) -> str:
        """
        Get the path to the profiling base directory.
        
        Returns:
            str: Path to the profiling base directory
        """
        cfg = self.get_or_load_config("profiling")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}"

    def get_profiling_output_path(self, file_name: str) -> str:
        """
        Get the path to the profiling output file.
        
        Args:
            file_name (str): The name of the file.
        
        Returns:
            str: Path to the profiling output file
        """
        cfg = self.get_or_load_config("profiling")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/profiling/{cfg.job_run_id}/{file_name}"

    def get_profiling_dir_path(self, file_name: str) -> str:
        """
        Get the path to the profiling directory.
        
        Args:
            file_name (str): The name of the file.
        
        Returns:
            str: Path to the profiling directory
        """        
        cfg = self.get_or_load_config("profiling")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/profiling/{cfg.job_run_id}/{file_name}/column_profiles"

    def get_profiling_insights_path(self, file_name: str) -> str:
        """
        Get the path to the profiling insights file.
        
        Args:
            file_name (str): The name of the file.
        
        Returns:
            str: Path to the profiling insights file
        """        
        cfg = self.get_or_load_config("profiling")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/profiling/{cfg.job_run_id}/{file_name}_insights.json"
        
    def get_cluster_bucket_path(self, bucket_name: str = None) -> str:
        """
        Get the path to the cluster bucket directory.

        Args:
            bucket_name (str, optional): The name of the bucket. Defaults to None.
        
        Returns:
            str: Path to the cluster bucket directory
        """
        cfg = self.get_or_load_config("cluster")
        base = f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/cluster/{cfg.job_run_id}/buckets"
        return f"{base}/{bucket_name}" if bucket_name else base

    def get_cluster_bucket_path_with_filename(self, bucket_name: str):
        """
        Get the path to the cluster bucket directory with filename.

        Args:
            bucket_name (str): The name of the bucket.

        Returns:
            str: Path to the cluster bucket directory with filename
        """
        return f"{self.get_cluster_bucket_path(bucket_name)}/{bucket_name}.parquet"

    def get_cluster_base_path(self) -> str:
        """
        Get the path to the cluster base directory. Returns None if cluster_on is not present in inference config.
        
        Returns:
            str: Path to the cluster base directory
        """
        inference_cfg = self.get_or_load_config("inference")
        if not inference_cfg.cluster_on:
            return None
        cfg = self.get_or_load_config("cluster")
        return f"{cfg.save_path}/{cfg.model_name}/{cfg.date_partition}/cluster/{cfg.job_run_id}"
    
    def get_salt_keys_for_file(self, functions_list: list[dict]) -> list[int]:
        """
        Get the salt key for a file.
        
        Args:
            functions_list (list[dict]): List of preprocessing functions
        
        Returns:
            list[int]: List of salt keys for the file
        """
        salt_key_val = 1
        for fn in functions_list:
            if fn.get('add_salt_key'):
                salt_key_val = fn['add_salt_key'].get('num_salt_keys', 1)
                break
        return [key for key in range(1, salt_key_val + 1)]
        
        

    def generate_salt_key_pairs(self, salt_keys: dict[str, list[int]]) -> list[str]:
        """
        Generate salt key pairs from a list of salt keys.
        
        Args:
            salt_keys (dict[str, list[int]]): Dictionary of salt keys
        
        Returns:
            list[str]: List of salt key pairs in the form of JSON strings
        
        Examples:
            >>> generate_salt_key_pairs({"left": [1, 2], "right": [1]})
            [
                '{"left":"1"},{"right":"1"}',
                '{"left":"2"},{"right":"1"}'
            ]
        """
        keys = list(salt_keys.keys())
        l_key_index, r_key_index = 0, 0 if len(salt_keys) == 1 else 1
        salt_key_pairs = []
        for l_sk in salt_keys[keys[l_key_index]]:
            for r_sk in salt_keys[keys[r_key_index]]:
                left_key = json.dumps({keys[l_key_index]: l_sk})
                right_key = json.dumps({keys[r_key_index]: r_sk})
                key_val_pair = left_key + "," + right_key
                salt_key_pairs.append(key_val_pair)
        return salt_key_pairs
    
    def get_nicknames_file_path(self) -> str:
        """
        Get the nicknames path from the resources folder.

        Returns:
            str: Path to the nicknames file
        """
        cfg = self.get_or_load_config("preprocess")
        return cfg.nicknames_file_path
    
    def get_bucket_queries(self) -> dict[str, dict]:
        """
        Get the bucket queries from the inference config.
        
        Returns:
            dict: A dictionary where each key is a bucket name and the value is a dictionary of its configuration.
        """
        cfg = self.get_or_load_config("inference")
        bucket_queries = None
        if cfg.bucket_queries:
            bucket_queries = {
                query.get("query").get("name"): query.get("query")
                for query in cfg.bucket_queries
            }
        else:
            bucket_queries = {
                "default_bucket": {
                    "sql": "SELECT * FROM __PREDICTIONS__",
                    "generate_comparison_viewer": True,
                    "sample_size_to_generate_charts": 10000000,
                    "num_example_rows": 5,
                }
            }
        logger.info(f"Bucket queries: {bucket_queries}")
        return bucket_queries
