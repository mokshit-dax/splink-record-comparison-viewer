from dataclasses import dataclass

@dataclass
class PreprocessConfig:
    """
    Configuration settings for dataset preprocessing.

    This dataclass encapsulates the parameters required for setting up the preprocessing pipeline.
    It defines the source datasets, the columns to be selected, model details for organizational
    purposes, and the destination path where the processed data will be stored.

    Attributes:
        files (list[str]): A list of file paths or source identifiers for the datasets to be processed.
        model_name (str): The name of the model. This is used for naming conventions and organizing
                          preprocessing outputs.
        job_run_id (str): The ID of the job run. This is used for naming conventions and organizing
                          preprocessing outputs.
        database_api_url (str): The API host URL of the database connection.
        databricks_host_url (str): The host URL of the databricks workspace.
        secrets_scope (str): The scope of the secrets.
        secrets_key (str): The key of the secrets.
        match_config_id (str): The ID of the match config record. This is used for fetching the configYAML and configJSON etc.
        save_path (str): The base directory where the preprocessed datasets will be saved.
        date_partition (str): The date partition for the preprocessing results.
    """
    
    # Source Details
    files: list[str]

    # Model Details
    model_name: str

    # Job Run ID
    job_run_id: str

    # Database Connection Details
    database_api_url: str
    databricks_host_url: str
    secrets_scope: str
    secrets_key: str

    # Match Config ID
    match_config_id: str

    # Date Partition
    date_partition: str

    # Destination Details
    save_path: str
