from dataclasses import dataclass

@dataclass
class ProfilingConfig:
    """
    Configuration settings for dataset profiling.

    This dataclass encapsulates the parameters required for setting up the profiling pipeline.
    It defines the source datasets, the columns to be profiled, and the destination path where
    the profiling results will be stored.

    Attributes:
        files (list[dict]): A list of dictionaries containing file details and columns to profile.
        profiling_functions (list[str]): List of function names to be used for profiling the data.
        model_name (str):The name of the model. This is used for naming conventions and organizing
                          profiling outputs.
        job_run_id (str): The ID of the job run. This is used for naming conventions and organizing
                         profiling outputs.
        save_path (str): The directory where the profiling results will be saved.
        database_api_url (str): The URL of the database API.
        secret_scope (str): The scope of the secret.
        match_config_id (str): The ID of the match configuration.
        uc_catalog (str): The name of the Unity Catalog catalog.
        uc_schema (str): The name of the Unity Catalog schema.
        uc_volume (str): The name of the Unity Catalog volume.
        date_partition (str): The date partition to be used for profiling.
    """
    
    files: list[dict]
    profiling_functions: list[str]
    model_name: str
    job_run_id: str
    save_path: str
    database_api_url: str
    secret_scope: str
    match_config_id: str
    uc_catalog: str
    uc_schema: str
    uc_volume: str
    date_partition: str