from dataclasses import dataclass

@dataclass
class ClusterConfig:
    """
    Configuration settings for clustering on dataset.

    This dataclass encapsulates the parameters required for cluster configuration.
    It defines the buckets, model details, job run ID, and destination path.

    Attributes:
        bucket_name (str): The name of the bucket.
        date_partition (str): The date partition of the data.
        threshold_match_probability (float): The threshold for match probability.
        model_name (str): The name of the model.
        job_run_id (str): The ID of the job run.
        task_run_id (str): The ID of the task run.
        database_api_url (str): The API URL for the database.
        databricks_host_url (str): The host URL for Databricks.
        secret_scope (str): The scope of the secret.
        secret_key (str): The key of the secret.
        match_config_id (str): The ID of the match config.
        save_path (str): The base directory where the source data is stored.
        model_version (str): The version of the model.
        model_model_path (str): The path to save the model.
        mlflow_tracking_uri (str): The URI for MLflow tracking.
        mlflow_registry_uri (str): The URI for MLflow registry.
    """
    
    
    # buckets: list[str]
    bucket_name: str
    date_partition: str
    model_name: str
    job_run_id: str
    task_run_id: str
    database_api_url: str
    databricks_host_url: str
    secret_scope: str
    secret_key: str
    match_config_id: str
    save_path: str
    model_version: str
    model_save_path: str
    mlflow_tracking_uri: str
    mlflow_registry_uri: str
