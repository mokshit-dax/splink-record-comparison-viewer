from dataclasses import dataclass

@dataclass
class InferenceConfig:
    """
    Configuration settings for model inference.

    This dataclass encapsulates the parameters required for setting up the inference pipeline.
    It defines the source data configuration, output paths, and AWS Lambda deployment settings.

    Attributes:
        partition (str): The partition identifier for the inference process.

        save_path (str): The base directory where the source data is stored.

        pre_inference_filters (list[dict]): A list of filters to apply to the dataset.
            Each filter is a dictionary containing a name key and a where key.
            The where key contains a string of SQL code to be executed.
            Example: [{'name': 'right', 'where': 'non_fulfillment_code IN ('B', 'M', 'T')'}]

        model_version (str): Version of the deployed model
        
        model_save_path (str): Path where the model is saved

        mlflow_tracking_uri (str): URI where the MLFlow tracking server is located

        mlflow_registry_uri (str): URI where the MLFlow model is registered

        generate_comparison_viewer (bool): Whether to generate comparison viewer charts

        num_example_rows (int): Number of example rows to include in the comparison viewer chart

        bucket_queries (list[dict]): A list of queries to apply to the dataset.
            Each query is a dictionary containing a name key and a sql key.
            The sql key contains a string of SQL code to be executed.
            Example: [{'name': 'right', 'sql': 'CREATE TABLE __TABLE_NAME__ AS SELECT __COLS_TO_SELECT__ FROM read_parquet('__FILE_PATH__') WHERE non_fulfillment_code IN ('B', 'M', 'T')'}]

        salt_key (str): Salt keys help partition the data. Inference is performed on data filtered by salt key.

        job_run_id (str): The ID of preprocessing task run.

        task_run_id (str): The ID of preprocessing task run.

        database_api_url (str): The API URL for the database.

        databricks_host_url (str): The host URL for Databricks.

        secret_scope (str): The scope of the secret.

        secret_key (str): The key of the secret.

        match_config_id (str): The ID of the match config.

        date_partition (str): The date partition of the job run.

        cluster_on (list[dict]): A list of dictionaries specifying the buckets to cluster on during the inference process.
            Each dictionary contains a `bucket` key with the following structure:
                - name (str): The name of the bucket (e.g., 'exact_first').
                - threshold (float): The match probability threshold for clustering within the bucket.

            Example:
                cluster_on = [
                    {'bucket': {'name': 'exact_first', 'threshold': 0.0}}
                ]
    """
    
    # Source Details
    partition: str
    save_path: str
    pre_inference_filters: list[dict]

    # Model Details
    model_version: str
    model_save_path: str
    model_name: str

    # MLFlow Details
    mlflow_tracking_uri: str
    mlflow_registry_uri: str

    # Chart Details
    generate_comparison_viewer: bool
    num_example_rows: int

    # Bucket Details
    bucket_queries: list[dict]

    # Clustering Details
    cluster_on: list[dict]

    # Salt Key Details
    salt_key: str

    # Job Run ID
    job_run_id: str

    # Task Run ID
    task_run_id: str

    # Database Connection Details
    database_api_url: str
    databricks_host_url: str
    secret_scope: str
    secret_key: str

    # Match Config ID
    match_config_id: str

    # Date Partition
    date_partition: str
