from dataclasses import dataclass

@dataclass
class TrainConfig:
    """
    Configuration settings for model training.

    This dataclass encapsulates the parameters required for setting up the training pipeline.
    It defines the rules for deterministic matching, blocking, and feature comparisons,
    as well as model details and paths for saving outputs.

    Attributes:
        save_path (str): The base directory where the trained model and outputs will be saved.

        primary_key (str): The primary key for the dataset.

        cols_to_select (list[str]): A list of columns to select from the dataset.

        pre_train_filters (list[dict]): A list of filters to apply to the dataset.
            Each filter is a dictionary containing a name key and a where key.
            The where key contains a string of SQL code to be executed.
            Example: [{'name': 'right', 'where': 'non_fulfillment_code IN ('B', 'M', 'T')'}]

        deterministic_rules (list[str]): A list of rules that define exact matches between records.
            Each rule is a string containing conditions joined by AND operators.
            Example: "l.first_lower=r.first_lower AND l.phone=r.phone"
            
        blocking_rules (list[str]): A list of rules used to partition data into blocks for comparison.
            Each rule is a string containing conditions joined by AND operators.
            Records are compared only within the same block.
            
        comparisons (list[dict]): A list of feature comparison configurations defining how fields
            should be compared between records. Each comparison is a dictionary specifying the field
            and comparison methods (e.g., exact match, Levenshtein distance) with parameters.
            Example: {'f_name_comparison': [{'exact': {'column': 'first_lower'}}]}
            
        link_type (str): The type of problem to solve (e.g., 'link_only', 'dedupe').
            
        recall (float): The target recall value for the model, between 0 and 1.
            Used to tune model thresholds during training.

        estimate_u_max_pairs (int): The maximum number of pairs to use for estimating the number of unique records.

        model_save_path: Path to save the mlflow model.

        model_version: Version of the model.

        mlflow_tracking_uri (str): The Tracking URI for the MLflow server.

        mlflow_experiment_root (str): The root directory for MLFlow experiments.

        mlflow_registry_uri (str): The URI for the MLFlow registry.

        job_run_id (str): The run ID for the job.

        task_run_id (str): The run ID for the task.

        date_partition (str): The date partition for the training results.

        database_api_url (str): The API URL for the database.
        
        databricks_host_url (str): The host URL for Databricks.
        
        secret_scope (str): The scope of the secret.
        
        secret_key (str): The key of the secret.

        match_config_id (str): The ID of the match config.

        uc_catalog (str): The catalog of the Unity Catalog.

        uc_schema (str): The schema of the Unity Catalog.

        uc_volume (str): The volume of the Unity Catalog.
    """
    
    # Source Details        
    save_path: str  
    primary_key: str
    cols_to_select: list[str]
    pre_train_filters: list[dict]

    # Rule Details
    deterministic_rules: list[str]
    blocking_rules: list[str]
    comparisons: list[str]

    # Model Details
    link_type: str
    recall: float
    estimate_u_max_pairs: int
    max_rows_limit: int
    em_convergence: float

    # Storage Details
    model_save_path: str
    model_version: str
    
    # MLFlow Details
    mlflow_tracking_uri: str
    mlflow_registry_uri: str
    mlflow_experiment_root: str

    # Job Details
    job_run_id: str

    # Task Details
    task_run_id: str

    # Date Partition
    date_partition: str

    # Database Connection Details
    database_api_url: str
    databricks_host_url: str
    secret_scope: str
    secret_key: str

    # Match Config ID
    match_config_id: str

    # Unity Catalog Details
    uc_catalog: str
    uc_schema: str
    uc_volume: str
