import mlflow
import json

from mlflow.models.signature import ModelSignature

from mlp_consumer_match.conf.config_loader import ConfigLoader
from splink import DuckDBAPI, Linker, SettingsCreator
from splink.internals.charts import save_offline_chart
from splink.blocking_analysis import count_comparisons_from_blocking_rule

from mlp_consumer_match.conf.train_config import TrainConfig
from mlp_consumer_match.connection.duckdb_connection import DuckDBConnection
from mlp_consumer_match.train.comparison.comparison_parser import ComparisonParser
from mlp_consumer_match.service.sql_formatting_service import SQLFormattingService
from mlp_consumer_match.train.mlflow.loggers.mlflow_logger_factory import MLflowLoggerFactory
from mlp_consumer_match.train.mlflow.models.mlflow_linker_model_factory import MLflowLinkerModelFactory
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger
from mlp_consumer_match.utils.convert_to_json import convert_to_json

logger = get_logger(name="train_pipeline")


class TrainPipeline:
    """
    Class for executing the record linkage model training pipeline using Splink.

    This class performs the following steps:
      1. Initializes a Spark session and retrieves job metadata
      2. Loads preprocessed training data file paths from the specified save path
      3. Configures TrainPipeline with the provided configuration, model name, and job metadata
      4. Trains the model
      5. Saves the trained model

    Args:
        cfg (TrainConfig): Configuration containing model training parameters.
        model_name (str): The name of the model.
        metrics: Optional metrics tracking object.
        chart_logger: Chart logger object.

    Returns:
        int: Returns 1 upon successful completion of the training job.
    """

    def __init__(self, cfg: TrainConfig, model_name: str, metrics=None, chart_logger: ChartLogger = ChartLogger()):
        """
        Initializes a new instance of the TrainPipeline class.

        Args:
            cfg (TrainConfig): Configuration containing model training parameters.
            model_name (str): The name of the model.
            metrics: Optional metrics tracking object.
            chart_logger: Chart logger object.
        """

        self.cfg = cfg
        self.model_name = model_name
        self.metrics = metrics

        self.settings = None
        self.linker = None

        # Get File System
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(self.cfg.save_path)
        self.files = self.fs.ls(f"{ConfigLoader().get_preprocess_path()}/")
        logger.info(f"File paths: {self.files}")

        # DuckDB Details
        self.db_path = f'{self.fs.db_path_prefix}{self.model_name}_db.db'
        self.duckdb_connection = DuckDBConnection(self.db_path).get_connection()
        self.duckdb_table_names = [file.name + '_table' for file in self.files]
        logger.info(f"DuckDB Table Names: {self.duckdb_table_names}")

        # MLFlow Logger
        self.mlflow_logger = MLflowLoggerFactory().create_mlflow_logger_from_tracking_and_registry_uri(
            tracking_uri=self.cfg.mlflow_tracking_uri,
            registry_uri= self.cfg.mlflow_registry_uri,
            mlflow_experiment_name=f'{self.cfg.mlflow_experiment_root}/{self.model_name}',
        )

        # Chart Logger
        self.chart_logger = chart_logger
        
        # MLflow Model Save Path
        self.mlflow_model_save_path = ConfigLoader().get_mlflow_model_save_path(self.model_name)
        logger.info(f"MLflow Model Save Path: '{self.mlflow_model_save_path}'")

        logger.info(f"Unity Catalog Save Path: {self.chart_logger.get_uc_destination_path()}")

        logger.info(f'Deterministic Rules: {str(self.cfg.deterministic_rules)}')

        logger.info(f'Blocking Rules: {str(self.cfg.blocking_rules)}')
        logger.info(f'test_logging: {self.cfg.comparisons}')
        logger.info(f'Comparisons: {str(ComparisonParser().parse(self.cfg.comparisons))}')

        if self.cfg.pre_train_filters:
            self.pre_train_filters = {query.get("filter").get("name"): " WHERE " + query.get("filter").get("where") for query in self.cfg.pre_train_filters}
        else:
            self.pre_train_filters = {}
        logger.info(f'Pre Train Filters: {str(self.pre_train_filters)}')

        self._configure_duckdb_tables()

        self._configure_linker_settings()

        self._configure_linker_model()

    def _configure_duckdb_tables(self):
        """
        Configures the DuckDB tables.

        Creates the DuckDB tables from the preprocessed data.

        Args:
            files (list): List of preprocessed files to create respective tables.
            db_path (str): Path to the DuckDB database.
            duckdb_connection (duckdb.Connection): Connection to the DuckDB database.
        """
        self.duckdb_connection.execute(f"SET temp_directory='{self.db_path}/temp_dir/';")
        self.duckdb_connection.execute(f"CALL load_aws_credentials()")
        logger.info("Creating DuckDB tables")

        for file in self.files:
            read_path, read_function = ConfigLoader().get_read_path_and_function_for_sql(file.path)
            table_name = file.name + '_table'
            logger.info(f"Table Name: {table_name}")

            sql_base_statement = f"CREATE TABLE __TABLE_NAME__ AS SELECT __COLS_TO_SELECT__ FROM __READ_FUNCTION__('__READ_PATH__')"
            sql_query = sql_base_statement + self.pre_train_filters.get(file.name, '')
            sql_query = SQLFormattingService().replace_placeholders_in_query(
                query = sql_query,
                replacement_map = {
                    '__READ_FUNCTION__': read_function,
                    '__READ_PATH__': read_path,
                    '__TABLE_NAME__': table_name,
                    '__COLS_TO_SELECT__': ConfigLoader().format_columns_for_selection(),
                }
            )
            logger.info(f"SQL Query for {table_name}: {sql_query}")

            self.duckdb_connection.query(sql_query)
            logger.info(f"Loaded {table_name} into DuckDB")

            table_count = self.duckdb_connection.query(f"SELECT count(*) FROM {table_name}").fetchone()[0]
            logger.info(f"Number of rows in {table_name}: {table_count}")

            table_cols = self.duckdb_connection.query(f"DESCRIBE {table_name}").fetchall()
            logger.info(f"Columns in {table_name}: {table_cols}")

    def _configure_linker_settings(self):
        """
        Configures the Linker settings.

        Creates the Linker settings based on the input parameters.

        Args:
            link_type (str): Whether model is of type 'dedupe' or 'link_only'.
            comparisons (list): List of comparisons to use.
            unique_id_column_name (str): Name of the unique identifier column.
            blocking_rules_to_generate_predictions (list): List of blocking rules to generate predictions.
            retain_matching_columns (bool): Whether to retain matching columns.
            retain_intermediate_calculation_columns (bool): Whether to retain intermediate calculation columns.
            additional_columns_to_retain (list): List of additional columns to retain.
        """
        self.settings = SettingsCreator(
            link_type=self.cfg.link_type,
            comparisons=ComparisonParser().parse(self.cfg.comparisons),
            unique_id_column_name=self.cfg.primary_key,
            blocking_rules_to_generate_predictions=self.cfg.blocking_rules,
            retain_matching_columns = True,
            retain_intermediate_calculation_columns = True,
            additional_columns_to_retain = self.cfg.cols_to_select,
            em_convergence=self.cfg.em_convergence,
        )
        logger.info(f"Configured Settings: {self.settings}")

    def _configure_linker_model(self):
        """
        Configures the Linker model.

        Creates the Linker model based on the input parameters.

        Args:
            input_table_or_tables (str or list): Table or tables to use for linking.
            db_api (DuckDBAPI): DuckDB API object.
            settings (Settings): Linker settings.
            validate_settings (bool): Whether to validate the settings.
        """
        self.linker = Linker(
            input_table_or_tables=self.duckdb_table_names,
            db_api = DuckDBAPI(connection=self.duckdb_connection),
            settings = self.settings,
            validate_settings = True,
        )
        logger.info(f"Configured Linker")

    def _log_chart(self, chart, chart_name, folder=None):
        """
        Logs the chart to MLFlow.

        Args:
            chart (dict): Visualization chart object to be saved and logged.
            chart_name (str): Name of the chart file (without extension).
            folder (str, optional): MLflow artifact folder name where the chart will be logged. Defaults to None.

        """
        chart_path = f"/tmp/{chart_name}.html"
        save_offline_chart(chart.to_dict(), chart_path, overwrite=True)
        mlflow.log_artifact(chart_path, folder)
        return


    def _validate_deterministic_rules(self):
        """
        Validates the deterministic rules by checking if they will generate a sufficient number of comparisons.
        
        Returns:
            list: A list of valid deterministic rules that will generate sufficient comparisons.
        """
        logger.info("Validating deterministic rules")
        valid_deterministic_rules = []
        
        for idx, rule in enumerate(self.cfg.deterministic_rules):
            try:
                # Count the number of comparisons that would be generated by this rule
                num_comparisons = count_comparisons_from_blocking_rule(
                    blocking_rule=rule,
                    table_or_tables=self.duckdb_table_names,
                    link_type=self.cfg.link_type,
                    db_api=DuckDBAPI(connection=self.duckdb_connection),
                    max_rows_limit=self.cfg.max_rows_limit,
                )

                logger.info(f"Rule {idx}: '{rule}' would generate {num_comparisons['number_of_comparisons_to_be_scored_post_filter_conditions']} comparisons")
                

                # Define a minimum threshold for comparisons
                min_comparisons_threshold = 0
                if num_comparisons['number_of_comparisons_to_be_scored_post_filter_conditions'] > min_comparisons_threshold:
                    valid_deterministic_rules.append(rule)
                else:
                    logger.warning(f"Rule {idx}: '{rule}' generates only {num_comparisons['number_of_comparisons_to_be_scored_post_filter_conditions']} comparisons, which is below the threshold of {min_comparisons_threshold}. Skipping this rule.")
            except Exception as e:
                logger.warning(f"Error evaluating rule {idx}: '{rule}'. Error: {str(e)}. Skipping this rule.")
        
        return valid_deterministic_rules

    def train_model(self):
        """
        Trains the Linker model.

        Args:
            linker (Linker): Linker object.
            deterministic_rules (list): List of deterministic rules to use for training.
            recall (float): Recall value to use for training.
            estimate_u_max_pairs (int): Maximum number of pairs to use for estimating U.

        Returns:
            dict: A dictionary containing the inference schema and the gamma comparisons with labels.
        """
        # Track model parameters if metrics available
        if self.metrics:
            model_params = {
                "em_convergence": self.cfg.em_convergence,
                "link_type": self.cfg.link_type,
                "primary_key": self.cfg.primary_key,
                "recall": self.cfg.recall,
                "estimate_u_max_pairs": self.cfg.estimate_u_max_pairs,
                # Add any other model parameters you want to track
            }
            self.metrics.track_training_params(model_params)

        
        valid_deterministic_rules = self._validate_deterministic_rules()
        logger.info(f"Valid Deterministic Rules: {valid_deterministic_rules}")
        if not valid_deterministic_rules:
            raise ValueError("No valid deterministic rules available for training. The rules might be using columns that are 100% null.")
        logger.info("Training Linker")

        self.linker.training.estimate_probability_two_random_records_match(valid_deterministic_rules, recall=self.cfg.recall, max_rows_limit=self.cfg.max_rows_limit)
        logger.info("Estimated probability of two random records matching")

        self._log_chart(self.linker.visualisations.match_weights_chart(), "initial_match_weights_chart")
        logger.info("Initial Match Weights Chart Logged")
        self.linker.training.estimate_u_using_random_sampling(self.cfg.estimate_u_max_pairs)
        logger.info("Estimated number of unique records")

        for index, deterministic_rule in enumerate(valid_deterministic_rules):
            model = self.linker.training.estimate_parameters_using_expectation_maximisation(deterministic_rule)

            self._log_chart(
                chart=self.linker.visualisations.match_weights_chart(), 
                chart_name=f"training_match_weight_chart_{index}",
            )
            self._log_chart(
                chart=model.match_weights_interactive_history_chart(),
                chart_name="training_interactive_match_weight_chart", 
                folder=f"training/iteration_{index}"
            )
            self._log_chart(
                chart=model.m_u_values_interactive_history_chart(),
                chart_name="m_u_values_interactive_history_chart",
                folder=f"training/iteration_{index}"
            )
            self._log_chart(
                chart=model.probability_two_random_records_match_iteration_chart(),
                chart_name="probability_two_random_records_match_iteration_chart", 
                folder=f"training/iteration_{index}"
            )
        
        final_match_weights_chart = self.linker.visualisations.match_weights_chart()
        self._log_chart(final_match_weights_chart, "final_match_weights_chart")

        # Save to Unity Catalog
        final_match_weights_chart.save(f"{self.chart_logger.get_uc_destination_path()}/final_match_weights_chart.html")
        self.chart_logger.log_uc_chart_path("final_match_weights_chart.html")
        logger.info("Final match weights chart saved to Unity Catalog")
        
        # Log chart dict and UC path
        self.chart_logger.log_chart_dict(
            final_match_weights_chart.to_dict(), "final_match_weights_chart"
        )
        logger.info("Logged final match weights chart JSON")

        self._log_chart(self.linker.visualisations.m_u_parameters_chart(), "m_u_parameters_chart")
        logger.info("Final match weights and m_u parameters charts created and logged")

        if self.metrics:
            try:
                performance_metrics = {
                    "number_of_comparisons": len(ComparisonParser().parse(self.cfg.comparisons)),
                    "number_of_blocking_rules": len(self.cfg.blocking_rules),
                    "number_of_deterministic_rules": len(self.cfg.deterministic_rules),
                }
                self.metrics.track_training_performance(performance_metrics)
            except Exception as e:
                logger.warning(f"Error tracking performance metrics: {e}")

        logger.info("Saving Linker")
        model_json = self.linker.misc.save_model_to_json()

        # self.linker can be directly used, just need to fetch 2 records to execute the SQL query
        record_1 = {
            'unique_id': 1, 
            'first': 'John', 
            'last': 'Doe', 
            'business_name': 'apple', 
            'phone': '9898989898', 
            'dob': '1990-01-01',
            'email': 'john.doe@example.com',
            'nicknames': ['Johnny'],  # Used in nickname comparison
            'lat': 40.7128,          # For distance comparison
            'lon': -74.0060,         # For distance comparison
            'address': '123 Main St',
            'address_state': 'NY',
            'address_post_directional': 'N',
            'address_place': 'New York',
            'address_pre_directional': 'W',
            'address_street': 'Main St',
            'address_zip_code': '10001',
            'address_occupancy_type': 'APT',
            'address_occupancy_identifier': '1A',
            'address_street_no': '123',
            'rec_id': 'rec1',
            'is_verified': True,
            'salt_key': 'salt1'
        }

        record_2 = {
            'unique_id': 2, 
            'first': 'Jon', 
            'last': 'Smith', 
            'business_name': 'apple', 
            'phone': '9898989899', 
            'dob': '1990-01-02',
            'email': 'jon.smith@example.com',
            'nicknames': ['Johnny'],  # Used in nickname comparison
            'lat': 40.7129,          # Slightly different location
            'lon': -74.0061,
            'address': '123 Main Street',
            'address_state': 'NY',
            'address_post_directional': 'N',
            'address_place': 'New York',
            'address_pre_directional': 'W',
            'address_street': 'Main Street',
            'address_zip_code': '10001',
            'address_occupancy_type': 'APT',
            'address_occupancy_identifier': '1A',
            'address_street_no': '123',
            'rec_id': 'rec2',
            'is_verified': True,
            'salt_key': 'salt2'
        }
        comparison = self.linker.inference.compare_two_records(record_1, record_2)
        sql_query = comparison.sql_used_to_create
        
        path = f'{self.cfg.save_path}/sql_queries/{self.model_name}_comparison_query.sql'
        self.fs.put(sql_query, path)
        logger.info(f'Saved SQL query to {path}')

        # Model to be logged
        model = MLflowLinkerModelFactory().create_mlflow_linker_model_from_tracking_uri(
            model_json=model_json,
            db_path=self.db_path,
            cols_to_select=ConfigLoader().format_columns_for_selection(),
            tracking_uri=self.cfg.mlflow_tracking_uri
        )

        # Model Signature
        mlflow_model_signature_dict = {
            'inputs': '[{"type": "string"}]',
            'outputs': '[{"type": "string"}]',
            'params': '[{"name": "partition", "type": "string", "default": "1", "shape": null}, {"name": "salt_key", "type": "string", "default": "1,1", "shape": null}, {"name": "prediction_path", "type": "string", "default": "/tmp/", "shape": null}]'
        }
        model_signature = ModelSignature.from_dict(mlflow_model_signature_dict)

        # Save primary_key, cols_to_select and model_json
        params = {
            'primary_key': self.cfg.primary_key,
            'cols_to_select': self.cfg.cols_to_select,
            'model_json': json.dumps(convert_to_json(model_json)),
        }
        params_dict = convert_to_json(params)
        self.mlflow_logger.log_params(params_dict)

        # Log Model to MLflow
        logger.info(f'Logging Model to MLflow with name: {self.model_name}')
        logged_model = self.mlflow_logger.log_model(
            artifact_path = self.model_name,  # Path where the model will be saved in the MLflow run
            python_model = model,  # The custom model object
            extra_pip_requirements = ['splink==4.0.7', 'duckdb==1.1.0', 'hydra-core==1.4.0.dev1'],  # Additional dependencies
            signature = model_signature,
        )
        logger.info(f"Model logged successfully. Model URI: {logged_model.model_uri}")        

        # Register Model
        logger.info(f"Registering model at: {self.mlflow_model_save_path}")
        self.mlflow_logger.register_model(
            model_uri=logged_model.model_uri,
            mlflow_model_save_path=self.mlflow_model_save_path,
            provided_model_version=self.cfg.model_version,
        )
        logger.info(f"Model registered successfully at: {self.mlflow_model_save_path}")

        # Construct Inference Schema
        ## Add match_weight and match_probability with their corresponding data types
        inference_schema = {
            'match_weight': 'DOUBLE',
            'match_probability': 'DOUBLE',
        }
  
        ## Add gamma columns with their corresponding data types
        for comp in model_json.get("comparisons", []):
            name = comp.get("output_column_name")
            inference_schema[f"gamma_{name}"] = 'INTEGER'

        ## Add cols_to_select columns with their corresponding data types
        input_table_schemas = []
        for file in self.files:
            tbl = file.name + '_table'
            tbl_schema = self.duckdb_connection.query(f"DESCRIBE {tbl}").fetchall()
            tbl_schema = {col[0] + '_l': col[1] for col in tbl_schema} if not input_table_schemas else {col[0] + '_r': col[1] for col in tbl_schema}
            input_table_schemas.append(tbl_schema)

        if len(input_table_schemas) == 1:
            input_table_schemas.append({key.replace('_l', '_r'): value for key, value in input_table_schemas[0].items()})

        final_inference_schema = {**input_table_schemas[0], **input_table_schemas[1], **inference_schema}
        logger.info(f'Inference Schema: \n{json.dumps(final_inference_schema, indent=2)}')


        # Gamma Comparisons with labels
        gamma_comparisons_with_labels = model.get_gamma_comparisons_with_labels()
        logger.info(f'Gamma Comparisons with labels: \n{json.dumps(gamma_comparisons_with_labels, indent=2)}')
        
        # Track model registration if metrics available
        if self.metrics:
            try:
                self.metrics.track_model_registration(
                    model_save_path=self.mlflow_model_save_path,
                    registry_uri=self.cfg.mlflow_registry_uri,
                )
            except Exception as e:
                logger.warning(f"Error tracking model registration: {e}")
        
        logger.info("Model successfully saved")
        return {
            "inference_schema": final_inference_schema,
            "gamma_comparisons_with_labels": gamma_comparisons_with_labels,
        }