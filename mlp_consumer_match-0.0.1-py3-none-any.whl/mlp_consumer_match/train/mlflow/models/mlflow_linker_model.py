import mlflow

class MLflowLinkerModel(mlflow.pyfunc.PythonModel):
    """
    Class for logging a Splink Linker model in MLflow.
    """
    def __init__(self, **kwargs):
        """
        Initialize the MLflowLinkerModel with the provided arguments.

        Raises: 
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLinkerModel is an abstract class") 

    
    def predict(self, context, model_input, **kwargs):
        """
        Generate predictions for input data using the trained linker model.

        Args:
            context: MLflow's context for managing the prediction lifecycle.
            model_input: Input data for the prediction (will contain processed data paths).
            params (dict): Parameters passed during inference, will include partition and output path.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLinkerModel is an abstract class") 