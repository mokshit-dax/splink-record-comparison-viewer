from mlp_consumer_match.train.mlflow.models.databricks_mlflow_linker_model import DatabricksMLflowLinkerModel
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="mlflow_linker_model_factory")

class MLflowLinkerModelFactory:
    """
    Factory class for creating MLflow linker models.
    """
    def create_mlflow_linker_model_from_tracking_uri(self, model_json: str, db_path: str, cols_to_select: list[str], tracking_uri: str):
        """
        Creates an MLflow linker model from the provided model JSON, database path, columns to select, and tracking URI.

        Args:
            model_json (str): The model JSON string.
            db_path (str): The path to the database.
            cols_to_select (list[str]): The columns to select.
            tracking_uri (str): The tracking URI for the MLflow experiment.

        Returns:
            mlflow.pyfunc.ModelInfo: Information about the logged model.
        """
        if "databricks" in tracking_uri:
            logger.info("Creating Databricks MLflow linker model")
            return DatabricksMLflowLinkerModel(
                model_json=model_json,
                db_path=db_path,
                columns=cols_to_select,
            )
        else:
            raise ValueError("Unsupported tracking URI")