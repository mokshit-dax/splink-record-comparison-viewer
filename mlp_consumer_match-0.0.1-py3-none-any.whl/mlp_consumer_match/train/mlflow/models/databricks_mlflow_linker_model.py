import json

from splink import DuckDBAPI, Linker

from mlp_consumer_match.train.mlflow.models.mlflow_linker_model import MLflowLinkerModel
from mlp_consumer_match.connection.duckdb_connection import DuckDBConnection
from mlp_consumer_match.service.sql_formatting_service import SQLFormattingService
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.dictionary_utils import DictionaryUtils

logger = get_logger(name="databricks_mlflow_linker_model")

class DatabricksMLflowLinkerModel(MLflowLinkerModel):
    """
    Class for logging a Splink Linker model in MLflow on Databricks.
    """

    def __init__(self, model_json: list, db_path: str, columns: str):
        """
        Initialize the DatabricksMLflowLinkerModel.

        Args:
            model_json (list): The JSON representation of the Splink Linker model.
            db_path (str): The path to the DuckDB database.
            columns (str): The columns to use for training.
        """
        self.model_json = model_json
        self.columns = columns
        self.db_path = db_path

    def add_salt_key_condition(self, model_json:dict, left_salt_key:str, right_salt_key:str) -> dict:
        """
        Add salt_key condition to all blocking rules.
        
        This method modifies the blocking rules in the model JSON to include salt_key conditions,
        which helps partition the data for parallel processing. The salt_key parameter is expected
        in the format "left_salt_key=X,right_salt_key=Y" where X and Y are the salt key values to match
        between the left and right tables.

        Args:
            model_json (dict): The model JSON to modify
            left_salt_key (str): The left salt key value
            right_salt_key (str): The right salt key value
        Returns:
            dict: The modified model JSON with updated blocking rules that include salt key filtering
        """
        
        for rule in model_json['blocking_rules_to_generate_predictions']:
            current_rule = rule['blocking_rule']
            # Add salt_key condition at the end of the blocking rule
            rule['blocking_rule'] = f"{current_rule} AND l.salt_key = {left_salt_key} AND r.salt_key = {right_salt_key}"

        return model_json

    def predict(self, context, model_input, params):
        """
        Generate predictions for input data using the trained linker model.

        Args:
            context: MLflow's context for managing the prediction lifecycle.
            model_input: List of json strings that represent a dictionary of the form {'name': '', 'path': '', 'pre_inference_filter':''}
            params (dict): Parameters passed during inference, including:
                - partition (str): The partition to use.
                - prediction_path (str): The path to save the predictions to.

        Returns:
            list: A list with the status of the prediction process.
        """
        partition = params.get("partition", None)
        prediction_path = params.get("prediction_path", None)
        logger.info(f"Model Input: {model_input}")
        file_objects = []
        for file_object in model_input[0]:
            file_objects.append(json.loads(file_object))
        logger.info(f"File objects: {file_objects}")
        
        logger.info(f"Columns to select : {self.columns}")

        conn = DuckDBConnection(self.db_path).get_connection()
        conn.execute(f"SET temp_directory='{self.db_path}/temp_dir/';")
        conn.execute(f"CALL load_aws_credentials()")

        # Salt Key Details
        salt_key = params.get("salt_key", None)

        if not salt_key:
            raise ValueError("Salt key is required for inference")

        # `salt_key` is a string of the form "{'left': 1},{'right': 2}" for linkage and "{'left': 1},{'left': 2}" for dedupe. 
        # So we're splitting on the comma to get the list of stringified dictionaries ["{'left': 1}", "{'right': 2}"] 
        # which is the input to merge_stringified_dicts_list().
        salt_keys_dict = DictionaryUtils.merge_stringified_dicts_list(salt_key.split(","))

        # `salt_keys_dict` is a dictionary like {"left": 1, "right": 2} for linkage, and {"left": [1, 2]} for dedupe. 
        # We're flattening all the values to [1, 2] to get the left and right salt keys.
        salt_keys_list = DictionaryUtils.flatten_dict_values_to_list(salt_keys_dict)
        if len(salt_keys_list) != 2:
            raise ValueError(f"Expected exactly 2 salt keys, but got {len(salt_keys_list)}: {salt_keys_list}")
        lk, rk = salt_keys_list

        logger.info(f"Salt Key Details: {salt_keys_dict}")
        logger.info(f"Left Salt Key: {lk}")
        logger.info(f"Right Salt Key: {rk}")

        table_names = []
        for file in file_objects:
            file_name = file.get('name')
            read_path, read_function = ConfigLoader().get_read_path_and_function_for_sql(file.get('path'), workflow_type="inference")
            filter = file.get('pre_inference_filter')

            predicate = f"{filter} AND" if filter else " WHERE"
            sk = salt_keys_dict.get(file_name)
            
            # For linkage
            if len(file_objects) > 1:
                file_filter = f"{predicate} salt_key = {sk}"

            # For Dedupe:
            else:
                file_filter = f"{predicate} (salt_key = {sk[0]} OR salt_key = {sk[1]})"

            table_name = file_name + '_table'
            table_names.append(table_name)
            
            sql_base_statement = f"CREATE TABLE __TABLE_NAME__ AS SELECT __COLS_TO_SELECT__ FROM __READ_FUNCTION__('__READ_PATH__')"
            sql_query = sql_base_statement + file_filter
            sql_query = SQLFormattingService().replace_placeholders_in_query(
                query = sql_query,
                replacement_map = {
                    '__READ_FUNCTION__': read_function,
                    '__READ_PATH__': read_path,
                    '__TABLE_NAME__': table_name,
                    '__COLS_TO_SELECT__': self.columns,
                }
            )
            conn.query(sql_query)
            logger.info(f"SQL Query executed: {sql_query}")

        # Add salt key condition to model_json
        logger.info("Adding salt key condition to model_json")
        self.model_json = self.add_salt_key_condition(self.model_json, lk, rk)

        logger.info(f"model_json = {self.model_json}")
        linker = Linker(
            input_table_or_tables=table_names,
            db_api = DuckDBAPI(connection=conn),
            settings = self.model_json,
        )

        status = None
        try:
            logger.info("Generating predictions")
            logger.info(f"Prediction output file path: {prediction_path}")
            linker.inference.predict(materialise_after_computing_term_frequencies=False).to_parquet(prediction_path, overwrite=True)
            status = "completed"
        except Exception as e:
            error_message = str(e)
            if "Table with name __splink__df_concat_with_tf does not exist!" in error_message:
                try:
                    # Extract the actual table name from the error message
                    table_name = error_message.split("Table with name ")[1].split(" does not exist!")[0]
                    # Find the temporary table with a similar name
                    temp_table = conn.execute(f"SELECT name FROM sqlite_temp_master WHERE name LIKE '{table_name}%'").fetchone()
                    if temp_table:
                        temp_table_name = temp_table[0]
                        conn.execute(f"""
                        CREATE TABLE {table_name} AS 
                        SELECT * FROM {temp_table_name}
                        """)
                        status = "completed"
                        logger.info(f"Created {table_name} table and recovered from error")
                    else:
                        raise Exception(f"Could not find a temporary table similar to {table_name}")
                except Exception as inner_e:
                    logger.error(f"Error creating {table_name} table: {str(inner_e)}")
                    status = "failed"
            else:
                logger.error(f"Error generating predictions: {error_message}")
                status = "failed"

        return [status]


    def get_gamma_comparisons_with_labels(self, return_json_str: bool = False):
        """
        Get gamma comparisons with labels from the model json with comparison names as keys and a map of levels with labels as values.
        
        Logic:
        - if level is null_level, adds the level label on key -1
        - in any other case, adds the level label on key in ascending order since the reversed order of comparisons start from else (0) onwards

        Args:
            return_json_str (bool): Whether to return the comparison map as a JSON string.

        Returns:
            dict: The gamma comparisons with labels.

        Example:
            {
                'gamma_first_name_cmp': {
                    '0': 'All other comparisons',
                    '1': 'Damerau-Levenshtein Distance on preprocessed_first <= 1',
                    '2': 'First Name Initial Match',
                    '3': 'Nicknames Match',
                    '4': 'Exact Match with term frequency adjustment on preprocessed_first ',
                    '5': 'Either Null First Name',
                    '6': 'Null First Name' # Custom Null Level Used
                },
                'gamma_address_cmp': {
                    '0': 'All other comparisons',
                    '1': 'Damerau-Levenshtein Distance on address_street <= 3',
                    '2': 'Damerau-Levenshtein Distance on address_street <= 1',
                    '3': 'Exact Match on address_street',
                    '-1': 'address is NULL' # Splink's Null Level Used
                },
                ...
            }
        """
        gamma_comparisons = {}
        for val in self.model_json['comparisons']:
            lvls = {}
            current_gamma_level = 0
            for lvl in reversed(val['comparison_levels']):
                is_null_level = lvl.get('is_null_level', False)
                label_for_charts = lvl.get('label_for_charts', 'NA')
                if is_null_level:
                    lvls["-1"] = label_for_charts
                else:
                    lvls[str(current_gamma_level)] = label_for_charts
                    current_gamma_level += 1
            gamma_comparisons["gamma_" + val['output_column_name']] = lvls
        return gamma_comparisons if not return_json_str else json.dumps(gamma_comparisons, indent=2)
