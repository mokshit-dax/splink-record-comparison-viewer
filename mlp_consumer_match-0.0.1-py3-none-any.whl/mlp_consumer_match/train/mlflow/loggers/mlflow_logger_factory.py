from mlp_consumer_match.train.mlflow.loggers.databricks_mlflow_logger import DatabricksMLflowLogger
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="mlflow_logger_factory")

class MLflowLoggerFactory:
    """
    Factory class for creating MLflow loggers.
    """
    def create_mlflow_logger_from_tracking_and_registry_uri(self, tracking_uri: str, registry_uri: str, mlflow_experiment_name: str):
        """
        Creates an MLflow logger from the tracking URI and registry URI.

        Args:
            tracking_uri (str): The tracking URI for the MLflow experiment.
            registry_uri (str): The registry URI for the MLflow experiment.
            mlflow_experiment_name (str): The name of the MLflow experiment.

        Returns:
            mlflow.client.MlflowClient: An MLflow client instance.
        
        Raises:
            ValueError: If the tracking URI or registry URI is not supported.
        """
        if "databricks" in tracking_uri or "databricks" in registry_uri:
            logger.info("Creating Databricks MLflow logger")
            return DatabricksMLflowLogger(
                tracking_uri=tracking_uri,
                registry_uri=registry_uri,
                mlflow_experiment_name=mlflow_experiment_name,
            )
        else:
            raise ValueError("Unsupported tracking and registry URI")