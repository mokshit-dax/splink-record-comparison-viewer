import mlflow

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.train.mlflow.loggers.mlflow_logger import MLflowLogger
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="databricks_mlflow_logger")

class DatabricksMLflowLogger(MLflowLogger):
    """
    Logger for logging models in Databricks MLflow.

    Contains methods for logging models and registering models
    in the MLflow model registry.
    """

    def __init__(self, tracking_uri: str, registry_uri: str, mlflow_experiment_name: str):
        """
        Initialize the DatabricksMLflowLogger with the provided arguments.

        Args:
            tracking_uri (str): The tracking URI for MLflow.
            registry_uri (str): The registry URI for MLflow.
            mlflow_experiment_name (str): The name of the MLflow experiment.
        """
        super().__init__()

        self.spark = SparkSessionFactory().get_or_create_spark_session()

        # Set tracking URI if provided
        self.tracking_uri = tracking_uri
        if self.tracking_uri:
            mlflow.set_tracking_uri(self.tracking_uri)
            logger.info(f"Tracking URI set to: {self.tracking_uri}")

        # Set registry URI if provided
        self.registry_uri = registry_uri
        if self.registry_uri:
            mlflow.set_registry_uri(self.registry_uri)
            logger.info(f"Registry URI set to: {self.registry_uri}")

        self.configure_mlflow_experiment(mlflow_experiment_name)


    def configure_mlflow_experiment(self, mlflow_experiment_name: str):
        """
        Configures the MLflow experiment.

        If the experiment already exists, it sets the experiment as the active experiment.
        Otherwise, it creates a new experiment and sets it as the active experiment.

        Args:
            mlflow_experiment_name (str): The name of the MLflow experiment.

        """
        existing_experiment = mlflow.get_experiment_by_name(mlflow_experiment_name)

        if existing_experiment:
            # If the experiment exists, set it as the active experiment
            active_run = mlflow.active_run()
            if active_run:
                logger.info(f"Active Run UUID: {active_run.info.run_id}")
                mlflow.end_run()
            else:
                logger.info("No active run.")
            logger.info(f"Using existing experiment: {mlflow_experiment_name}")
        else:
            # If the experiment doesn't exist, create it and set it as the active experiment
            mlflow.create_experiment(mlflow_experiment_name)
            logger.info(f"Created new experiment: {mlflow_experiment_name}")
        
        mlflow.set_experiment(mlflow_experiment_name)  
        logger.info(f"Set experiment to: {mlflow_experiment_name}")
        mlflow_run = mlflow.start_run(run_name=mlflow_experiment_name)
        logger.info(f"Run id: {str(mlflow_run.info.run_id)}")


    def log_model(self, python_model, artifact_path: str, **kwargs):
        """
        Log a model in MLflow.

        Args:
            python_model: The Python model to log.
            artifact_path (str): The path where the model will be saved in MLflow.
            **kwargs: Additional keyword arguments to pass to mlflow.pyfunc.log_model.

        Returns:
            mlflow.pyfunc.ModelInfo: Information about the logged model.
        """
        model_info = mlflow.pyfunc.log_model(
            artifact_path=artifact_path,
            python_model=python_model,
            **kwargs
        )
        logger.info(f"Model logged: {model_info}")
        return model_info


    def register_model(self, model_uri: str, mlflow_model_save_path: str, provided_model_version: str):
        """
        Register a model in the Databricks Unity Catalog.

        Args:
            model_uri (str): The URI of the logged model.
            mlflow_model_save_path (str): The path where the model will be saved in MLflow.
            provided_model_version (str): The version of the model.
        """
        catalog, schema, model_name = mlflow_model_save_path.split('.')
        self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema};")

        registered_model_info = mlflow.register_model(
            model_uri = model_uri,  # URI of the logged model
            name = mlflow_model_save_path  # Name under which the model will be registered
        )
        client = mlflow.MlflowClient()
        client.set_registered_model_alias(
            name = mlflow_model_save_path, 
            alias="champion",
            version = registered_model_info.version
        )
        client.set_model_version_tag(
            name=mlflow_model_save_path, 
            version=registered_model_info.version, 
            key="model_version", 
            value=provided_model_version
        )
        logger.info(f"Registered Model '{model_name}' at {mlflow_model_save_path} with following details:")
        logger.info(f"\tModel Version used for Champion: {registered_model_info.version}")
        logger.info(f"\tModel Version Tag: {provided_model_version}")


    def log_params(self, params: dict):
        """
        Log parameters in MLflow.

        Args:
            params (dict): Dictionary of parameters to log.
        """
        mlflow.log_params(params)
        logger.info(f"Logged parameters: {params}")