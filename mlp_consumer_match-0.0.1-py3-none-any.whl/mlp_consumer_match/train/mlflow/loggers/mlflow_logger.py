class MLflowLogger:
    """
    Abstract class for logging MLflow models.

    Contains methods for logging models and registering models
    in the MLflow model registry.

    """

    def __init__(self, **kwargs):
        """
        Initialize the MLflowLogger with the provided arguments.

        Raises: 
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLogger is an abstract class")

    def log_model(self, **kwargs):
        """
        Log a model in MLflow.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLogger is an abstract class")

    def log_params(self, **kwargs):
        """
        Log parameters in MLflow.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLogger is an abstract class")

    def register_model(self, **kwargs):
        """
        Register a model in the MLflow model registry.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        NotImplementedError("MLflowLogger is an abstract class")
