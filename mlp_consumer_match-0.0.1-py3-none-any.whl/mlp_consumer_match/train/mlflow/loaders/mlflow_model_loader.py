class MLflowModelLoader:
    """
    Abstract class for logging MLflow models.

    Contains methods for logging models and registering models
    in the MLflow model registry.

    """

    def __init__(self, **kwargs):
        """
        Initialize the MLflowLogger with the provided arguments.

        Raises: 
            NotImplementedError: If the method is not implemented in a subclass.
        """
        raise NotImplementedError("MLflowModelLoader is an abstract class")
    
    def get_primary_key_from_model_version(self) -> str or None:
        """
        Retrieves the 'primary_key' parameter associated with a specific MLflow model
        version stored in Databricks Unity Catalog.

        Returns:
            str or None: The value of the 'primary_key' parameter if found, otherwise None.
        """
        raise NotImplementedError("MLflowModelLoader is an abstract class")
    
    def _get_model_version_from_tag(self, **kwargs) -> str or None:
        """
        Retrieves the model version from the using model tags.

        Args:
            tag_key (str): The tag key.
            tag_value (str): The tag value.

        Returns:
            str: The model version.
        """
        raise NotImplementedError("MLflowModelLoader is an abstract class")
        
    