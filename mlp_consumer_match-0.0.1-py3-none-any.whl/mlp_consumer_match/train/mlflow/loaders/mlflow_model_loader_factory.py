from mlp_consumer_match.train.mlflow.loaders.databricks_mlflow_model_loader import DatabricksMLflowModelLoader
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="mlflow_model_loader_factory")

class MLflowModelLoaderFactory:
    """
    Factory class for creating MLflow model loaders.
    """
    def create_mlflow_model_loader_from_registry_uri(self, registry_uri: str, model_name: str, model_version_tag: str):
        """
        Creates an MLflow model loader from the registry URI.

        Args:
            registry_uri (str): The registry URI for the MLflow experiment.
            model_name (str): The name of the model.
            model_version_tag (str): The version tag of the model.

        Returns:
            mlflow.client.MlflowModelLoader: An MLflow model loader instance.
        
        Raises:
            ValueError: If the registry URI is not supported.
        """
        if "databricks" in registry_uri:
            logger.info("Creating Databricks MLflow model loader")
            return DatabricksMLflowModelLoader(
                registry_uri=registry_uri,
                model_name=model_name,
                model_version_tag=model_version_tag,
            )
        raise ValueError("Unsupported registry URI")