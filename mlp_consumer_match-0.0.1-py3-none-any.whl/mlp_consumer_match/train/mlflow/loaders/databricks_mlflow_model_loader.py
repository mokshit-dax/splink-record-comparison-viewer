import mlflow
from mlflow.tracking import MlflowClient

from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.train.mlflow.loaders.mlflow_model_loader import MLflowModelLoader
from mlp_consumer_match.utils.convert_to_json import convert_to_json

logger = get_logger(name="databricks_mlflow_model_loader")

class DatabricksMLflowModelLoader(MLflowModelLoader):
    """
    A utility class for loading MLflow models from Databricks Unity Catalog
    and retrieving associated parameters.
    """

    def __init__(self, registry_uri: str, model_name: str, model_version_tag: str):
        """
        Initializes the MLflowClient and sets the registry URI for Unity Catalog.
        """
        try:
            # Setup MLflow
            mlflow.set_registry_uri(registry_uri)
            self.client = MlflowClient()

            # Get model save path
            self.mlflow_model_save_path = ConfigLoader().get_mlflow_model_save_path(
                model_name, workflow_type="inference"
            )

            # Get Model Version Tag from Champion Model if not provided in config
            self.model_version_tag = (
                self.client.get_model_version_by_alias(
                    self.mlflow_model_save_path, "champion"
                ).tags.get("model_version", None) if not model_version_tag else model_version_tag
            )
            if not self.model_version_tag:
                raise ValueError(
                    f"Model version tag not found for model {self.mlflow_model_save_path}"
                )
            logger.info(f"Model version tag: {self.model_version_tag}")

            logger.info("DatabricksMLflowModelLoader initialized successfully")

        except Exception as e:
            logger.error(f"Error initializing DatabricksMLflowModelLoader: {e}")
            self.client = None
            self.model_version_tag = None

    def _get_model_version_from_tag(self, tag_key: str):
        """
        Get the model version from the using model tags.

        Args:
            tag_key (str): The tag key.

        Returns:
            str: The model version.
        """
        all_versions = self.client.search_model_versions(
            f"name='{self.mlflow_model_save_path}'"
        )
        matching_versions = []
        for mv in all_versions:
            mv_full = self.client.get_model_version(name=mv.name, version=mv.version)
            if mv_full.tags.get(tag_key) == self.model_version_tag:
                matching_versions.append(mv_full)

        if not matching_versions:
            raise ValueError(
                f"No model versions found with tag {tag_key}={self.model_version_tag}"
            )

        # Sort and load the latest matching version
        sorted_versions = sorted(
            matching_versions, key=lambda mv: int(mv.version), reverse=True
        )
        latest_version = sorted_versions[0].version

        return latest_version

    def get_primary_key_from_model_version(self) -> str or None:
        """
        Retrieves the 'primary_key' parameter associated with a specific MLflow model
        version stored in Databricks Unity Catalog.

        Returns:
            str or None: The value of the 'primary_key' parameter if found, otherwise None.
        """
        if not self.client:
            logger.error(
                "Error: MLflowClient not initialized. Cannot retrieve primary key."
            )
            return None
        try:
            model_version_details = self.client.get_model_version(
                name=self.mlflow_model_save_path,
                version=int(self._get_model_version_from_tag(tag_key="model_version")),
            )

            run_id = model_version_details.run_id
            logger.info(
                f"Found MLflow Run ID: {run_id} for model version {self.model_version_tag}."
            )

            run = self.client.get_run(run_id)
            parameters = run.data.params
            primary_key = parameters.get("primary_key", None)

            if primary_key:
                logger.info(
                    f"Primary Key stored in MLflow for {self.mlflow_model_save_path} version {self.model_version_tag}: {primary_key}"
                )
            else:
                logger.error(
                    f"Primary Key parameter not found in the run for {self.mlflow_model_save_path} version {self.model_version_tag}. Please ensure 'primary_key' was logged using mlflow.log_param() when this model version was created."
                )

            return primary_key

        except Exception as e:
            logger.error(f"An error occurred while retrieving primary key: {e}")
            return None

    def load_model(self, return_json: bool = False) -> dict or mlflow.pyfunc.PyFuncModel:
        """
        Loads the model from MLflow. Returns it as a JSON object if `return_json` is True,
        otherwise returns the loaded MLflow PyFuncModel.
        
        Args:
            return_json (bool): Whether to return the model as a JSON object.
        
        Returns:
            dict: The model settings as a JSON object if `return_json` is True.
            mlflow.pyfunc.PyFuncModel: The loaded MLflow model if `return_json` is False.
        """
        logger.info(f"Loading Model {'as JSON object' if return_json else 'as PyFuncModel'}")
        model_version = self._get_model_version_from_tag(tag_key="model_version")

        if not model_version:
            raise ValueError("Model version not found")
        
        logger.info(f"Fetched Model Version: {model_version}")
        
        model_uri = f"models:/{self.mlflow_model_save_path}/{model_version}"
        
        logger.info(f"Loading model from {model_uri}")        

        try:
            mlflow_linker = mlflow.pyfunc.load_model(model_uri)
            if return_json:
                return convert_to_json(mlflow_linker.unwrap_python_model().model_json.copy())
            return mlflow_linker
        except Exception as e:
            logger.error(f"Failed to load model from MLflow: {str(e)}")
            raise