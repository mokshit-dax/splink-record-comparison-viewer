import json

from pyspark.dbutils import DBUtils

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.train.train_pipeline import TrainPipeline
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.training_metrics import TrainingMetrics
from mlp_consumer_match.connection.database_api import DatabaseAPI
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger
from mlp_consumer_match.conf.train_config import TrainConfig

logger = get_logger(__name__)

def main():
    """
    Executes the record linkage model training pipeline using Splink.

    This function performs the following steps:
      1. Initializes a Spark session and retrieves job metadata
      2. Loads preprocessed training data file paths from the specified save path
      3. Configures TrainPipeline with the provided configuration, file paths, model name, and job metadata
      4. Trains the model
      5. Saves the trained model

    Returns:
        int: Returns 1 upon successful completion of the training job.
    """
    # Load config
    cfg: TrainConfig = ConfigLoader().get_or_load_config("train")

    # Get spark connection
    spark = SparkSessionFactory().get_or_create_spark_session()
    dbutils = DBUtils(spark)

    # Fetch model_name from dbutils
    model_name = dbutils.jobs.taskValues.get(taskKey='preprocess_task', key="model_name")
    
    # Initialize metrics tracker for training workflow
    metrics = TrainingMetrics(job_run_id=cfg.job_run_id, event_type="Train")
    metrics.add_metric("model_name", model_name)

    logger.info(f"Training started at: {metrics.start_time}")

    # Initialize Unity Catalog Uploader
    chart_logger = ChartLogger()
    uc_destination_path = ConfigLoader().get_uc_destination_path()
    chart_logger.set_uc_destination_path(uc_destination_path)


    # Fetch Database API connection
    database_api = DatabaseAPI(cfg.database_api_url)

    # Create Match Run Event Record in Database
    database_api.create_match_run_event(
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        event_type="Training"
    )
    logger.info("Created Match Run Event Record for Training")

    # Initialize TrainPipeline
    train_pipeline = TrainPipeline(
        cfg=cfg,
        model_name=model_name,
        metrics=metrics,
        chart_logger=chart_logger
    )
    
    # Train model
    train_output = train_pipeline.train_model()

    chart_data=chart_logger.get_charts_data(json_encode=True)
    chart_data_path=chart_logger.get_chart_paths(json_encode=True)

    logger.info(f"Chart Data: {chart_data}")
    logger.info(f"Chart Data Path: {chart_data_path}")

    # Update match run detail table
    database_api.update_match_run_detail(
        run_id=cfg.job_run_id,
        chart_data=chart_data,
        chart_data_path=chart_data_path,
        output=train_output,
    )
    logger.info("Updated Match Run Detail Record")


    # End time
    metrics.track_total_execution_time_in_seconds()

    metrics.log_metrics_summary()
    logger.info("Training Job Completed Successfully")

    logger.info(f"Training completed at: {metrics.end_time}")
    logger.info(f"Total training time: {metrics.metrics.get('total_execution_in_seconds', None)}")

    database_api.update_match_run_event(
        remove_end_slash=True,
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        metrics=json.dumps(metrics.get_metrics_summary()),
    )
    logger.info("Updated Match Run Event Record for Training")

if __name__ == "__main__":
    main()
