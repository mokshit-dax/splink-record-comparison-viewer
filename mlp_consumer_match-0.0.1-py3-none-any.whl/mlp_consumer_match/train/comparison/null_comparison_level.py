from splink.comparison_level_library import NullLevel

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class NullComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles null value comparisons between records.

    This class extends the base ComparisonLevel class and implements a null comparison
    level using Splink's NullLevel. It checks if values in the specified column are null
    in either record being compared.

    Attributes:
        comparison_level: The configured Splink NullLevel comparison object
    """
    def __init__(self):
        """
        Initialize the NullComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, column: str):
        """
        Get the configured NullLevel comparison object.

        Returns:
            The configured NullLevel comparison object
        """
        self.comparison_level = NullLevel(column)
        return self.comparison_level
