from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

from splink.comparison_level_library import AbsoluteDifferenceLevel

from typing import Union
from splink.internals.column_expression import ColumnExpression


class AbsoluteDifferenceComparisonLevel(ComparisonLevel):
    """
    A comparison level where the absolute difference between two numerical values is within a specified threshold.

    This class extends the base ComparisonLevel class and implements an absolute difference comparison
    level using Splink's AbsoluteDifferenceLevel.

    Attributes:
        comparison_level: The configured Splink AbsoluteDifferenceLevel comparison object
    """
    def __init__(self):
        """
        Initialize the AbsoluteDifferenceComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, column: Union[str, ColumnExpression], difference_threshold: Union[float, int]):
        """
        Get the configured AbsoluteDifferenceLevel comparison object.

        Args:
            column (Union[str, ColumnExpression]): Input column name or ColumnExpression.
            difference_threshold (Union[float, int]): The maximum allowed absolute difference between the two values.

        Returns:
            The configured AbsoluteDifferenceLevel comparison object
        """
        self.comparison_level = AbsoluteDifferenceLevel(column, difference_threshold)
        return self.comparison_level