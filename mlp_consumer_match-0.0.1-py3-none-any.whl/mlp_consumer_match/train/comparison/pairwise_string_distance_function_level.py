import splink.comparison_level_library as cll

from typing import Union
from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class PairwiseStringDistanceFunctionLevel(ComparisonLevel):
    """
    A comparison level class that generates pairwise string distance function comparisons.

    This class extends the base ComparisonLevel class and implements a custom comparison
    level for calculating string distances between pairs of values in array columns.
    It supports various string distance functions including Levenshtein, Damerau-Levenshtein,
    Jaro-Winkler, and Jaro distance metrics.
    """
    def __init__(self):
        """
        Initialize the PairwiseStringDistanceFunctionLevel object.
        """
        self.comparison_level = None

    def _aggregator(self) -> str:
        """
        Determine the aggregation function (max/min) based on whether higher values
        indicate more similarity for the given distance function.

        Returns:
            str: 'max' if higher values indicate more similarity, 'min' otherwise
        """
        return "max" if self._higher_is_more_similar() else "min"

    def _comparator(self) -> str:
        """
        Determine the comparison operator (>=/<) based on whether higher values
        indicate more similarity for the given distance function.

        Returns:
            str: '>=' if higher values indicate more similarity, '<=' otherwise
        """
        return ">=" if self._higher_is_more_similar() else "<="

    def _higher_is_more_similar(self) -> bool:
        """
        Check if higher values indicate more similarity for the given distance function.

        Returns:
            bool: True if higher values indicate more similarity, False otherwise

        Raises:
            KeyError: If the distance function name is not recognized
        """
        return {
            "levenshtein": False,
            "damerau_levenshtein": False,
            "jaro_winkler_similarity": True,
            "jaro_similarity": True,
        }[self.distance_function_name]
    
    def _generate_sql_conditions(self, distance_threshold: Union[int, float], additional_conditions: dict = None) -> str:
        """
        Generate additional SQL conditions to filter string pairs based on length and
        containment constraints.

        Args:
            distance_threshold (Union[int, float]): The threshold value for the distance function
            additional_conditions (dict, optional): Dictionary of additional conditions

        Returns:
            str: SQL conditions string to be ANDed with the base condition
        """
        if additional_conditions:
            additional_conditions_sql = []
            
            # Max string length constraint
            if 'max_string_length_threshold' in additional_conditions:
                val = additional_conditions['max_string_length_threshold']
                additional_conditions_sql.append(
                    f'len(pair[1]) * {val} > {distance_threshold} AND len(pair[2]) * {val} > {distance_threshold}'
                )
            
            # Containment constraint
            if 'relative_length_ratio' in additional_conditions:
                val = additional_conditions['relative_length_ratio']
                additional_conditions_sql.append(
                    f'(contains(pair[1], pair[2]) OR contains(pair[2], pair[1])) AND '
                    f'least(len(pair[1]), len(pair[2])) >= {val} * greatest(len(pair[1]), len(pair[2]))'
                )

            # Min length constraint
            if 'min_length' in additional_conditions:
                val = additional_conditions['min_length']
                additional_conditions_sql.append(f'len(pair[1]) > {val} AND len(pair[2]) > {val}')

            conditions_sql = " AND ".join(additional_conditions_sql)
            return " AND " + conditions_sql
        return ""

    def get(self, column: str, distance_function_name: str, distance_threshold: Union[int, float], additional_conditions: dict = None) -> cll.CustomLevel:
        """
        Generate a custom Splink comparison level for pairwise string distance function.

        Args:
            column (str): The column name containing arrays of strings to compare
            distance_function_name (str): The name of the distance function to use
                (one of: 'levenshtein', 'damerau_levenshtein', 'jaro_winkler_similarity', 'jaro_similarity')
            distance_threshold (Union[int, float]): The threshold value for the distance function
            additional_conditions (dict, optional): Dictionary of additional conditions:
                - max_string_length_threshold: Minimum length requirement relative to threshold
                - relative_length_ratio: Minimum length ratio between strings
                - min_length: Minimum absolute length requirement for both strings

        Returns:
            cll.CustomLevel: A custom comparison level with the constructed SQL condition
        """
        # Store the parameters as instance variables
        self.column = column
        self.distance_function_name = distance_function_name
        self.distance_threshold = distance_threshold
        self.additional_conditions = additional_conditions

        # If there are additional SQL conditions, combine them with AND
        base_condition = f"""list_{self._aggregator()}(
                        list_transform(
                            flatten(
                                list_transform(
                                    {column}_l,
                                    x -> list_transform(
                                        {column}_r,
                                        y -> [x,y]
                                    )
                                )
                            ),
                            pair -> {distance_function_name}(pair[1], pair[2]){self._generate_sql_conditions(distance_threshold, additional_conditions)}
                        )
                    ) {self._comparator()} {distance_threshold}"""

        # Generate descriptive label for charts
        suffixes = [f'{key}: {value}' for key, value in additional_conditions.items()] if additional_conditions else []
        suffix_str = ', '.join(suffixes)

        label_for_charts = f"Pairwise {distance_function_name} on {column} <= {distance_threshold} with {suffix_str if suffix_str else 'no additional conditions'}"

        return cll.CustomLevel(sql_condition=base_condition, label_for_charts=label_for_charts)