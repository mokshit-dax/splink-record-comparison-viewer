import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class JaroWinklerComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles Jaro Winkler distance comparisons between records.

    This class extends the base ComparisonLevel class and implements a Jaro Winkler distance comparison
    level using Splink's JaroWinklerLevel. It checks if values in the specified column are null
    in either record being compared.

    Attributes:
        comparison_level: The configured Splink JaroWinklerLevel comparison object
    """
    def __init__(self):
        """
        Initialize the JaroWinklerComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, column: str, distance_threshold: float, min_length: int = None, relative_length_ratio: float = None):
        """
        Generates a custom Splink comparison level for Jaro Winkler similarity between two columns,
        with optional minimum length and containment constraints.

        Args:
            column (str): The column name to compare between records.
            distance_threshold (int): Maximum allowed Jaro Winkler distance between strings.
            min_length (int, optional): Minimum allowed length of strings.
            relative_length_ratio (float, optional): Minimum required ratio between shorter and longer string lengths.
                Must be between 0 and 1. For example, 0.7 means the shorter string must be at least 70% as
                long as the longer string.

        Returns:
            splink.custom_level.CustomLevel: A custom comparison level with the constructed SQL condition.
        """
        conditions = []
        label_parts = []
        
        if min_length is not None:
            conditions.append(f'len("{column}_l") > {min_length}')
            conditions.append(f'len("{column}_r") > {min_length}')
            label_parts.append(f"min_length: {min_length}")
        
        # Apply containment constraint
        if relative_length_ratio is not None:
            conditions.append(f'(greatest(length("{column}_l"),length("{column}_r")) - least(length("{column}_l"),length("{column}_r")))/least(length("{column}_l"),length("{column}_r")) <= {relative_length_ratio}')
            label_parts.append(f"relative_length_ratio: {relative_length_ratio}")
        
        # Base condition
        conditions.append(f'jaro_winkler_similarity("{column}_l","{column}_r") >= {distance_threshold}')
        
        # Join all conditions with AND
        final_sql = "(" + " AND ".join(conditions) + ")"
        
        # Generate label for charts
        label_for_charts = f"Jaro Winkler Similarity on {column} >= {distance_threshold}"
        if label_parts:
            label_for_charts += f" with {', '.join(label_parts)}"
        
        similarity_level = cll.CustomLevel(
            sql_condition=final_sql,
            label_for_charts=label_for_charts,
        )
        return similarity_level