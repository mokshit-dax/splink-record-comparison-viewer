from splink.comparison_level_library import ElseLevel

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class ElseComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles the default "else" case for comparisons between records.

    This class extends the base ComparisonLevel class and implements an else comparison
    level using Splink's ElseLevel. It represents the default case when no other comparison
    levels match during record comparison.

    Attributes:
        comparison_level: The configured Splink ElseLevel comparison object
    """
    def __init__(self):
        """
        Initialize the ElseComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, **kwargs):
        """
        Get the configured ElseLevel comparison object.

        Returns:
            The configured ElseLevel comparison object
        """
        self.comparison_level = ElseLevel()
        return self.comparison_level