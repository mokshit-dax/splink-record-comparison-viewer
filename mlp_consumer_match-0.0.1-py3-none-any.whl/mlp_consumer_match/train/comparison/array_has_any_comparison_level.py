import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class ArrayHasAnyComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles exact value comparisons between records.

    This class extends the base ComparisonLevel class and implements an exact comparison
    level using duckdb's list_has_any function. It checks if values in the specified column are 
    exactly equal between the records being compared, with an optional minimum length
    constraint.

    Attributes:
        comparison_level: The configured Splink CustomLevel comparison object
    """
    def __init__(self):
        """
        Initialize the ArrayHasAnyComparison object.
        """
        self.comparison_level = None

    def get(self, column: str, min_length: int = 0):
        """
        Get the configured exact comparison level.

        This method creates and returns a Splink CustomLevel comparison object that checks for
        exact matches between values in the specified column, with an optional minimum length
        constraint.

        Args:
            column (str): The name of the column to compare between records
            min_length (int, optional): The minimum length requirement for the column value.
                                      If provided, only matches where the value length exceeds
                                      this threshold will be considered. Defaults to 0.

        Returns:
            The configured CustomLevel comparison object that implements the exact matching logic
        """
        similarity_level = cll.CustomLevel(
            sql_condition = f'list_has_any(list_filter("{column}_l", x -> length(x) > {min_length}), list_filter("{column}_r", y -> length(y) > {min_length}))',
            label_for_charts = f"Exact List Match" if min_length == 0 else f"Exact List Match with min length > {min_length}",
        )

        return similarity_level