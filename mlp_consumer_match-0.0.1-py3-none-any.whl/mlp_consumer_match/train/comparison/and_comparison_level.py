import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class AndComparisonLevel(ComparisonLevel):
    """
    A comparison level is the logical AND of other comparison levels. 

    This class extends the base ComparisonLevel class and implements Splink's And comparison
    level.

    Attributes:
        comparison_level: The configured Splink And comparison object
    """
    def __init__(self):
        """
        Initialize the AndComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, comparison_levels: list):
        """
        Get the configured And comparison object.

        Args:
            comparison_levels (list[dict]): A list of comparison level dictionaries.

        Returns:
            The configured And comparison object
        """

        comparison_level_creators = []
        for cmp_dict in comparison_levels:
            cmp_type, params = next(iter(cmp_dict.items()))
            
            from mlp_consumer_match.train.comparison.comparison_level_factory import ComparisonLevelFactory
            factory = ComparisonLevelFactory()
            creator = factory.get_comparison_level(cmp_type, params)

            comparison_level_creators.append(creator)

        # Combine with AND
        return cll.And(*comparison_level_creators)