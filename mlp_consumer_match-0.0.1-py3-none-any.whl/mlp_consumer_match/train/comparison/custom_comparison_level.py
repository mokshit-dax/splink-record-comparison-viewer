import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class CustomComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles custom comparisons between records.

    This class extends the base ComparisonLevel class and implements a custom comparison level using Splink's CustomLevel.

    Attributes:
        comparison_level: The configured Splink CustomLevel comparison object
    """
    def __init__(self):
        """
        Initialize the CustomComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, condition: str, label_for_charts: str = None):
        """
        Generates a custom Splink comparison level for custom SQL condition between two columns.

        Args:
            condition (str): The SQL condition to apply to the comparison.
            label_for_charts (str): A label for this level to be used in charts

        Returns:
            splink.custom_level.CustomLevel: A custom comparison level with the constructed SQL condition.
        """
        
        similarity_level = cll.CustomLevel(
            sql_condition=f'({condition})',
            label_for_charts=f"{label_for_charts}",
        )
        
        return similarity_level