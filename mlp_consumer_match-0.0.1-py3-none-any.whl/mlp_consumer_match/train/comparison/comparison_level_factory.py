from mlp_consumer_match.train.comparison.null_comparison_level import NullComparisonLevel
from mlp_consumer_match.train.comparison.exact_comparison_level import ExactComparisonLevel
from mlp_consumer_match.train.comparison.else_comparison_level import ElseComparisonLevel
from mlp_consumer_match.train.comparison.levenshtein_comparison_level import LevenshteinComparisonLevel
from mlp_consumer_match.train.comparison.damerau_levenshtein_comparison_level import DamerauLevenshteinComparisonLevel
from mlp_consumer_match.train.comparison.jaccard_comparison_level import JaccardComparisonLevel
from mlp_consumer_match.train.comparison.jaro_winkler_comparison_level import JaroWinklerComparisonLevel
from mlp_consumer_match.train.comparison.array_has_any_comparison_level import ArrayHasAnyComparisonLevel
from mlp_consumer_match.train.comparison.custom_comparison_level import CustomComparisonLevel
from mlp_consumer_match.train.comparison.absolute_difference_comparison_level import AbsoluteDifferenceComparisonLevel
from mlp_consumer_match.train.comparison.pairwise_string_distance_function_level import PairwiseStringDistanceFunctionLevel
from mlp_consumer_match.train.comparison.and_comparison_level import AndComparisonLevel


class ComparisonLevelFactory:
    def __init__(self):
        """
        Initialize the ComparisonLevelFactory with supported comparison level handlers.
        """
        self.cmp_lvls_mapping = {
            'null_level': NullComparisonLevel(),
            'exact_level': ExactComparisonLevel(),
            'else_level': ElseComparisonLevel(),
            'levenshtein_level': LevenshteinComparisonLevel(),
            'damerau_levenshtein_level': DamerauLevenshteinComparisonLevel(),
            'jaccard_level': JaccardComparisonLevel(),
            'jaro_winkler_level': JaroWinklerComparisonLevel(),
            'array_has_any_level': ArrayHasAnyComparisonLevel(),
            'custom_level': CustomComparisonLevel(),
            'absolute_difference_level': AbsoluteDifferenceComparisonLevel(),
            'pairwise_string_distance_function_level': PairwiseStringDistanceFunctionLevel(),
            'and_level': AndComparisonLevel()
        }

    def get_comparison_level(self, cmp_lvl_name, cmp_lvl_config):
        """
        returns a comparison level object based on the provided name and configuration.

        Args:
            cmp_lvl_name (str): The name of the comparison level type.
            cmp_lvl_config (dict): The configuration for the comparison level.

        Returns:
            object: The created comparison level object.
        """
        if cmp_lvl_name not in self.cmp_lvls_mapping:
            raise ValueError(f"Unsupported comparison level type: {cmp_lvl_name}")

        # Special case for and_level: pass the config as a positional argument
        if cmp_lvl_name == "and_level":
            return self.cmp_lvls_mapping[cmp_lvl_name].get(cmp_lvl_config)
        else:
            return self.cmp_lvls_mapping[cmp_lvl_name].get(**cmp_lvl_config)