import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class LevenshteinComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles Levenshtein distance comparisons between records.

    This class extends the base ComparisonLevel class and implements a  Levenshtein distance comparison
    level using Splink's LevenshteinLevel. It checks if values in the specified column are null
    in either record being compared.

    Attributes:
        comparison_level: The configured Splink LevenshteinLevel comparison object
    """
    def __init__(self):
        """
        Initialize the LevenshteinComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, column: str, distance_threshold: int, max_string_length_threshold: float = None, relative_length_ratio: float = None, min_length: int = None):
        """
        Generates a custom Splink comparison level for Levenshtein similarity between two columns,
        with optional minimum length and containment constraints.

        Args:
            column (str): The column name to compare between records.
            distance_threshold (int): Maximum allowed Levenshtein distance between strings.
            max_string_length_threshold (float, optional): If provided, minimum length of each string must be greater than distance_threshold / max_string_length_threshold.
            relative_length_ratio (float, optional): Minimum required ratio between shorter and longer string lengths (range: 0 to 1).
            min_length (int, optional): Minimum allowed length for both strings.

        Returns:
            splink.custom_level.CustomLevel: A custom comparison level with the constructed SQL condition.
        """
        conditions = []
        label_parts = []
        
        # Apply minimum length constraint
        if max_string_length_threshold is not None:
            conditions.append(f'len("{column}_l") * {max_string_length_threshold} > {distance_threshold}')
            conditions.append(f'len("{column}_r") * {max_string_length_threshold} > {distance_threshold}')
            label_parts.append(f"max_string_length_threshold: {max_string_length_threshold}")
        
        # Apply containment constraint
        if relative_length_ratio is not None:
            conditions.append(f'(contains("{column}_l", "{column}_r") OR contains("{column}_r", "{column}_l"))')
            conditions.append(f'least(len("{column}_l"), len("{column}_r")) >= {relative_length_ratio} * greatest(len("{column}_l"), len("{column}_r"))')
            label_parts.append(f"relative_length_ratio: {relative_length_ratio}")
        
        # Apply minimum length constraint
        if min_length is not None:
            conditions.append(f'len("{column}_l") >= {min_length}')
            conditions.append(f'len("{column}_r") >= {min_length}')
            label_parts.append(f"min_length: {min_length}")
        
        # Base condition
        conditions.append(f'levenshtein("{column}_l", "{column}_r") <= {distance_threshold}')
        
        # Join all conditions with AND
        final_sql = "(" + " AND ".join(conditions) + ")"
        
        # Generate label for charts
        label_for_charts = f"Levenshtein Distance on {column} <= {distance_threshold}"
        if label_parts:
            label_for_charts += f" with {', '.join(label_parts)}"
        
        similarity_level = cll.CustomLevel(
            sql_condition=final_sql,
            label_for_charts=label_for_charts,
        )
        return similarity_level