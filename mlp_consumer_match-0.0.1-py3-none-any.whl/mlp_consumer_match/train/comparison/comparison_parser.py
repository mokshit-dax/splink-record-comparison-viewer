import splink.comparison_library as cl

from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.train.comparison.comparison_level_factory import ComparisonLevelFactory
from mlp_consumer_match.train.comparison.predefined_comparisons.email_comparison import EmailComparison
from mlp_consumer_match.train.comparison.predefined_comparisons.date_of_birth_comparison import DateOfBirthComparison
from mlp_consumer_match.train.comparison.predefined_comparisons.distance_in_km_at_thresholds import DistanceInKMAtThresholdsComparison
from mlp_consumer_match.train.comparison.predefined_comparisons.address_comparison import AddressComparison

logger = get_logger(name="comparison_parser")

class ComparisonParser:
    """
    Parser for converting configuration-defined comparison levels into Splink comparison objects.

    This class handles the parsing and conversion of YAML-defined comparison configurations into
    Splink comparison level objects that can be used for record linkage. It supports multiple
    types of comparison levels including null, exact, and else comparisons.

    Example YAML configuration:
        comparisons:
          f_name_comparison:
            - null_level:
                column: first_lower
            - exact_level:
                column: first_lower
            - else_level:
                column: first_lower
    """

    def __init__(self):
        # Predefined comparisons
        self.predefined_comparisons = {
            'predefined_email_comparison': EmailComparison,
            'predefined_date_of_birth_comparison': DateOfBirthComparison,
            'predefined_distance_in_km_at_thresholds_comparison': DistanceInKMAtThresholdsComparison,
            'predefined_address_comparison': AddressComparison,
        }

    def _parse_comparison_levels(self, cmp_config: list):
        """
        Parse a list of comparison level configurations into Splink comparison level objects.

        Args:
            cmp_config (list): List of comparison level configurations from the YAML file.
                Each item is a dictionary with a single key-value pair where the key is
                the comparison level type and the value is its configuration.

        Returns:
            list: List of parsed Splink comparison level objects.

        Example input:
            [
                {'null_level': {'column': 'first_lower'}},
                {'exact_level': {'column': 'first_lower'}},
                {'else_level': {'column': 'first_lower'}}
            ]
        """
        parsed_cmp_lvls = []
        for cmp_lvl in cmp_config:
            # Get the comparison level function
            cmp_lvl_name, cmp_lvl_config = list(cmp_lvl.items())[0]
            cmp_lvl_function = ComparisonLevelFactory().get_comparison_level(cmp_lvl_name, cmp_lvl_config)
            logger.info(f'Comparison Level Function: {cmp_lvl_function.get_comparison_level("duckdb").as_dict()}')

            # Append the comparison level function to the list
            parsed_cmp_lvls.append(cmp_lvl_function)

        return parsed_cmp_lvls

    def parse(self, comparisons: dict):
        """
        Parse the complete comparisons configuration into Splink CustomComparison objects.

        Args:
            comparisons (dict): Dictionary of comparison configurations from the YAML file.
                Keys are comparison names and values are lists of comparison level configurations.

        Returns:
            list: List of Splink CustomComparison objects ready for use in record linkage.

        Example input:
            {
                'f_name_comparison': [
                    {'null_level': {'column': 'first_lower'}},
                    {'exact_level': {'column': 'first_lower'}},
                    {'else_level': {'column': 'first_lower'}}
                ]
            }
        """
        parsed_comparisons = []
        logger.info(f'Comparisons:')
        for cmp_name, cmp_config in comparisons.items():
            comparison = None

            logger.info(f'Comparison Level Name: {cmp_name}')

            if 'uses' in cmp_config and cmp_config['uses'] in self.predefined_comparisons:
                comparison = self.predefined_comparisons.get(cmp_config['uses'])(**cmp_config, comparison_name=cmp_name).get()

            else:
                # Get the parsed comparison levels
                parsed_cmp_lvls = self._parse_comparison_levels(cmp_config)
                comparison = cl.CustomComparison(
                    output_column_name = cmp_name,
                    comparison_description = cmp_name,
                    comparison_levels = parsed_cmp_lvls,
                )

            parsed_comparisons.append(comparison)

        return parsed_comparisons