import splink.comparison_library as cl


class EmailComparison:
    """
    Email comparison class.
    """
    def __init__(self, column: str, comparison_name: str, **kwargs):
        """
        Initialize the EmailComparison class.

        Args:
            column (str): The column name.
            comparison_name (str): The comparison name.
            **kwargs: Additional keyword arguments.
        """
        kwargs.pop('uses')
        self.cmp = cl.EmailComparison(col_name=column, **kwargs)
        self.comparison_name = comparison_name

    def get(self) -> cl.CustomComparison:
        """
        Get the comparison.

        Returns:
            cl.CustomComparison: The comparison.
        """
        return cl.CustomComparison(
            output_column_name=self.comparison_name,
            comparison_description=self.comparison_name,
            comparison_levels=self.cmp.get_configured_comparison_levels()
        )