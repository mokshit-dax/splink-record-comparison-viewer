import splink.comparison_library as cl


class DateOfBirthComparison:
    """
    Date of birth comparison class.
    """
    def __init__(self, column: str, input_is_string: bool, comparison_name: str, **kwargs):
        """
        Initialize the DateOfBirthComparison class.

        Args:
            column (str): The column name.
            input_is_string (bool): Whether the input is a string.
            comparison_name (str): The comparison name.
            **kwargs: Additional keyword arguments.
        """
        kwargs.pop('uses')
        self.cmp = cl.DateOfBirthComparison(col_name=column, input_is_string=input_is_string, **kwargs)
        self.comparison_name = comparison_name

    def get(self) -> cl.CustomComparison:
        """
        Get the comparison.

        Returns:
            cl.CustomComparison: The comparison.
        """
        return cl.CustomComparison(
            output_column_name=self.comparison_name,
            comparison_description=self.comparison_name,
            comparison_levels=self.cmp.get_configured_comparison_levels()
        )