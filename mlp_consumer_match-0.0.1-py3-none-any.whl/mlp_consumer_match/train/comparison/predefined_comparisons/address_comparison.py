import splink.comparison_library as cl
from omegaconf.listconfig import ListConfig

from mlp_consumer_match.train.comparison.custom_comparison_level import CustomComparisonLevel
from mlp_consumer_match.train.comparison.null_comparison_level import NullComparisonLevel
from mlp_consumer_match.train.comparison.else_comparison_level import ElseComparisonLevel
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)

class AddressComparison:
    """
    Address Comparison Class.
    Following comparisons are performed on the columns for <column>:
    1. <column>_street_no : Exact Match
    2. <column>_street : Exact Match or Damerau-Levenshtein at specified thresholds
    3. <column>_zip_code : Exact Match
    4. <column>_pre_directional : Exact Match or Null-NotNull Match
    5. <column>_post_directional : Exact Match or Null-NotNull Match
    6. <column>_occupancy_type : Exact Match or Null-NotNull Match
    7. <column>_occupancy_identifier : Exact Match or Null-NotNull Match
    8. <column>_place : Exact Match or Null-NotNull Match
    9. <column>_state : Exact Match or Null-NotNull Match
    
    Args:
        column (str): The column name
        damerau_levenshtein_at_thresholds (list[int]): The damerau_levenshtein_at_thresholds
        comparison_name (str): The comparison name
        **kwargs: Additional keyword arguments
    """
    def __init__(self, column: str, damerau_levenshtein_at_thresholds: list[int], comparison_name: str, **kwargs):
        """
        Initialize the AddressComparison object. Returns a CustomComparison object.

        Args:
            column (str): The column name
            damerau_levenshtein_at_thresholds (list[int]): The damerau_levenshtein_at_thresholds
            comparison_name (str): The comparison name
            **kwargs: Additional keyword arguments
        """
        logger.info(f"Creating Address Comparison '{comparison_name}' for column: {column}")
        self.column = column
        self.comparison_name = comparison_name
        self.damerau_levenshtein_at_thresholds = damerau_levenshtein_at_thresholds

    def get(self):
        """
        Returns a CustomComparison object.

        Returns:
            cl.CustomComparison: A CustomComparison object.
        """

        self.__validate()
        
        return cl.CustomComparison(
            output_column_name = self.comparison_name,
            comparison_description = self.comparison_name,
            comparison_levels = [
                NullComparisonLevel().get(column = self.column),
                CustomComparisonLevel().get(
                    condition = self.__get_query(f"{self.column}_street_l = {self.column}_street_r"),
                    label_for_charts = f"Exact Match on {self.column}_street"
                ),
                *[
                    CustomComparisonLevel().get(
                        condition = self.__get_query(f"damerau_levenshtein({self.column}_street_l, {self.column}_street_r) <= {threshold}"),
                        label_for_charts = f"Damerau-Levenshtein Distance on {self.column}_street <= {threshold}"
                    ) for threshold in self.damerau_levenshtein_at_thresholds
                ],
                ElseComparisonLevel().get()
            ]
        )
    

    def __validate(self):
        """
        Validate the input parameters.

        Raises:
            ValueError: If damerau_levenshtein_at_thresholds is not a list of integers.
        """
        if self.damerau_levenshtein_at_thresholds and not isinstance(self.damerau_levenshtein_at_thresholds, ListConfig):
            raise ValueError("damerau_levenshtein_at_thresholds must be a list")
        if self.damerau_levenshtein_at_thresholds and not all(isinstance(i, int) for i in self.damerau_levenshtein_at_thresholds):
            raise ValueError("damerau_levenshtein_at_thresholds must be a list of integers")
        if self.damerau_levenshtein_at_thresholds == []:
            logger.warning("'damerau_levenshtein_at_thresholds' is empty. No Damerau-Levenshtein comparison levels will be added.")
        logger.info("Finished Validating Address Comparison Parameters")


    def __get_query(self, sql_condition_for_street: str):
        """
        Get the query for the comparison.

        Args:
            sql_condition_for_street (str): The SQL condition for street

        Returns:
            str: The query for the comparison
        """
        return f'''
            ({self.column}_street_no_l = {self.column}_street_no_r)
            AND ({sql_condition_for_street})
            AND ({self.column}_zip_code_l = {self.column}_zip_code_r)
            AND (
                ({self.column}_pre_directional_l IS NULL OR {self.column}_pre_directional_r IS NULL)
                OR ({self.column}_pre_directional_l = {self.column}_pre_directional_r)
            ) 
            AND (
                ({self.column}_post_directional_l IS NULL OR {self.column}_post_directional_r IS NULL)
                OR ({self.column}_post_directional_l = {self.column}_post_directional_r)
            )
            AND (
                ({self.column}_occupancy_type_l IS NULL OR {self.column}_occupancy_type_r IS NULL)
                OR ({self.column}_occupancy_type_l = {self.column}_occupancy_type_r)
            )
            AND (
                ({self.column}_occupancy_identifier_l IS NULL OR {self.column}_occupancy_identifier_r IS NULL)
                OR ({self.column}_occupancy_identifier_l = {self.column}_occupancy_identifier_r)
            )
            AND (
                ({self.column}_place_l IS NULL OR {self.column}_place_r IS NULL)
                OR ({self.column}_place_l = {self.column}_place_r)
            )
            AND (
                ({self.column}_state_l IS NULL OR {self.column}_state_r IS NULL)
                OR ({self.column}_state_l = {self.column}_state_r)
            )'''