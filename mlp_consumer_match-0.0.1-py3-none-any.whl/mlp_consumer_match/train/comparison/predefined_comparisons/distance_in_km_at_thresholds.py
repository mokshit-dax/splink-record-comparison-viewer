import splink.comparison_library as cl


class DistanceInKMAtThresholdsComparison:
    """
    Distance in KM at thresholds comparison class.
    """
    def __init__(self, latitude_column: str, longitude_column: str, km_thresholds: list, comparison_name: str, **kwargs):
        """
        Initialize the DistanceInKMAtThresholdsComparison class.

        Args:
            latitude_column (str): The latitude column name.
            longitude_column (str): The longitude column name.
            km_thresholds (list): The km thresholds.
            comparison_name (str): The comparison name.
            **kwargs: Additional keyword arguments.
        """
        kwargs.pop('uses')
        self.cmp = cl.DistanceInKMAtThresholds(lat_col=latitude_column, long_col=longitude_column, km_thresholds=km_thresholds, **kwargs)
        self.comparison_name = comparison_name

    def get(self) -> cl.CustomComparison:
        """
        Get the comparison.

        Returns:
            cl.CustomComparison: The comparison.
        """
        return cl.CustomComparison(
            output_column_name=self.comparison_name,
            comparison_description=self.comparison_name,
            comparison_levels=self.cmp.get_configured_comparison_levels()
        )