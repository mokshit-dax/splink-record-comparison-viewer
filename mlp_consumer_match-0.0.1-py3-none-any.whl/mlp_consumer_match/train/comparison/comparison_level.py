class ComparisonLevel:
    """
    Base class for comparison levels in the matching process.
    """
    def __init__(self):
        """
        Initialize the ComparisonLevel object.
        """
        pass

    def get(self, **kwargs):
        """
        Get the configured comparison level.

        Returns:
            The configured comparison level object
        """
        return NotImplementedError("ComparisonLevel is an abstract class")