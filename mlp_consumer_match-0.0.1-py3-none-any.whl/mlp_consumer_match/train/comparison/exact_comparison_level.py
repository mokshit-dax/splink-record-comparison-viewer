import splink.comparison_level_library as cll

from mlp_consumer_match.train.comparison.comparison_level import ComparisonLevel

class ExactComparisonLevel(ComparisonLevel):
    """
    A comparison level class that handles exact value comparisons between records.

    This class extends the base ComparisonLevel class and implements an exact comparison
    level using Splink's CustomLevel. It checks if values in the specified column are 
    exactly equal between the records being compared, with an optional minimum length
    constraint.

    Attributes:
        comparison_level: The configured Splink CustomLevel comparison object

    Example:
        exact_level = ExactComparisonLevel()
        comparison = exact_level.get(column="name", min_length=2, term_frequency_adjustments=True)
        # Creates a comparison that checks if name_l = name_r AND length(name_l) > 2 with term frequency adjustments
    """
    def __init__(self):
        """
        Initialize the ExactComparisonLevel object.
        """
        self.comparison_level = None

    def get(self, column: str, min_length: int = None, term_frequency_adjustments: bool = False):
        """
        Get the configured exact comparison level.

        This method creates and returns a Splink CustomLevel comparison object that checks for
        exact matches between values in the specified column, with an optional minimum length
        constraint.

        Args:
            column (str): The name of the column to compare between records
            min_length (int, optional): The minimum length requirement for the column value.
                                      If provided, only matches where the value length exceeds
                                      this threshold will be considered. Defaults to None.
            term_frequency_adjustments (bool, optional): Whether to apply term frequency
                                                        adjustments to the comparison. Defaults to False.

        Returns:
            The configured CustomLevel comparison object that implements the exact matching logic
        """
        condition = '' if not min_length else f' AND length("{column}_l") > {min_length}'

        self.comparison_level = cll.CustomLevel(
            sql_condition = f'"{column}_l" = "{column}_r" {condition}',
            label_for_charts = f"Exact Match {'with term frequency adjustment' if term_frequency_adjustments else ''} on {column} {'with min length > ' + str(min_length) if min_length else ''}"
        ).configure(tf_adjustment_column=column if term_frequency_adjustments else None)
        
        return self.comparison_level
