from pyspark.sql import SparkSession
import argparse

def main():
  print("Hello World!")
  spark = SparkSession.builder.getOrCreate()
  parser = argparse.ArgumentParser()
  parser.add_argument("--test")
  args = parser.parse_args()
  print(args)

if __name__ == '__main__':
  main()
