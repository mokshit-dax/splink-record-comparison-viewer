import time
from splink import DuckDBAPI, Linker

from mlp_consumer_match.connection.duckdb_connection import DuckDBConnection
from mlp_consumer_match.conf.cluster_config import ClusterConfig
from mlp_consumer_match.cluster.cluster import Cluster
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.train.mlflow.loaders.mlflow_model_loader_factory import MLflowModelLoaderFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger

from mlp_consumer_match.conf.config_loader import ConfigLoader

logger = get_logger(name="cluster_pipeline")

class ClusterPipeline(Cluster):
    def __init__(self, cfg: ClusterConfig, preprocessed_file: str, preprocessed_table_name: str, db_path_prefix: str, metrics=None):
        self.cfg = cfg
        self.preprocessed_file = preprocessed_file
        self.preprocessed_table_name = preprocessed_table_name
        self.db_path_prefix = db_path_prefix
        self.metrics = metrics
        
        self.model_name = self.cfg.model_name
        self.job_run_id = self.cfg.job_run_id
        self.output_path = ConfigLoader().get_cluster_base_path()
        self.mlflow_registry_uri = self.cfg.mlflow_registry_uri
        self.model_save_path = self.cfg.model_save_path
        self.mlflow_model_save_path = f'{self.cfg.model_save_path}.{self.model_name}'
        
        # DuckDB Details
        self.db_path = f'{self.db_path_prefix}{self.model_name}_db.db'
        self.duckdb_connection = DuckDBConnection(self.db_path).get_connection()
        self.db_api = DuckDBAPI(connection=self.duckdb_connection)
        self.duckdb_connection.execute("CALL load_aws_credentials();")

        # FileSystem
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(self.cfg.save_path)

        # MLFlow Model Loader
        self.mlflow_model_loader = (
            MLflowModelLoaderFactory().create_mlflow_model_loader_from_registry_uri(
                registry_uri=self.cfg.mlflow_registry_uri,
                model_name=self.cfg.model_name,
                model_version_tag=self.cfg.model_version,
            )
        )

    def setup_database(self):
        """
        Sets up the DuckDB database by creating necessary tables.

        This method creates a table for the preprocessed data and a test table for input data.
        If the tables already exist, they will not be recreated.
        """
        logger.info(f"Creating table {self.preprocessed_table_name} in DuckDB.")
        try:
            read_path, read_function = ConfigLoader().get_read_path_and_function_for_sql(self.preprocessed_file, workflow_type="inference")
            self.duckdb_connection.query(
                f"CREATE TABLE IF NOT EXISTS {self.preprocessed_table_name} AS SELECT * FROM {read_function}('{read_path}')"
            )
            logger.info(f"Preprocessed table created: {self.preprocessed_table_name}")

        except Exception as e:
            logger.error(f"Failed to set up database: {str(e)}")
            raise
    
    def load_prediction_data(self, prediction_path:str):
        """
        Loads the prediction data from the specified path.

        Args:
            prediction_path (str): The path to the prediction data.

        Returns:
            prediction_data: The loaded prediction data in a format suitable for Splink.
        """
        try:
            read_path, read_function = ConfigLoader().get_read_path_and_function_for_sql(prediction_path, workflow_type="inference")
            prediction_data = self.db_api.sql_to_splink_dataframe_checking_cache(
                f"select * from {read_function}('{read_path}')",
                output_tablename_templated="__splink__df_predict"
            )
            logger.info("Prediction data loaded successfully.")
            return prediction_data
        except Exception as e:
            logger.error(f"Failed to load prediction data: {str(e)}")
            raise

    def save_clustered_results(self, clustered_data_table_name: str, cluster_path: str):
        """
        Saves the clustered results to a specified path in Parquet format.

            clustered_data_table_name (str): The name of the table in db containing the clustered data.
            cluster_path (str): The file path where the clustered results will be saved.

        This method attempts to save the clustered data in Parquet format to the specified s3 output path.
        If the operation fails, an error is logged and the exception is raised.
        """

        try:
            self.duckdb_connection.query(
                f"COPY {clustered_data_table_name} TO '{cluster_path}'"
            )
            logger.info(f"Saved clustered results to: {cluster_path}")
        except Exception as e:
            logger.error(f"Failed to save clustered results: {str(e)}")
            raise

    def run_clustering(self, bucket_name: str, threshold_match_probability: str):
        """
        Executes the clustering process for the specified bucket.

        This method orchestrates the loading of data, model, and execution of clustering.

        Args:
            bucket_name (str): The name of the bucket for which clustering is to be performed.

        Returns:
            None: The method saves the clustered results to a specified path.
        """
        
        logger.info(f"Running clustering for bucket: {bucket_name}")
        prediction_path = f"{ConfigLoader().get_bucket_path(bucket_name)}/"
        cluster_path = ConfigLoader().get_cluster_bucket_path_with_filename(bucket_name)

        # Create Directory
        self.fs.mkdir(f"{ConfigLoader().get_cluster_bucket_path(bucket_name)}/")
        logger.info(f"Created directory: {ConfigLoader().get_cluster_bucket_path(bucket_name)}/")

        folders = self.fs.ls(f"{ConfigLoader().get_cluster_base_path()}/")
        logger.info(f"Folders in {ConfigLoader().get_cluster_base_path()}/: {folders}")

        # Setup database
        self.setup_database()
        
        # Load model settings
        model_settings = self.mlflow_model_loader.load_model(return_json=True)
        logger.info("Model loaded successfully.")

        # Initialize linker
        linker = Linker(
            input_table_or_tables = f"{self.preprocessed_table_name}",
            db_api = DuckDBAPI(connection=self.duckdb_connection),
            settings = model_settings,
        )

        # Load prediction data
        logger.info(f"Loading predictions from path: {prediction_path}")
        prediction_data = self.load_prediction_data(prediction_path)

        # Perform clustering
        logger.info("Performing clustering.")
        start_time = time.time()
        
        clustered_data = linker.clustering.cluster_pairwise_predictions_at_threshold(
            prediction_data,
            threshold_match_probability= threshold_match_probability
        )
        
        end_time = time.time()
        clustering_time = end_time - start_time
        
        if self.metrics:
            self.metrics.add_metric("cluster_execution_time", round(clustering_time, 2))

        # Save the results
        self.save_clustered_results(clustered_data.physical_name, cluster_path)
        logger.info(f"Clustered results saved to: {cluster_path}")

