from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.cluster.cluster_pipeline import ClusterPipeline
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.inference_metrics import InferenceMetrics
from mlp_consumer_match.connection.database_api import DatabaseAPI
import json

logger = get_logger(__name__)

def main():
    """
    Main function to execute the clustering job.

    This function initializes the Spark session, fetches job parameters from the configuration,
    retrieves preprocessed files from the specified path, and runs the clustering pipeline.

    Raises:
        Exception: If multiple input files are found in the specified directory or if there is an error
                   fetching preprocessed files.
    """
    # Load config
    cfg = ConfigLoader().get_or_load_config("cluster")
    # Initialize metrics tracker
    metrics = InferenceMetrics(job_run_id=cfg.job_run_id, event_type="Cluster")
    metrics.add_metric("model_name", cfg.model_name)

    logger.info(f"Clustering started at: {metrics.start_time}")

    # Fetch Database API connection
    database_api = DatabaseAPI(cfg.database_api_url)

    # Create Match Run Event Record in Database
    database_api.create_match_run_event(
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        event_type="Cluster",
    )
    logger.info("Match Run Event Record created in Database")

    # Get File System
    fs = FileSystemFactory().create_file_system_from_path_prefix(cfg.save_path)

    # Get file names from path using file system with path as save_path/model_name/date_partition/preprocessed/job_run_id/
    try:
        files = fs.ls(f"{ConfigLoader().get_preprocess_path()}/")
        logger.info(f"Files found: {files}")
        if len(files) > 1:
            logger.error("Multiple input files are present.")
            raise Exception("Multiple input files found. Please ensure only one file is present in the directory.")
        
        # preprocessed_file = files[0].path + f"*.parquet"  # Assign the single file found
        preprocessed_file = files[0].path
        preprocessed_table_name = files[0].name + '_table'
        db_path_prefix = fs.db_path_prefix
        logger.info(f"Preprocessed file: {preprocessed_file}")
        logger.info(f"Preprocessed table name: {preprocessed_table_name}")
        logger.info(f"DB Path Prefix: {db_path_prefix}")

    except Exception as e:
        logger.error(f"Error fetching preprocessed files: {str(e)}")
        metrics.add_metric("error", str(e))
        metrics.log_metrics_summary()
        raise
    
    logger.info(f"File paths: {files}")

    # Initialize Clustering Pipeline
    cluster_pipeline = ClusterPipeline(
        cfg,
        preprocessed_file, 
        preprocessed_table_name,
        db_path_prefix,
        metrics=metrics
    )
    
    bucket_info = cfg.bucket_name.split(":")
    bucket, threshold_match_probability = bucket_info[0], float(bucket_info[1])
    
    # Run predict on the model and save results
    result = cluster_pipeline.run_clustering(
        bucket, 
        threshold_match_probability
    )

    assert "failed" not in str(result).lower()
    
    metrics.track_total_execution_time_in_seconds()
    metrics.log_metrics_summary()
    
    logger.info(f"Clustering completed at: {metrics.end_time}")
    logger.info(f"Total clustering time: {metrics.metrics.get('total_execution_in_seconds', None)}")

    database_api.update_match_run_event(
        remove_end_slash=True,
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        metrics=json.dumps(metrics.get_metrics_summary()),
        )
    logger.info("Match Run Event Record updated in Database")
    
    logger.info("Clustering Job Completed Successfully")

if __name__ == "__main__":
    main()
