import json

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.metrics.inference_metrics import InferenceMetrics
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.file_system.file_system_platform import FileSystemPlatform
from mlp_consumer_match.train.mlflow.loaders.mlflow_model_loader_factory import (
    MLflowModelLoaderFactory,
)
from mlp_consumer_match.connection.database_api import DatabaseAPI

logger = get_logger(name="join_clustered_buckets")


class JoinClusters:
    """
    The `JoinClusters` class is a utility class for joining multiple cluster buckets.

    Args:
        output_folder (str, optional): The name of the output folder to stored joined cluster in. Defaults to "matchai_output".
        cluster_id_column (str, optional): The name of the cluster id column given by Splink. Defaults to "cluster_id".
    """

    def __init__(
        self,
        output_folder="matchai_output",
        cluster_id_column="cluster_id",
    ):

        self.spark = SparkSessionFactory().get_or_create_spark_session()
        self.cfg = ConfigLoader().get_or_load_config("inference")
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(
            self.cfg.save_path
        )

        self.mlflow_model_loader = (
            MLflowModelLoaderFactory().create_mlflow_model_loader_from_registry_uri(
                registry_uri=self.cfg.mlflow_registry_uri,
                model_name=self.cfg.model_name,
                model_version_tag=self.cfg.model_version,
            )
        )

        self.primary_key = self.mlflow_model_loader.get_primary_key_from_model_version()
        self.cluster_id_column = cluster_id_column

        self.bucket_queries = ConfigLoader().get_bucket_queries()
        self.joined_bucket_path = (
            f"{ConfigLoader().get_cluster_bucket_path(output_folder)}/"
        )
        logger.info(f"Joined bucket path: {self.joined_bucket_path}")

    def join_buckets(self, metrics=None):
        """
        Join the buckets on primary key.

        Args:
            metrics: Optional metrics tracker for logging distinct ID counts

        Returns:
            DataFrame: The joined DataFrame.
        """
        buckets = self._fetch_bucket_data()
        logger.info(f"Buckets to be joined: {buckets}")

        files = self.fs.ls(f"{ConfigLoader().get_preprocess_path()}/")
        logger.info(f"Files found: {files}")
        if len(files) > 1:
            logger.error("Multiple input files are present.")
            raise Exception("Multiple input files found. Please ensure only one file is present in the directory.")
        
        preprocessed_file_path = files[0].path + f"*.parquet"  # Assign the single file found
        logger.info(f"Preprocessed file: {preprocessed_file_path}")

        # first bucket will be the preprocessed file, inner join all buckets over this file
        preprocessed_file = self.fs.read_as_spark_dataframe(preprocessed_file_path)

        if buckets:
            joined_df = self._join_for_each_bucket(buckets, preprocessed_file)
        else:
            logger.info("No buckets found, no join performed.")
            return preprocessed_file

        # Log distinct ID counts for each bucket
        if metrics:
            bucket_id_columns = [f"{bucket}_id" for bucket in buckets.keys()]
            metrics.track_bucket_id_counts(joined_df, bucket_id_columns)

        return joined_df

    def _join_for_each_bucket(self, buckets, joined_df):
        """
        Join the buckets on primary key.

        Args:
            buckets (dict): A dictionary of bucket names and their corresponding DataFrames.
            joined_df (DataFrame): The DataFrame to join the buckets on.

        Returns:
            DataFrame: The joined DataFrame.
        """
        cols_to_select = [self.cluster_id_column, self.primary_key]

        # Iterate over all buckets
        for bucket_name, bucket_df_path in buckets.items():
            try:
                current_df = self.fs.read_as_spark_dataframe(bucket_df_path).select(
                    *cols_to_select
                )
                current_df = current_df.withColumnRenamed(
                    self.cluster_id_column, f"{bucket_name}_id"
                )

                joined_df = joined_df.join(current_df, on=self.primary_key, how="inner")

            except Exception as e:
                logger.error(f"Error joining bucket '{bucket_name}': {e}")
                joined_df = joined_df.withColumn(f"{bucket_name}_id", F.col(self.primary_key))
                continue

        return joined_df

    def _fetch_bucket_data(self):
        """
        Fetch the bucket data paths.

        Returns:
            dict: A dictionary of bucket names and their corresponding data paths.
        """
        buckets = {}

        for bucket_name, _ in self.bucket_queries.items():
            buckets[bucket_name] = ConfigLoader().get_cluster_bucket_path(bucket_name)

        return buckets

    def save_joined_buckets(self, joined_df):
        """
        Save the joined buckets to the given path.

        Args:
            joined_df (DataFrame): The joined DataFrame.
        """
        self.fs.write_spark_dataframe(
            df=joined_df,
            raw_path=self.joined_bucket_path,
        )
        logger.info(f"Joined buckets stored at: {self.joined_bucket_path}")

        # Check for Delta Share configuration in YAML
        if hasattr(self.cfg, 'share_name') and self.cfg.share_name:
            try:
                # Create Delta Share file system
                delta_fs = FileSystemFactory().create_file_system_from_platform(FileSystemPlatform.DELTA_SHARE)
                
                # Write to Delta Share using model_save_path as catalog.schema and with a descriptive table name
                table_name = f"{self.cfg.job_run_id}_matchai_output"
                full_path = f"{self.cfg.share_name}.{self.cfg.model_save_path}.{table_name}"
                
                delta_fs.write_spark_dataframe(
                    df=joined_df,
                    raw_path=full_path,
                    file_format="delta",
                    model_name=self.cfg.model_name
                )
                
                logger.info(f"Joined buckets also stored in Delta Share: {self.cfg.share_name}")
            except Exception as e:
                logger.error(f"Failed to write to Delta Share: {e}")

def main():
    """
    Entry point for the join_clusters job.
    """
    try:
        # Load config
        cfg = ConfigLoader().get_or_load_config("inference")

        metrics = InferenceMetrics(
            job_run_id=cfg.job_run_id, event_type="Join Clustered Buckets"
        )
        logger.info(f"Join Clusters started at: {metrics.start_time}")

        # Fetch Database API connection
        database_api = DatabaseAPI(cfg.database_api_url)

        # Create Match Run Event Record in Database
        database_api.create_match_run_event(
            run_id=cfg.job_run_id,
            task_id=cfg.task_run_id,
            event_type="Join Clustered Buckets"
        )
        logger.info("Created Match Run Event Record")

        join_clusters = JoinClusters()
        joined_df = join_clusters.join_buckets(metrics=metrics)
        logger.info("Buckets joined successfully")
        join_clusters.save_joined_buckets(joined_df)

        metrics.track_dataset_stats(
            dataset_name="joined_bucket_output",
            row_count=joined_df.count(),
            column_count=len(joined_df.columns),
        )

        # End time
        metrics.track_total_execution_time_in_seconds()
        
        metrics.log_metrics_summary()
        logger.info(f"Join Clusters completed at: {metrics.end_time}")
        logger.info(f"Total Time: {metrics.metrics.get('total_execution_in_seconds', None)}")

        database_api.update_match_run_event(
            remove_end_slash=True,
            run_id=cfg.job_run_id,
            task_id=cfg.task_run_id,
            metrics=json.dumps(metrics.get_metrics_summary()),
        )
        logger.info("Updated Match Run Event Record")

        logger.info("Join Clusters Job Completed Successfully")
    except Exception as e:
        logger.error(f"Error in join_clusters job: {str(e)}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
