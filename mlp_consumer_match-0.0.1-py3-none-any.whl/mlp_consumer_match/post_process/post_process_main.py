import time
import datetime as dt
import json

from pyspark.dbutils import DBUtils

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.post_process.post_process_pipeline import PostProcessPipeline
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.inference_metrics import InferenceMetrics
from mlp_consumer_match.connection.database_api import DatabaseAPI

logger = get_logger(__name__)

def main():
    """
    Executes the post process pipeline for a matchai model.

    This function performs the following steps:
      1. Retrieves Spark connection and job metadata.
      2. Loads preprocessed data file paths from the specified save path.
      3. Initializes PostProcessPipeline with the provided configuration, file paths, model name, and job metadata.
      4. Runs post process on the predicted results and saves the results to output path.
      5. Sets Clusters names in task values.
    """
    # Load config
    logger.info("Loading configuration for post process")
    cfg = ConfigLoader().get_or_load_config("inference")

    # Get spark connection
    spark = SparkSessionFactory().get_or_create_spark_session()
    dbutils = DBUtils(spark)

    # Fetch model_name and job_run_id from dbutils
    model_name = dbutils.jobs.taskValues.get(taskKey='preprocess_task', key="model_name")
    job_run_id = dbutils.jobs.taskValues.get(taskKey='preprocess_task', key="job_run_id")
    date_partition = dbutils.jobs.taskValues.get(taskKey='preprocess_task', key="date_partition")
    logger.info(f"Load Job parameters")
    logger.info(f"model_name={model_name}")
    logger.info(f"job_run_id={job_run_id}")
    logger.info(f"date_partition={date_partition}")
    
    # Initialize metrics tracker
    metrics = InferenceMetrics(job_run_id=job_run_id, event_type="PostProcess")
    metrics.add_metric("model_name", model_name)

    logger.info(f"Post Process started at: {metrics.start_time}")

    # Initialize chart logger
    chart_logger = ChartLogger()
    uc_destination_path = ConfigLoader().get_uc_destination_path(workflow_type="inference")
    chart_logger.set_uc_destination_path(uc_destination_path)

    # Fetch Database API connection
    database_api = DatabaseAPI(cfg.database_api_url)

    # Create Match Run Event Record in Database
    database_api.create_match_run_event(
        run_id=job_run_id,
        task_id=cfg.task_run_id,
        event_type="Post Process",
    )
    logger.info("Created Match Run Event Table Record for Post Process")

    # Initialize post process pipeline
    post_process_pipeline = PostProcessPipeline(
        cfg=cfg, 
        metrics=metrics,
        chart_logger=chart_logger
    )

    # Run post process
    post_process_pipeline.run()

    chart_data_path=chart_logger.get_chart_paths(json_encode=True)
    chart_data=chart_logger.get_charts_data(json_encode=True)

    logger.info(f"Chart Data: {chart_data}")
    logger.info(f"Chart Data Path: {chart_data_path}")

    # Update Match Run Detail Record with chart path for comparison viewer chart
    database_api.update_match_run_detail(
        run_id=job_run_id,
        chart_data_path=chart_data_path,
        chart_data=chart_data,
    )

    # Set Clusters names in task values
    if cfg.cluster_on:
        cluster_pairs = [f"{bucket['bucket']['name']}:{bucket['bucket']['threshold']}" for bucket in cfg.cluster_on]
        dbutils.jobs.taskValues.set(key="cluster_on", value=list(cluster_pairs))
        logger.info(f"Generated cluster pairs: {cluster_pairs}")

    # Calculate total elapsed time
    metrics.track_total_execution_time_in_seconds()
    
    # Add metrics
    metrics.log_metrics_summary()
    logger.info(f"Post process completed at: {metrics.end_time}")
    logger.info(f"Total post process time: {metrics.metrics.get('total_execution_in_seconds', None)}")

    database_api.update_match_run_event(
        remove_end_slash=True,
        run_id=job_run_id,
        task_id=cfg.task_run_id,
        metrics=json.dumps(metrics.get_metrics_summary()),
    )
    logger.info("Updated Match Run Event Table Record for Post Process")
    logger.info("Post Process Job Completed Successfully")

if __name__ == "__main__":
    main()
