import mlflow
from itertools import chain
from splink import DuckDBAPI, Linker

from pyspark.sql.functions import create_map, lit, col, when, concat_ws

from mlp_consumer_match.conf.inference_config import InferenceConfig
from mlp_consumer_match.service.sql_formatting_service import SQLFormattingService
from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.connection.duckdb_connection import DuckDBConnection
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.train.mlflow.loaders.mlflow_model_loader_factory import MLflowModelLoaderFactory
from mlp_consumer_match.utils.file_system.file_system_platform import FileSystemPlatform
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.chart.chart_logger import ChartLogger
from mlp_consumer_match.utils.chart.chart_utils import ChartUtils


logger = get_logger(name="post_process_pipeline")

class PostProcessPipeline:
    """
    This class implements the complete post-processing pipeline for the data.
    """

    def __init__(self, cfg: InferenceConfig, metrics=None, chart_logger: ChartLogger = None, chart_utils: ChartUtils=None):
        """
        Initialize the post-processing pipeline.
        Args:
            cfg: Configuration containing post-process parameters
            metrics: Metrics tracking object
            chart_logger: Chart Logger object
            chart_utils: Chart Utils object
        """
        logger.info("Initializing PostProcessPipeline")
        self.cfg = cfg
        self.metrics = metrics

        # Get File System
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(self.cfg.save_path)
        self.files = self.fs.ls(f"{ConfigLoader().get_preprocess_path()}/")
        logger.info(f"File paths: {self.files}")

        # Spark connection
        self.spark = SparkSessionFactory().get_or_create_spark_session()

        # DuckCB Connections
        self.db_path = f'{self.fs.db_path_prefix}{self.cfg.model_name}_db.db'
        self.duckdb_connection = DuckDBConnection(self.db_path).get_connection()
        self.db_api = DuckDBAPI(connection=self.duckdb_connection)
        self.duckdb_connection.execute("CALL load_aws_credentials();")

        self.mlflow_model_save_path = ConfigLoader().get_mlflow_model_save_path(self.cfg.model_name, workflow_type="inference")
        logger.info(f"Model save path: {self.mlflow_model_save_path}")

        # MLflow Details
        mlflow.set_tracking_uri(self.cfg.mlflow_tracking_uri)
        logger.info(f"MLflow tracking uri: {self.cfg.mlflow_tracking_uri}")

        # MLflow Model Loader
        self.mlflow_model_loader = MLflowModelLoaderFactory().create_mlflow_model_loader_from_registry_uri(
            registry_uri=self.cfg.mlflow_registry_uri,
            model_name=self.cfg.model_name,
            model_version_tag=self.cfg.model_version,
        )

        # Load model json
        self.model_json = self.mlflow_model_loader.load_model(return_json=True)
        logger.info(f"Successfully loaded model_json: {self.model_json}")

        # Bucketing Details
        self.bucket_queries = ConfigLoader().get_bucket_queries()

        # Output Details
        self.output_path = ConfigLoader().get_prediction_path()
        logger.info(f"Output path: {self.output_path}")

        # Clustering Details
        logger.info(f"Clustering on: {self.cfg.cluster_on}")

        # Initialize paths
        self.prediction_path = f"{ConfigLoader().get_prediction_path(include_salt_key_glob_pattern=True)}/"
        logger.info(f"Prediction path: {self.prediction_path}")

        # Initialize predictions df
        self.predictions_df = self.fs.read_as_spark_dataframe(self.prediction_path)
        logger.info(f"Prediction DataFrame columns: {self.predictions_df.columns}")
        logger.info(f"Prediction count: {self.predictions_df.count()}")

        # Initialize Chart helpers
        self.chart_logger = chart_logger
        self.chart_utils = chart_utils or ChartUtils()


    def generate_match_reason_label_for_predictions(self):
        """
        Generate match_reason for each record based on the GAMMA Level of the comparisons.
        """
        gamma_comparisons_with_labels = self.mlflow_model_loader.load_model().unwrap_python_model().get_gamma_comparisons_with_labels()
        logger.info(f"Gamma Comparisons with labels: {gamma_comparisons_with_labels}")
        
        for column, mapping in gamma_comparisons_with_labels.items():
            mapping_expr = create_map([lit(x) for x in chain(*mapping.items())])
            self.predictions_df = self.predictions_df.withColumn(f"{column}_label", when(col(column) == 0, lit(None)).otherwise(mapping_expr[col(column)]))

        label_columns = [col(cmp + "_label") for cmp in gamma_comparisons_with_labels.keys()]
        logger.info(f"Label columns generated: {label_columns}")

        self.predictions_df = self.predictions_df.withColumn("match_reason", concat_ws("; ", *label_columns))
        logger.info(f"Label columns concatenated to produce `match_reason` column")

        self.predictions_df = self.predictions_df.withColumn("match_reason", when(col("match_reason") == "", lit("NA")).otherwise(col("match_reason")))
        logger.info(f"`match_reason` column updated to replace empty strings with `NA`")

        self.predictions_df = self.predictions_df.drop(*label_columns)
        logger.info(f"Dropped label columns")
        logger.info("Match Reason Label generated for all gamma columns")


    def generate_buckets(self):
        """
        Generate buckets from the given DataFrame.
        """
        self.predictions_df.createOrReplaceTempView('predictions')
        for bucket_name, bucket_config in self.bucket_queries.items():
            bucket_sql_query = SQLFormattingService().replace_placeholders_in_query(
                bucket_config.get("sql"),
                replacement_map = {
                    '__PREDICTIONS__': 'predictions',
                }
            )
            logger.info(f"Bucket SQL query: \n{bucket_sql_query}")
            bucket_df = self.spark.sql(bucket_sql_query)
            bucket_count = bucket_df.count()
            logger.info(f"Bucket DataFrame count: {bucket_count}")
            
            # Track bucket statistics
            if self.metrics:
                self.metrics.add_metric(f"bucket_{bucket_name}_count", bucket_count)

            if bucket_count == 0:
                logger.info(f"No records found for bucket: {bucket_name}")
                logger.info(f"Skipping bucket: {bucket_name}")
                continue

            bucket_file_path = f"{ConfigLoader().get_bucket_path(bucket_name)}/"
            self.fs.write_spark_dataframe(bucket_df, bucket_file_path)
            logger.info(f"Created bucket file: {bucket_file_path}")
            
            if hasattr(self.cfg, 'share_name') and self.cfg.share_name:
                # Create Delta Share file system
                delta_fs = FileSystemFactory().create_file_system_from_platform(FileSystemPlatform.DELTA_SHARE)
                
                # Write to Delta Share using model_save_path as catalog.schema and with a descriptive table name
                table_name = f"{self.cfg.job_run_id}_bucket_{bucket_name}"
                full_path = f"{self.cfg.share_name}.{self.cfg.model_save_path}.{table_name}"

                delta_fs.write_spark_dataframe(
                    df=bucket_df,
                    raw_path= full_path,
                    file_format="delta",
                    model_name=self.cfg.model_name,  
                )

            if bucket_config.get("generate_comparison_viewer"):
                try:
                    # Generate and save charts
                    self._generate_charts(self.model_json, self.duckdb_connection, bucket_file_path, bucket_name, bucket_count, bucket_config)
                    chart_path = ConfigLoader().get_comparison_viewer_bucket_path(bucket_name)
                    logger.info(f"Comparison viewer charts saved at: {chart_path}")

                except Exception as e:
                    logger.error(f"Error processing bucket {bucket_name}: {str(e)}")
                    raise

        logger.info("Bucket generation completed successfully")

    def run(self):
        """
        Run the post process pipeline.

        This function performs the following steps:
            1. Generate match reason label for predictions.
            2. Generate buckets from the given DataFrame.
        """
        if self.metrics:
            self.metrics.add_metric("total_prediction_count", self.predictions_df.count())
            
        self.generate_match_reason_label_for_predictions()
        self.generate_buckets()

    
    def _generate_charts(
        self,
        model_json,
        duckdb_connection,
        bucket_file_path,
        bucket_name,
        bucket_count,
        bucket_config,
    ):
        """
        Generate charts for the given bucket.

        Args:
            model_json (dict): The model JSON.
            duckdb_connection (DuckDBConnection): The DuckDB connection.
            bucket_file_path (str): The path to the bucket file.
            bucket_name (str): The name of the bucket.
            bucket_count (int): Number of records in bucket.
            bucket_config (dict): The bucket config.
        """
        self.chart_utils.create_sampled_pred_table(
            duckdb_connection,
            bucket_file_path,
            bucket_count,
            bucket_name,
            bucket_config,
        )

        linker = Linker(
            input_table_or_tables=["__splink__df_predict"],
            db_api=DuckDBAPI(connection=duckdb_connection),
            settings=model_json,
        )
        splink_df = linker._db_api.table_to_splink_dataframe(
            "__splink__df_predict", "__splink__df_predict"
        )

        logger.info("Generating comparison viewer charts")
        chart_html = linker.visualisations.comparison_viewer_dashboard(
            splink_df,
            return_html_as_string=True,
            out_path=ConfigLoader().get_comparison_viewer_bucket_path(bucket_name),
            num_example_rows=bucket_config.get("num_example_rows"),
            overwrite=True,
        )

        # Log comparison viewer chart
        self.chart_logger.save_chart_to_uc(chart_html, chart_name=f"{bucket_name}_comparison_viewer.html")
        self.chart_logger.log_uc_chart_path(f"{bucket_name}_comparison_viewer.html")
        logger.info("Comparison viewer charts saved to Unity Catalog")

        chart_dict = self.chart_utils.get_comparison_viewer_chart_as_dict(linker, splink_df, bucket_config.get("num_example_rows"))
        self.chart_logger.log_chart_dict(chart_dict, chart_name=f"{bucket_name}_comparison_viewer")
        logger.info("Logged Comparison viewer JSON")

        duckdb_connection.query("DROP TABLE __splink__df_predict")
