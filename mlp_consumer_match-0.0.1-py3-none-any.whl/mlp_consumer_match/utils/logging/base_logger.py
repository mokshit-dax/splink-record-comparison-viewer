# base_logger.py
from typing import Any, Union

class BaseLogger:
    """
    Abstract base class for logger implementations.
    
    This class serves as a template for all logger implementations.
    It defines methods that must be implemented by subclasses.
    
    Methods:
        initialize(name, level, **kwargs): Configure the logger with name and level
        debug(message, **kwargs): Log a debug message
        info(message, **kwargs): Log an info message
        warning(message, **kwargs): Log a warning message
        error(message, **kwargs): Log an error message
        critical(message, **kwargs): Log a critical message
        set_level(level): Change the logging level
    """
    
    def __init__(self):
        """
        Initializes the BaseLogger class.
        
        Since this is a base class, subclasses should initialize
        their specific logging implementation in the initialize method.
        """
        pass

    def initialize(self, name: str, level: Union[int, str] = "INFO", **kwargs) -> None:
        """
        Configure the logger with specified name and level.
        
        Args:
            name: The name of the logger
            level: The logging level (can be int, string,)
            **kwargs: Additional configuration parameters
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")
    

    def debug(self, message: str, **kwargs) -> None:
        """
        Log a debug message.
        
        Args:
            message: The message to log
            **kwargs: Additional contextual information to include
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")

    def info(self, message: str, **kwargs) -> None:
        """
        Log an info message.
        
        Args:
            message: The message to log
            **kwargs: Additional contextual information to include
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")

    def warning(self, message: str, **kwargs) -> None:
        """
        Log a warning message.
        
        Args:
            message: The message to log
            **kwargs: Additional contextual information to include
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")

    def error(self, message: str, **kwargs) -> None:
        """
        Log an error message.
        
        Args:
            message: The message to log
            **kwargs: Additional contextual information to include
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")

    def critical(self, message: str, **kwargs) -> None:
        """
        Log a critical message.
        
        Args:
            message: The message to log
            **kwargs: Additional contextual information to include
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")

    def set_level(self, level: Union[int, str]) -> None:
        """
        Change the logging level.
        
        Args:
            level: The new logging level (can be int, string)
            
        Raises:
            NotImplementedError: If the method is not implemented in a subclass
        """
        raise NotImplementedError("Not Implemented")
 

# Logger Factory
_loggers = {}

def get_logger(name: str, implementation: str = "python", **kwargs) -> BaseLogger:
    if name in _loggers:
        return _loggers[name]

    if implementation.lower() == "python":
        from mlp_consumer_match.utils.logging.python_logger import PythonLogger
        logger_class = PythonLogger
    else:
        raise ValueError(f"Unknown logger implementation: {implementation}")
    
    kwargs.setdefault("suppress_noisy_logs", True)
    
    logger = logger_class()
    logger.initialize(name, **kwargs)
    _loggers[name] = logger
    return logger
