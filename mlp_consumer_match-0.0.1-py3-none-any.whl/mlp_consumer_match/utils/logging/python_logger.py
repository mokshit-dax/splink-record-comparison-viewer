import logging
from typing import Any, Union
from .base_logger import BaseLogger


class NoReceivedCommandFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return "Received command " not in record.getMessage()


class NoPythonDotEnvFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return "Python-dotenv" not in record.getMessage()


class PythonLogger(BaseLogger):
    """
    Concrete implementation of BaseLogger using Python's built-in logging module.
    """

    def __init__(self):
        super().__init__()
        self.logger: Union[logging.Logger, None] = None

    def initialize(
        self,
        name: str,
        level: Union[int, str] = logging.INFO,
        *,
        suppress_noisy_logs: bool = False,
        formatter: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream: Any = None,
        **kwargs
    ) -> None:
        """
        Initialize the Python logger.
        
        Args:
            name: Logger name
            level: Log level (e.g., logging.INFO or "INFO")
            suppress_noisy_logs: If True, applies filters for common noisy logs
            formatter: Optional formatter string
            stream: Optional stream (defaults to sys.stderr)
        """
        self.logger = logging.getLogger(name)
        if isinstance(level, str):
            level = level.upper()
            level = getattr(logging, level, logging.INFO)

        self.logger.setLevel(level)

        if not self.logger.handlers:
            handler = logging.StreamHandler(stream)
            handler.setLevel(level)
            handler.setFormatter(logging.Formatter(formatter))
            if suppress_noisy_logs:
                handler.addFilter(NoReceivedCommandFilter())
                handler.addFilter(NoPythonDotEnvFilter())

            self.logger.addHandler(handler)
        
        self.logger.propagate = False

        if suppress_noisy_logs:
            # Apply filters and levels to external noisy loggers
            noisy_loggers = ["py4j.clientserver", "dotenv"]
            for nl in noisy_loggers:
                ext_logger = logging.getLogger(nl)
                ext_logger.addFilter(NoReceivedCommandFilter())
                ext_logger.addFilter(NoPythonDotEnvFilter())
                ext_logger.setLevel(logging.WARNING)

            # Explicit level overrides
            logging.getLogger("py4j").setLevel(logging.ERROR)
            logging.getLogger("py4j.java_gateway").setLevel(logging.INFO)


    def debug(self, message: str, **kwargs) -> None:
        if self.logger:
            self.logger.debug(message, **kwargs)

    def info(self, message: str, **kwargs) -> None:
        if self.logger:
            self.logger.info(message, **kwargs)

    def warning(self, message: str, **kwargs) -> None:
        if self.logger:
            self.logger.warning(message, **kwargs)

    def error(self, message: str, **kwargs) -> None:
        if self.logger:
            self.logger.error(message, **kwargs)

    def critical(self, message: str, **kwargs) -> None:
        if self.logger:
            self.logger.critical(message, **kwargs)

    def set_level(self, level: Union[int, str]) -> None:
        if self.logger:
            if isinstance(level, str):
                level = level.upper()
                level = getattr(logging, level, logging.INFO)
            self.logger.setLevel(level)
