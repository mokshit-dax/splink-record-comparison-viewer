def convert_to_json(data):
    if isinstance(data, dict):
        return {k: convert_to_json(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_to_json(item) for item in data]
    elif isinstance(data, (str, int, float, bool)):
        return data
    elif data is None:
        return None
    else:
        try:
            return str(data)
        except Exception:
            return None