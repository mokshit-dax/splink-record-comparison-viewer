import datetime as dt
from typing import Dict, Any
import json
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="base_metrics")

class BaseMetrics:
    """
    Base class for tracking metrics across different workflows.
    This class provides common functionality for tracking metrics across task executions.
    """
    
    def __init__(self, job_run_id: str, event_type: str):
        """
        Initialize a workflow metrics tracker.
        
        Args:
            job_run_id: ID of the current job run
            event_type: Type of event being tracked (e.g., "Preprocess", "Train")
        """
        self.job_run_id = job_run_id
        self.event_type = event_type
        self.start_time = dt.datetime.now().isoformat()
        self.end_time = None
        self.metrics = {}
        logger.info(f"Started {event_type} event")
        logger.info(f"Initialized metrics tracking (job_run_id: {job_run_id})")
    
    def _end(self):
        """
        Mark the end of an event and record end time.
        """
        self.end_time = dt.datetime.now().isoformat()
        logger.info(f"Ended {self.event_type} event")
    
    def add_metric(self, metric_name: str, value: Any):
        """
        Add a metric.
        
        Args:
            metric_name: Name of the metric
            value: Value of the metric
        """
        self.metrics[metric_name] = value
        logger.debug(f"Added metric: {metric_name}={value}")
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """
        Generate a summary of all metrics collected.
        
        Returns:
            Dictionary containing all metrics
        """
        return {
            "job_run_id": self.job_run_id,
            "event_type": self.event_type,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "metrics": self.metrics
        }
    
    def log_metrics_summary(self) -> None:
        """
        Log the metrics summary as JSON.
        """
        self._end()
        summary = self.get_metrics_summary()
        
        try:
            # Use default=str to convert any non-serializable objects to strings
            json_summary = json.dumps(summary, default=str, indent=2)
            logger.info(f"Workflow metrics summary: {json_summary}")
            
        except Exception as e:
            logger.error(f"Error serializing metrics: {str(e)}")
            logger.info(f"Workflow metrics summary (non-JSON): {summary}")

    def track_total_execution_time_in_seconds(self) -> None:
        """
        Track the total execution time in seconds for the event.
        """
        start_time = dt.datetime.fromisoformat(self.start_time)
        end_time = dt.datetime.now()
        elapsed_time = end_time - start_time
        self.add_metric("total_execution_in_seconds", round(elapsed_time.total_seconds(), 2))