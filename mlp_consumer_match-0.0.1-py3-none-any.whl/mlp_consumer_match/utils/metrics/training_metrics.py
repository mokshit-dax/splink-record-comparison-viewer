from typing import Dict, Any, List, Optional

from mlp_consumer_match.utils.metrics.base_metrics import BaseMetrics
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="training_metrics")

class TrainingMetrics(BaseMetrics):
    """
    Metrics tracker for the training workflow.
    """
    def __init__(self, job_run_id: str, event_type: str):
        """
        Initialize training metrics tracker.
        
        Args:
            job_run_id: ID of the current job run
            event_type: Type of event being tracked (e.g., "Train")
        """
        super().__init__(job_run_id, event_type)
    
    def track_training_params(self, model_params: Dict[str, Any]) -> None:
        """
        Track training parameters.
        
        Args:
            model_params: Dictionary containing model parameters
        """
        if "training_params" not in self.metrics:
            self.metrics["training_params"] = {}
        
        for param_name, param_value in model_params.items():
            self.metrics["training_params"][param_name] = param_value
        
        logger.info(f"Tracked {len(model_params)} training parameters")

        
    def track_training_performance(self, metrics: Dict[str, Any]) -> None:
        """
        Track training performance metrics.
        
        Args:
            metrics: Dictionary containing performance metrics
        """
        for metric_name, metric_value in metrics.items():
            self.add_metric(metric_name, metric_value)
        
        logger.info(f"Tracked {len(metrics)} training performance metrics")

    def track_model_registration(self, model_save_path: str, registry_uri: str) -> None:
        """
        Track model registration details.
        
        Args:
            model_save_path: Save path of the registered model
            model_version: Version of the registered model
        """
        self.add_metric("model_save_path", model_save_path)
        self.add_metric("registry_uri", registry_uri)
        
        logger.info(f"Tracked model registration: {model_save_path}")