from typing import Dict, Any

from mlp_consumer_match.utils.metrics.base_metrics import BaseMetrics
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="profiling_metrics")

class ProfilingMetrics(BaseMetrics):
    """
    Metrics tracker for the profiling workflow.
    """
    def __init__(self, job_run_id: str, event_type: str):
        """
        Initialize profiling metrics tracker.
        
        Args:
            job_run_id: ID of the current job run
            event_type: Type of event being tracked (e.g., "Profile")
        """
        super().__init__(job_run_id, event_type)
    
    def track_dataset_stats(self, dataset_name: str, row_count: int, column_count: int):
        """
        Track statistics about a profiled dataset.
        
        Args:
            dataset_name: Name of the dataset
            row_count: Number of rows in the dataset
            column_count: Number of columns in the dataset
        """
        self.add_metric(f"{dataset_name}_dataset_record_count", row_count)
        self.add_metric(f"{dataset_name}_dataset_attribute_count", column_count)
        logger.info(f"Tracked dataset stats for {dataset_name}: {row_count} rows, {column_count} columns")
    
    def track_column_stats(self, dataset_name: str, column_name: str, stats: Dict[str, Any]):
        """
        Track statistics about a specific column in a dataset.
        
        Args:
            dataset_name: Name of the dataset
            column_name: Name of the column
            stats: Dictionary containing column statistics
        """
        self.add_metric(f"{dataset_name}_{column_name}_stats", stats)
        logger.info(f"Tracked column stats for {dataset_name}.{column_name}")

    def track_profiling_function(self, function_name: str, execution_time_seconds: float):
        """
        Track execution of a profiling function.
        
        Args:
            function_name: Name of the profiling function
            execution_time_seconds: Execution time in seconds
        """
        # Initialize profiling_function_time dictionary if not exists
        if "profiling_function_time" not in self.metrics:
            self.metrics["profiling_function_time"] = {}
        
        # Add the specific function execution time
        self.metrics["profiling_function_time"][function_name] = round(execution_time_seconds, 2)
        
        logger.info(f"Tracked profiling function execution {function_name}: {round(execution_time_seconds, 2)} seconds")