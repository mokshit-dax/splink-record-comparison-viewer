from typing import Dict, Any, List

from mlp_consumer_match.utils.metrics.base_metrics import BaseMetrics
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="preprocess_metrics")

class PreprocessMetrics(BaseMetrics):
    """
    Metrics tracker for the preprocessing workflow.
    """
    def __init__(self, job_run_id: str, event_type: str):
        """
        Initialize preprocessing metrics tracker.
        
        Args:
            job_run_id: ID of the current job run
            event_type: Type of event being tracked (e.g., "Preprocess")
        """
        super().__init__(job_run_id, event_type)
    
    def track_dataset_stats(self, dataset_name: str, row_count: int, column_count: int):
        """
        Track statistics about a dataset.
        
        Args:
            dataset_name: Name of the dataset
            row_count: Number of rows in the dataset
            column_count: Number of columns in the dataset
        """
        self.add_metric(f"{dataset_name}_dataset_record_count", row_count)
        self.add_metric(f"{dataset_name}_dataset_attribute_count", column_count)
        logger.info(f"Tracked dataset stats for {dataset_name}: {row_count} rows, {column_count} columns")
    
    def track_salt_key_generation(self, dataset_name: str, num_salt_keys: int):
        """
        Track salt key generation for a dataset.
        
        Args:
            dataset_name: Name of the dataset
            num_salt_keys: Number of salt keys generated
        """
        self.add_metric(f"{dataset_name}_salt_keys", num_salt_keys)
        logger.info(f"Tracked salt key generation for {dataset_name}: {num_salt_keys} keys")
    
    def track_preprocessor_execution(self, preprocessor_name: str, execution_time_seconds: float):
        """
        Track execution of a preprocessor.
        
        Args:
            preprocessor_name: Name of the preprocessor function
            execution_time_seconds: Execution time in seconds
        """
        self.add_metric(f"{preprocessor_name}_execution_time", round(execution_time_seconds, 2))
        logger.info(f"Tracked preprocessor execution {preprocessor_name}: {round(execution_time_seconds, 2)} seconds")
    
    def track_preprocess_stats(self, dataset_name: str, input_count: int, output_count: int, columns_selected: List[str]):
        """
        Track preprocessing statistics for a dataset.
        
        Args:
            dataset_name: Name of the dataset
            input_count: Input record count
            output_count: Output record count after preprocessing
            columns_selected: List of columns selected for preprocessing
        """
        self.add_metric(f"preprocessed_{dataset_name}_output_record_count", output_count)
        self.add_metric(f"preprocessed_{dataset_name}_columns_selected", columns_selected)
        self.add_metric(f"preprocessed_{dataset_name}_attribute_count", len(columns_selected))
        
        # Calculate and track retention rate
        retention_rate = round((output_count / input_count) * 100, 2) if input_count > 0 else 0
        self.add_metric(f"preprocessed_{dataset_name}_retention_rate", f"{retention_rate}%")
        
        logger.info(f"Tracked preprocessing stats for {dataset_name}: {input_count} input records, "
                   f"{output_count} output records, {len(columns_selected)} columns")
    
    def get_preprocess_metrics(self) -> Dict[str, Any]:
        """
        Get all preprocessing metrics.
        
        Returns:
            Dictionary containing preprocessing metrics
        """
        return self.metrics