from typing import Dict, Any, List, Optional

from mlp_consumer_match.utils.metrics.base_metrics import BaseMetrics
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="inference_metrics")

class InferenceMetrics(BaseMetrics):
    """
    Metrics tracker for inference workflows (linkage and dedupe).
    """
    def __init__(self, job_run_id: str, event_type: str):
        """
        Initialize inference metrics tracker.
        
        Args:
            job_run_id: ID of the current job run
            event_type: Type of event being tracked (e.g., "Linkage", "Dedupe")
        """
        super().__init__(job_run_id, event_type)
    
    def track_dataset_stats(self, dataset_name: str, row_count: int, column_count: int) -> None:
        """
        Track statistics about a dataset.
        
        Args:
            dataset_name: Name of the dataset
            row_count: Number of rows in the dataset
            column_count: Number of columns in the dataset
        """
        self.add_metric(f"{dataset_name}_dataset_record_count", row_count)
        self.add_metric(f"{dataset_name}_dataset_attribute_count", column_count)
        logger.info(f"Tracked dataset stats for {dataset_name}: {row_count} rows, {column_count} columns")
    
    def track_salt_key_generation(self, dataset_name: str, num_salt_keys: int) -> None:
        """
        Track salt key generation for a dataset.
        
        Args:
            dataset_name: Name of the dataset
            num_salt_keys: Number of salt keys generated
        """
        self.add_metric(f"{dataset_name}_salt_keys", num_salt_keys)
        logger.info(f"Tracked salt key generation for {dataset_name}: {num_salt_keys} keys")
    
    def track_preprocessor_execution(self, preprocessor_name: str, execution_time_seconds: float) -> None:
        """
        Track execution of a preprocessor.
        
        Args:
            preprocessor_name: Name of the preprocessor function
            execution_time_seconds: Execution time in seconds
        """
        self.add_metric(f"{preprocessor_name}_execution_time", round(execution_time_seconds, 2))
        logger.info(f"Tracked preprocessor execution {preprocessor_name}: {round(execution_time_seconds, 2)} seconds")
    
    def track_inference_stats(self, model_name: str, model_version: str, batch_count: int,
                             record_count: int, execution_time_seconds: float) -> None:
        """
        Track inference execution statistics.
        
        Args:
            model_name: Name of the model used for inference
            model_version: Version of the model used
            batch_count: Number of batches processed
            record_count: Number of records processed
            execution_time_seconds: Total execution time in seconds
        """
        self.add_metric("model_name", model_name)
        self.add_metric("model_version", model_version)
        self.add_metric("batch_count", batch_count)
        self.add_metric("record_count", record_count)
        self.add_metric("execution_time_seconds", round(execution_time_seconds, 2))
        
        logger.info(f"Tracked inference stats: {batch_count} batches, {record_count} records, "
                   f"time: {round(execution_time_seconds, 2)} seconds")
    
    def track_model_load(self, model_name: str, model_version: str, load_time_seconds: float) -> None:
        """
        Track model loading statistics.
        
        Args:
            model_name: Name of the model being loaded
            model_version: Version of the model
            load_time_seconds: Time taken to load the model in seconds
        """
        self.add_metric("model_name", model_name)
        self.add_metric("model_version", model_version)
        self.add_metric("model_load_time_seconds", round(load_time_seconds, 2))
    
        logger.info(f"Tracked model load: {model_name} (version {model_version}) "
                f"in {round(load_time_seconds, 2)} seconds")
    
    def track_post_process_stats(self, output_count: int, threshold_applied: float) -> None:
        """
        Track post-processing statistics.
        
        Args:
            output_count: Number of output records after post-processing
            threshold_applied: Confidence threshold applied
        """
        self.add_metric("output_count", output_count)
        self.add_metric("threshold_applied", threshold_applied)
        logger.info(f"Tracked post-process stats: {output_count} output records, threshold: {threshold_applied}")
    
    def track_cluster_stats(self, cluster_count: int, avg_cluster_size: float) -> None:
        """
        Track clustering statistics (for dedupe workflows).
        
        Args:
            cluster_count: Number of clusters created
            avg_cluster_size: Average cluster size
        """
        self.add_metric("cluster_count", cluster_count)
        self.add_metric("avg_cluster_size", round(avg_cluster_size, 2))
        logger.info(f"Tracked cluster stats: {cluster_count} clusters, avg size: {round(avg_cluster_size, 2)}")
    
    def track_bucket_id_counts(self, df, bucket_columns: List[str]) -> None:
        """
        Track distinct ID counts for each bucket column.
        
        Args:
            df: DataFrame containing bucket ID columns
            bucket_columns: List of column names containing bucket IDs
        """
        for column in bucket_columns:
            count = df.select(column).distinct().count()
            self.add_metric(f"{column}_distinct_count", count)
            logger.info(f"Tracked {column} bucket distinct ID count: {count}")