import logging

class NoReceivedCommandFilter(logging.Filter):
    """
    A logging filter that excludes log messages containing "Received command ".
    """
    def filter(self, record):
        if "Received command " not in record.getMessage():
            return record.getMessage()


class NoPythonDotEnvFilter(logging.Filter):
    """
    A logging filter that excludes log messages containing "Python-dotenv".
    """
    def filter(self, record):
        if "Python-dotenv" not in record.getMessage():
            return record.getMessage()


def get_logger() -> logging.Logger:
    """
    Configure and return a logger with custom filters and settings.

    This function sets up a logger with the following configurations:
    - Sets the log level for "py4j" to ERROR
    - Sets the log level for "py4j.java_gateway" to INFO
    - Configures basic logging with a specific format and INFO level
    - Adds custom filters to exclude certain log messages

    Returns:
        logging.Logger: Configured logger instance
    """
    logging.getLogger("py4j").setLevel(logging.ERROR)
    logging.getLogger("py4j.java_gateway").setLevel(logging.INFO)
    logging.basicConfig(format="%(asctime)s %(levelname)-8s %(message)s", level=logging.INFO)
    logger = logging.getLogger(__name__)

    filter_1 = NoReceivedCommandFilter()
    filter_2 = NoPythonDotEnvFilter()
    logger.addFilter(filter_1)
    logger.addFilter(filter_2)

    return logger