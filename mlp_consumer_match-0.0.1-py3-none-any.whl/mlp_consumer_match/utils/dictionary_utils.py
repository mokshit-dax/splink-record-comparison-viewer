import json

from typing import List, Dict, Union, Any
from collections import defaultdict

class DictionaryUtils:
    """
    A class for dictionary operations.
    
    This class provides a collection of static methods for dictionary operations,
    such as merging a list of stringified dictionaries and flattening dictionary values to a list.
    """
    @staticmethod
    def merge_stringified_dicts_list(str_dicts_list: List[str]) -> Dict[str, Union[int, List[int]]]:
        """
        Merge a list of stringified dictionaries into a single dictionary.

        If a key is present in multiple dictionaries, the values are merged into a list.
        If a key is present in only one dictionary, the value is kept as is.
    
        Args:
            str_dicts_list (List[str]): List of string dictionaries
            
        Returns:
            Dict[str, Union[int, List[int]]]: A dictionary containing the merged key-value pairs

        Examples:
            >>> merge_stringified_dicts_list(['{"left": 1}', '{"right": 2}'])
            {'left': 1, 'right': 2}

            >>> merge_stringified_dicts_list(['{"left": 3}', '{"left": 4}'])
            {'left': [3, 4]}
        """
        merged: Dict[str, List[int]] = defaultdict(list)
        for item in str_dicts_list:
            for k, v in json.loads(item).items():
                merged[k].append(v)
        return {k: v[0] if len(v) == 1 else v for k, v in merged.items()}

    @staticmethod
    def flatten_dict_values_to_list(dictionary: Dict[str, Union[Any, List[Any]]]) -> List[Any]:
        """
        Flattens all values in a dictionary into a single list.

        If a value is a list, its elements are added individually.
        If a value is a single item, it is added as-is.

        Args:
            dictionary (Dict[str, Union[Any, List[Any]]]): The dictionary to flatten.

        Returns:
            List[Any]: A flattened list of all dictionary values.

        Examples:
            >>> flatten_dict_values_to_list({"left": [1, 2]})
            [1, 2]

            >>> flatten_dict_values_to_list({"left": 1})
            [1]

            >>> flatten_dict_values_to_list({"left": [1, 2], "right": 3})
            [1, 2, 3]

            >>> flatten_dict_values_to_list({"left": [1], "right": [2, 3]})
            [1, 2, 3]

            >>> flatten_dict_values_to_list({"left": "x", "right": ["y", "z"]})
            ["x", "y", "z"]
        """
        result: List[Any] = []
        for value in dictionary.values():
            if isinstance(value, list):
                result.extend(value)
            else:
                result.append(value)
        return result
