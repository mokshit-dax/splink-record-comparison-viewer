from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory

def save_json_file(data, path):
    """Saves dictionary data as JSON to specified path"""

    fs = FileSystemFactory().create_file_system_from_path_prefix(path)
    fs.put(path=path, data=data, overwrite=True)