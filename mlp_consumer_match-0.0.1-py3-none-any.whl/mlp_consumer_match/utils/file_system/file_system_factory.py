from mlp_consumer_match.utils.file_system.databricks_file_system import DatabricksFileSystem
from mlp_consumer_match.utils.file_system.s3_file_system import S3FileSystem
from mlp_consumer_match.utils.file_system.file_system_platform import FileSystemPlatform
from mlp_consumer_match.utils.file_system.delta_share_file_system import DeltaShareFileSystem
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="file_system_factory")

class FileSystemFactory:
    """
    A factory class that creates file system instances based on the specified path prefix or platform.
    """
    def create_file_system_from_path_prefix(self, path_prefix: str):
        """
        Creates a file system instance based on the specified path prefix.

        Args:
            path_prefix (str): The prefix for the file system path.

        Returns:
            FileSystem: The created file system instance.
        """
        if path_prefix.startswith("/dbfs"):
            logger.info(f"Using Databricks File System")
            return DatabricksFileSystem()
        elif path_prefix.startswith("s3://"):
            logger.info(f"Using S3 File System")
            return S3FileSystem()
        elif self._is_delta_share_path(path_prefix):
            logger.info("Using Delta Share File System")
            return DeltaShareFileSystem()
        else:
            logger.error(f"Unsupported file system prefix: {path_prefix}")
            raise


    def create_file_system_from_platform(self, platform: str):
        """
        Creates a file system instance based on the specified platform.

        Args:
            platform (str): The platform for which the file system is created.

        Returns:
            FileSystem: The created file system instance.
        """
        self.file_systems_map = {
            FileSystemPlatform.DATABRICKS: DatabricksFileSystem,
            FileSystemPlatform.S3: S3FileSystem,
            FileSystemPlatform.DELTA_SHARE: DeltaShareFileSystem,
            # Add file systems for other platforms as needed
        }

        if platform not in self.file_systems_map:
            logger.error(f"Unsupported file system platform: {platform}")
            raise
        return self.file_systems_map.get(platform)()

    def _is_delta_share_path(self, path: str) -> bool:
        """
        Determines if a path is a Delta Share path.
        A Delta Share path is in the format <provider>.<share>.<schema>.<table>
        
        Args:
            path (str): The path to check
            
        Returns:
            bool: True if the path is a Delta Share path
        """
        # <provider_name>.<share_name>.<schema_name>.<table_name>
        # Check for dot-separated format and not a URL or file path

        if not isinstance(path, str):
            return False
        
        parts = path.split('.')
        return (len(parts) == 4 and 
                not path.startswith(("s3://", "/dbfs", "file:", "http://", "https://", "/")) and
                not any('/' in part for part in parts))