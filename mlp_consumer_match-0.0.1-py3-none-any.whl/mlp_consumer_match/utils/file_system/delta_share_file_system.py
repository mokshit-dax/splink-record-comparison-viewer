from mlp_consumer_match.utils.file_system.file_system import FileSystem
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="delta_share_file_system")

class DeltaShareFileSystem(FileSystem):
    """
    Handles reading from Delta Share tables (read-only).
    """

    def __init__(self):
        super().__init__()
        logger.debug("DeltaShareFileSystem initialized")
    
    def parse_delta_share_path(self, path):
        """
        Parse a dot-separated Delta Share path.
        Format: provider.share.schema.table
        """
        parts = path.split('.')
        if len(parts) != 4:
            raise ValueError(f"Invalid Delta Share path format. Expected provider.share.schema.table but got: {path}")
    
        provider, share, schema, table = parts
        logger.info(f"Parsed Delta Share path: provider={provider}, share={share}, schema={schema}, table={table}")
        return provider, share, schema, table

    def register_catalog_from_share(self, provider: str, share: str, catalog: str):
        """
        Registers a Unity Catalog catalog from a Delta Share.

        Args:
            provider (str): Name of the Delta Share provider.
            share (str): Name of the Delta Share.
            catalog (str): Name of the catalog to register.
        """

        try:
            logger.info(f"Registering UC catalog '{catalog}' from share {provider}.{share}")
            
            # Check if the share exists
            share_exists_query = f"SHOW SHARES IN PROVIDER `{provider}`"
            shares_df = self.spark.sql(share_exists_query)
            available_shares = [row.name for row in shares_df.collect()]
            logger.info(f"Available shares from provider {provider}: {available_shares}")

            if not available_shares or share not in available_shares:
                raise ValueError(f"Share '{share}' not found from provider '{provider}'")

            # Create catalog
            sql = f"CREATE CATALOG IF NOT EXISTS {catalog} USING SHARE `{provider}`.`{share}`"
            logger.info(f"Executing SQL: {sql}")
            self.spark.sql(sql)

             
            # Verify catalog was created
            catalog_exists = self.spark.sql(f"SHOW CATALOGS LIKE '{catalog}'").count() > 0
            if not catalog_exists:
                raise ValueError(f"Failed to create catalog '{catalog}'")

            # List available schemas
            schemas_df = self.spark.sql(f"SHOW SCHEMAS IN {catalog}")
            available_schemas = [row.databaseName for row in schemas_df.collect()]
            logger.info(f"Available schemas in catalog {catalog}: {available_schemas}")

            logger.info(f"Successfully registered catalog '{catalog}' from share {provider}.{share}")
        
        except Exception as e:
            logger.error(f"Error registering catalog: {e}")
            raise

    def ls(self, catalog: str, schema: str):
        """
        Lists tables in the given UC schema.

        Args:
            catalog (str): Name of the catalog.
            schema (str): Name of the schema within the catalog.

        Returns:
            list: List of tables in the specified schema.
        """
        logger.info(f"Listing tables in UC schema: {catalog}.{schema}")
        return self.spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()

    def read_as_spark_dataframe(self, path, file_format: str = 'delta', options: dict = None, model_name=None):
        """
        Reads the Delta Share table as a Spark DataFrame from the registered UC catalog.

        Args:
             path: String path in format <provider>.<share>.<schema>.<table> or 
                 dictionary with provider_name, share_name, schema_name, table_name
            file_format (str, optional): File format to read (default: 'delta').
            options (dict, optional): Additional options for reading the table.
            model_name (str, optional): Optional model name to use as catalog name.

        Returns:
            DataFrame: Spark DataFrame containing the table data.
        """
        logger.info(f"DeltaShareFileSystem reading from path: {path}")
    
        try:
            catalog = model_name
            
            # Handle string path format
            if isinstance(path, str):
                provider, share, schema, table = self.parse_delta_share_path(path)

            # Handle dictionary format
            elif isinstance(path, dict) or hasattr(path, 'get'):
                provider = path.get('provider_name', '')
                share = path.get('share_name', '')
                schema = path.get('schema_name', '')
                table = path.get('table_name', '')
            else:
                raise ValueError(f"Unsupported path format: {path}")
            

            # Verify we have all required components
            if not all([provider, share, schema, table, catalog]):
                missing = []
                for key, val in {'provider_name': provider, 'share_name': share, 
                            'schema_name': schema, 'table_name': table, 'catalog': catalog}.items():
                    if not val:
                        missing.append(key)
                raise ValueError(f"Missing required keys in Delta Share path: {', '.join(missing)}")
            
            # Register the catalog from share
            self.register_catalog_from_share(provider, share, catalog)

            # Access the table
            full_table = f"{catalog}.{schema}.{table}"
            logger.info(f"Reading Delta Share table: {full_table}")
            return self.spark.table(full_table)

        except Exception as e:
            logger.error(f"Error reading from Delta Share: {e}")
            raise

    def write_spark_dataframe(self, df, raw_path, write_mode="overwrite", file_format="delta", options=None, model_name=None):
        """
        Writes DataFrame to Unity Catalog and shares via Delta Share.
        """
        try:
            if raw_path and '.' in raw_path:
                parts = raw_path.split('.')
                if len(parts) != 4:
                    raise ValueError(f"Invalid raw_path format: {raw_path}. Expected: share_name.catalog.schema.table_name")
                share_name, catalog, schema, table_name = parts
                logger.info(f"Using share_name: {share_name}, catalog: {catalog}, schema: {schema}, table_name: {table_name}")
            
            # Create schema if it doesn't exist
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            
            # Write DataFrame to table
            full_table_path = f"{catalog}.{schema}.{table_name}"
            logger.info(f"Writing DataFrame to UC table: {full_table_path}")
            
            writer = df.write.mode(write_mode).format(file_format)
            if options:
                for k, v in options.items():
                    writer = writer.option(k, v)
                    
            writer.saveAsTable(full_table_path)
            
            # Grant share access if share_name provided
            if share_name:
                self._add_table_to_share(share_name, catalog, schema, table_name)

            return full_table_path
        except Exception as e:
            logger.error(f"Error writing DataFrame to Delta Share: {e}")
            raise

    def _add_table_to_share(self, share_name, catalog, schema, table):
        """
        Add a table to a Delta Share
        """
        try:
            # Add the table to the share
            share_sql = f"""
            ALTER SHARE {share_name} 
            ADD TABLE {catalog}.{schema}.{table}
            WITH HISTORY
            """
            logger.info(f"Adding table to Delta Share: {share_sql}")
            self.spark.sql(share_sql)
            logger.info(f"Successfully added table to share: {share_name}")
            
        except Exception as e:
            logger.error(f"Error adding table to share: {e}")
            raise

    def get_table_schema(self, catalog: str, schema: str, table: str):
        """
        Returns the schema of the table in UC.

        Args:
            catalog (str): Name of the catalog.
            schema (str): Name of the schema within the catalog.
            table (str): Name of the table.

        Returns:
            pyspark.sql.types.StructType: Schema of the specified table.
        """
        full_table = f"{catalog}.{schema}.{table}"
        logger.info(f"Getting schema for UC table: {full_table}")
        return self.spark.table(full_table).schema

    def put(self, *args, **kwargs):
        """
        Not implemented. Delta Share is read-only.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Raises:
            NotImplementedError: Writing is not supported.
        """
        raise NotImplementedError("For Delta Share, use write_spark_dataframe instead.")

    def rm(self, *args, **kwargs):
        """
        Not implemented. Delta Share is read-only.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Raises:
            NotImplementedError: Remove is not supported.
        """
        raise NotImplementedError("Delta Share is read-only. Remove is not supported.")

    def mkdir(self, *args, **kwargs):
        """
        Not implemented. Delta Share is read-only.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Raises:
            NotImplementedError: Mkdir is not supported.
        """
        raise NotImplementedError("Delta Share is read-only. Mkdir is not supported.")

    def read(self, *args, **kwargs):
        """
        Not implemented. Delta Share does not support file-like read.

        Args:
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Raises:
            NotImplementedError: Use read_as_spark_dataframe instead.
        """
        raise NotImplementedError("Delta Share does not support file-like read. Use read_as_spark_dataframe.")