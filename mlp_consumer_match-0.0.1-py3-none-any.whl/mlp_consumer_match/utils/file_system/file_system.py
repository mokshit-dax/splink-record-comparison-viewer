from typing import Union, Any
from pyspark.sql import DataFrame

from mlp_consumer_match.utils.file_system.file_info import FileInfo
from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="file_system")


class FileSystem:
    """
    A base class for file system operations.
    """

    def __init__(self):
        self.spark = SparkSessionFactory().get_or_create_spark_session()

    def ls(self, path: str, extension: str = "") -> list[FileInfo]:
        """
        Lists files in the specified path.

        Args:
            path (str): Path to list files from.
            extension (str, optional): File extension to filter by. Defaults to "".

        Returns:
            list[FileInfo]: List of FileInfo objects.
        """
        raise NotImplementedError("Subclasses must implement this method")

    def put(self, data: Union[str, bytes, dict, Any], path: str, overwrite: bool = True, format: str = "auto") -> None:
        """
        Writes data to the specified path.

        Args:
            data (Union[str, bytes, dict, Any]): Data to write.
            path (str): Path to write data to.
            overwrite (bool, optional): Whether to overwrite the existing file. Defaults to True.
            format (str, optional): Format of the data. Defaults to "auto".
        """
        raise NotImplementedError("Subclasses must implement this method")

    def rm(self, path: str, recursive: bool = False) -> None:
        """
        Removes the specified path.

        Args:
            path (str): Path to remove.
            recursive (bool, optional): Whether to remove recursively. Defaults to False.
        """
        raise NotImplementedError("Subclasses must implement this method")

    def read(self, path: str, mode: str = "r") -> str:
        """
        Reads the content of the specified path.

        Args:
            path (str): Path to read from.
            mode (str, optional): Mode to read the file in. Defaults to "r".

        Returns:
            str: Content of the file.
        """
        raise NotImplementedError("Subclasses must implement this method")

    def format_path_as_spark_api_format(self, path: str) -> str:
        """
        Formats the path to be used in the Spark API.

        Args:
            path (str): Path to format.

        Returns:
            str: Formatted path.
        """
        return path

    def read_as_spark_dataframe(
        self, raw_path: str, file_format: str = "parquet", options: dict = None, model_name=None
    ) -> DataFrame:
        """
        Reads a Spark DataFrame from the specified path.

        Args:
            raw_path (str): The raw path where the DataFrame should be read from.
            file_format (str, optional): The file format (e.g., "parquet", "delta", "csv", "json"). Defaults to "parquet".
            options (dict, optional): Additional options for Spark's DataFrameReader (e.g., partitionBy, compression).
            model_name: Optional model name (used by some file systems)

        Returns:
            DataFrame: The Spark DataFrame read from the specified path.
        """
        if self.spark is None:
            raise RuntimeError(
                "SparkSession must be provided to FileSystemUtil to read Spark DataFrames."
            )

        spark_path = self.format_path_as_spark_api_format(raw_path)
        logger.info(
            f"Reading Spark DataFrame from: {spark_path} with format: {file_format}"
        )

        try:
            reader = self.spark.read.format(file_format)
            if options:
                reader = reader.options(**options)
            df = reader.load(spark_path)
            logger.info(f"Successfully loaded Spark DataFrame from {spark_path}")
            return df
        except Exception as e:
            logger.error(f"Error reading Spark DataFrame from {spark_path}: {e}")
            raise

    def write_spark_dataframe(
        self,
        df: DataFrame,
        raw_path: str,
        write_mode: str = "overwrite",
        file_format: str = "parquet",
        options: dict = None,
        model_name = None,
    ):
        """
        Writes a Spark DataFrame to the specified path in a distributed manner.
        This uses Spark's DataFrame.write API.

        Args:
            df (DataFrame): The Spark DataFrame to write.
            raw_path (str): The raw path where the DataFrame should be written.
            write_mode (str): The write mode (e.g., "overwrite", "append", "ignore", "errorifexists").
            file_format (str): The file format (e.g., "parquet", "delta", "csv", "json").
            options (dict, optional): Additional options for Spark's DataFrameWriter (e.g., partitionBy, compression).
            model_name: Optional model name (used by some file systems)
        """

        spark_path = self.format_path_as_spark_api_format(raw_path)
        logger.info(
            f"Writing Spark DataFrame to: {spark_path} with mode: {write_mode} and format: {file_format}"
        )

        try:
            writer = df.write.mode(write_mode).format(file_format)

            # Add any extra options like partitionBy, compression, etc.
            if options:
                writer = writer.options(**options)

            writer.save(spark_path)
            logger.info(f"Successfully wrote Spark DataFrame to {spark_path}")
        except Exception as e:
            logger.error(f"Error writing Spark DataFrame to {spark_path}: {e}")
            raise
