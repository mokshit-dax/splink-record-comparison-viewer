import s3fs
import json
import pickle
from typing import Union, Any

from mlp_consumer_match.utils.file_system.file_info import FileInfo
from mlp_consumer_match.utils.file_system.file_system_platform import FileSystemPlatform
from mlp_consumer_match.utils.file_system.file_system import FileSystem
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="s3_file_system")

class S3FileSystem(FileSystem):
    """
    A class representing the S3 file system.
    """
    def __init__(self):
        """
        Initializes a new instance of the S3FileSystem class.
        """
        super().__init__()
        self.db_path_prefix = '/local_disk0/'
        self.__s3fs = s3fs.S3FileSystem()
        logger.debug(f"S3FileSystem initialized with db_path_prefix: {self.db_path_prefix}")


    def ls(self, path: str, extension: str = "") -> list[FileInfo]:
        """
        Lists files in the specified path.

        Args:
            path (str): Path to list files from.
            extension (str, optional): File extension to filter by. Defaults to "".

        Returns:
            list[FileInfo]: List of FileInfo objects.
        """
        logger.debug(f"Listing files in path: {path} with extension: {extension}")
        files = self.__s3fs.ls(path, True)
        return [
            FileInfo(
                path = f's3://{file.get("Key")}' if file.get('type') == "file" else f's3://{file.get("Key")}/',
                name = file.get("Key").split("/")[-1],
                platform=FileSystemPlatform.S3,
            ) for file in files if file.get("Key").endswith(extension) and file.get("Key").split('/')[-1]
        ]

    def put(self, data: Union[str, bytes, dict, Any], path: str, overwrite: bool = True, format: str = "auto"):
        """
        Writes data to the specified path.

        Args:
            data (Union[str, bytes, dict, Any]): Data to write.
            path (str): Path to write data to.
            overwrite (bool, optional): Whether to overwrite the existing file. Defaults to True.
            format (str, optional): Format to write data in. Defaults to "auto".
        """
        logger.debug(f"Writing data to path: {path} with format: {format}")
        mode = "wb" if format in ["pickle", "binary"] else "w"

        if self.__s3fs.exists(path) and not overwrite:
            raise FileExistsError(f"File {path} already exists and overwrite=False.")
        
        if isinstance(data, dict) or format == "json":
            data = json.dumps(data).encode("utf-8")  # Convert dict to JSON bytes

        elif isinstance(data, bytes) or format == "pickle" or format == "binary":
            data = pickle.dumps(data) if format == "pickle" else data

        with self.__s3fs.open(path, mode) as f:
            f.write(data)

    def rm(self, path: str, recursive: bool = False) -> None:
        """
        Removes the specified path.

        Args:
            path (str): Path to remove.
            recursive (bool, optional): Whether to remove recursively. Defaults to False.
        """
        logger.debug(f"Removing data from path: {path}")
        self.__s3fs.rm(path, recursive=recursive)

    def mkdir(self, path: str) -> None:
        """
        Creates a directory and its parent directories at the specified path.

        Args:
            path (str): Path to create directory and its parent directories at.
        """
        logger.debug(f"Creating directory at path: {path}")
        path = path.rstrip('/') if path.endswith('/') else path
        placeholder_path = f'{path}/.keep'
        with self.__s3fs.open(placeholder_path, "w") as f:
          f.write("")
        return

    def read_as_spark_dataframe(self, path_config, file_format="parquet", options=None, model_name=None):
        """
        Reads a Spark DataFrame from S3 location.
        
        Args:
            path_config: String path or dictionary with bucket and prefix
            file_format: Format of the files to read
            options: Additional Spark reader options
        
        Returns:
            DataFrame: Spark DataFrame
        """
        try:
             # Handle both string and dict paths
            if isinstance(path_config, str):
                # It's a string path - pass directly to parent implementation
                return super().read_as_spark_dataframe(path_config, file_format, options)
        
            
            bucket = path_config.get('bucket_name', '')
            prefix = path_config.get('prefix', '')            
            
            if not all([bucket, prefix]):
                raise ValueError("Missing required keys in S3 path configuration")
            
            # Handle bucket with or without s3:// prefix
            if not bucket.startswith('s3://'):
                bucket = f"s3://{bucket}"
                
            # Build full path and trim extra slashes
            full_path = f"{bucket.rstrip('/')}/{prefix.lstrip('/')}"
            logger.info(f"Reading S3 path from config: {full_path}")
                
            # Use the base class implementation with resolved path
            return super().read_as_spark_dataframe(full_path, file_format, options)
            
        except Exception as e:
            logger.error(f"Error reading from S3: {e}")
            raise

    def read(self, path: str, mode: str = "r") -> str:
        """
        Reads the content of the specified path.

        Args:
            path (str): Path to read from.
            mode (str, optional): Mode to read the file in. Defaults to "r".

        Returns:
            str: Content of the file.
        """
        logger.debug(f"Reading data from path: {path}")
        with self.__s3fs.open(path, mode) as f:
            data = f.read()
        return json.loads(data) if path.endswith(".json") else data