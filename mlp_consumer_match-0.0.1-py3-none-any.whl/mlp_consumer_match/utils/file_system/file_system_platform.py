class FileSystemPlatform:
    """
    A class representing the platform where the file system is stored.
    """
    DATABRICKS = "databricks"
    S3 = "s3"
    DELTA_SHARE = "delta_share"
