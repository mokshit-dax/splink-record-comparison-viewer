import json
import pickle

from typing import Union, Any

from pyspark.dbutils import DBUtils
from mlp_consumer_match.utils.file_system.file_info import FileInfo
from mlp_consumer_match.utils.file_system.file_system import FileSystem
from mlp_consumer_match.utils.file_system.file_system_platform import FileSystemPlatform
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="databricks_file_system")

class DatabricksFileSystem(FileSystem):
    """
    A class that provides methods for interacting with Databricks file system.

    Attributes:
        db_path_prefix (str): Prefix for the database path.
        __dbutils (pyspark.dbutils.DBUtils): DBUtils instance
    """
    def __init__(self):
        """
        Initializes the DatabricksFileSystem with a Spark session and DBUtils instance.
        """
        super().__init__()
        self.db_path_prefix = '/local_disk0/'
        self.__dbutils = DBUtils(self.spark)
        logger.debug(f"DatabricksFileSystem initialized with db_path_prefix: {self.db_path_prefix}")

    def ls(self, path: str, extension: str = "") -> list[FileInfo]:
        """
        Lists files in the specified path.

        Args:
            path (str): Path to list files from.
            extension (str, optional): File extension to filter by. Defaults to "".

        Returns:
            list[FileInfo]: List of FileInfo objects.
        """
        logger.debug(f"Listing files in path: {path} with extension: {extension}")
        
        files = self.__dbutils.fs.ls(self.format_path_as_spark_api_format(path))
        return [
            FileInfo(
                path=file.path[5:] if file.path.startswith('file:') else file.path, 
                name=file.name if not file.name.endswith("/") else file.name[:-1], 
                platform=FileSystemPlatform.DATABRICKS,
            ) for file in files if file.name.endswith(extension)
        ]

    def put(self, data: Union[str, bytes, dict, Any], path: str, overwrite: bool = True, format: str = "auto") -> None:
        """
        Writes data to the specified path.

        Args:
            data (Union[str, bytes, dict, Any]): Data to write.
            path (str): Path to write data to.
            overwrite (bool, optional): Whether to overwrite the existing file. Defaults to True.
            format (str, optional): Format of the data. Defaults to "auto".
        """
        logger.debug(f"Writing data to path: {path} with format: {format}")
        if isinstance(data, dict) or format == "json":
            data = json.dumps(data)
        
        elif isinstance(data, bytes) or format == "pickle" or format == "binary":
            local_tmp_path = f"/tmp/{path.split('/')[-1]}"
            with open(local_tmp_path, "wb") as f:
                f.write(pickle.dumps(data) if format == "pickle" else data)
            self.__dbutils.fs.cp(
                self.format_path_as_spark_api_format(local_tmp_path),
                self.format_path_as_spark_api_format(path),
                overwrite
            )
            return
        
        # Default case: Assume text format
        self.__dbutils.fs.put(
            self.format_path_as_spark_api_format(path),
            data,
            overwrite,
        )


    def rm(self, path: str, recursive: bool = False) -> None:
        """
        Removes the specified path.

        Args:
            path (str): Path to remove.
            recursive (bool, optional): Whether to remove recursively. Defaults to False.
        """
        logger.debug(f"Removing data from path: {path}")
        self.__dbutils.fs.rm(
            self.format_path_as_spark_api_format(path),
            recursive
        )

    def mkdir(self, path: str) -> None:
        """
        Creates a directory and its parent directories at the specified path.

        Args:
            path (str): Path to create directory and its parent directories at.
        """
        logger.debug(f"Creating directory at path: {path}")
        self.__dbutils.fs.mkdirs(self.format_path_as_spark_api_format(path))

    def read(self, path: str, mode: str = "r") -> str:
        """
        Reads the content of the specified path.

        Args:
            path (str): Path to read from.
            mode (str, optional): Mode to read the file in. Defaults to "r".

        Returns:
            str: Content of the file.
        """
        logger.debug(f"Reading data from path: {path}")
        with open(path, mode) as f:
            data = f.read()
        return json.loads(data) if path.endswith(".json") else data

    def format_path_as_spark_api_format(self, path: str) -> str:
        """
        Formats the path to be used in the Spark API.
        
        Args:
            path (str): Path to format.
            
        Returns:
            str: Formatted path.
        """
        logger.debug(f"Formatting path for Spark API: {path}")
        if path.startswith("/dbfs"):
            return f"file:{path}"
        return path