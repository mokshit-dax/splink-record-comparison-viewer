from dataclasses import dataclass

@dataclass
class FileInfo:
    """
    A class representing a file in a file system.

    Attributes:
        path (str): The path of the file.
        name (str): The name of the file.
        platform (str): The platform where the file is stored.
    """
    
    path: str
    name: str
    platform: str