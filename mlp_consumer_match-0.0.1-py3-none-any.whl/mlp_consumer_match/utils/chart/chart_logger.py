import json
from typing import Dict, List

from mlp_consumer_match.utils.file_system.databricks_file_system import DatabricksFileSystem
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="chart_logger")

class ChartLogger:
    """
    Singleton class to help log charts to MatchAI Database.
    """

    _instance = None # Class-level attribute to hold the single instance

    def __new__(cls):
        """
        Controls the instance creation process, ensuring only one instance exists.
        If an instance already exists, it returns the existing one.
        Otherwise, it creates a new instance.
        """
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.charts: List[Dict] = []
            cls._instance.chart_paths: List[str] = []
            cls._instance.uc_destination_path = None # Store the path
        return cls._instance
    
    def set_uc_destination_path(self, uc_destination_path: str) -> None:
        """
        Sets the target Unity Catalog volume base path. Creates the directory if it doesn't exist.

        Args:
            uc_destination_path (str): Target Unity Catalog volume base path
        """
        self._instance.uc_destination_path = uc_destination_path
        fs = DatabricksFileSystem()
        fs.mkdir(uc_destination_path)
    
    def save_chart_to_uc(self, chart: str, chart_name: str = None) -> None:
        """
        Saves a chart to Unity Catalog.

        Args:
            chart (str): Chart object
            chart_name (str): Name of the chart file
        """
        fs = DatabricksFileSystem()
        fs.put(path=f"{self._instance.uc_destination_path}/{chart_name}", data=chart, overwrite=True)
    
    def get_uc_destination_path(self) -> str:
        """
        Returns the target Unity Catalog volume base path.
        """
        return self._instance.uc_destination_path

    def log_chart_dict(self, chart: Dict, chart_name: str = None) -> None:
        """
        Logs a dictionary format of chart.

        Args:
            chart (Dict): Chart object
            chart_name (str): Name of the chart file
        """
        self._instance.charts.append({chart_name: chart})

    def log_uc_chart_path(self, file_name: str) -> None:
        """
        Logs a Unity catalog path for the chart.

        Args:
            file_name: Name of the chart file
        """

        self._instance.chart_paths.append(f"{self._instance.uc_destination_path}/{file_name}")

    def get_charts_data(self, json_encode: bool = False) -> List[Dict]:
        """
        Returns all charts data.

        Args:
            json_encode (bool): Whether to encode the charts data as JSON.

        Returns:
            List[Dict]: List of charts data.
        """
        if json_encode:
            return json.dumps(self._instance.charts)
        return self._instance.charts

    def get_chart_paths(self, json_encode: bool = False) -> List[str]:
        """
        Returns all chart paths.

        Args:
            json_encode (bool): Whether to encode the chart paths as JSON.

        Returns:
            List[str]: List of chart paths.
        """
        if json_encode:
            return json.dumps(self._instance.chart_paths)
        return self._instance.chart_paths

    def clear_charts(self) -> None:
        """
        Clears all stored charts.
        """
        self._instance.charts = []