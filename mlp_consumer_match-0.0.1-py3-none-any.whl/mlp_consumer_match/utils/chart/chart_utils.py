import json
from typing import Any, Dict
from splink.internals.pipeline import CTEPipeline
from splink.internals.splink_dataframe import SplinkDataFrame
from splink.internals.comparison_vector_distribution import (
    comparison_vector_distribution_sql,
)
from splink.internals.splink_comparison_viewer import comparison_viewer_table_sqls
from splink.internals.misc import EverythingEncoder
from splink.internals.linker import Linker
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader

logger = get_logger(name="chart_utils")


class ChartUtils:
    """
    Utility class to help generate charts.
    """

    def get_comparison_viewer_chart_as_dict(
        self, linker: Linker, df_predict: SplinkDataFrame, num_example_rows: int = 5
    ) -> Dict[str, Any]:
        """
        Returns comparison viewer chart as a dictionary.

        Args:
            linker: Linker object
            df_predict: Predicted DataFrame
            num_example_rows (int): Number of example rows to include in the charts

        Returns:
            Dict[str, Any]: Dictionary of comparison viewer chart
        """
        pipeline = CTEPipeline([df_predict])
        sql = comparison_vector_distribution_sql(linker)
        pipeline.enqueue_sql(sql, "__splink__df_comparison_vector_distribution")

        sqls = comparison_viewer_table_sqls(linker, num_example_rows)
        pipeline.enqueue_list_of_sqls(sqls)

        df = linker._db_api.sql_pipeline_to_splink_dataframe(pipeline)

        comparison_vector_data = df.as_record_dict()
        splink_settings = linker._settings_obj._as_completed_dict()

        template_data: dict[str, Any] = {
            "comparison_vector_data": json.dumps(
                comparison_vector_data, cls=EverythingEncoder
            ),
            "splink_settings": json.dumps(splink_settings),
        }

        return template_data

    def create_sampled_pred_table(
        self,
        duckdb_connection,
        bucket_file_path,
        bucket_count,
        bucket_name,
        bucket_config,
    ):
        """
        Creates a sampled data table for the given bucket.

        Args:
            duckdb_connection: DuckDB connection
            bucket_file_path: Path to bucket file
            bucket_count: Count of bucket
            bucket_name: Name of bucket
            bucket_config: Bucket config
        """
        read_path, read_function = ConfigLoader().get_read_path_and_function_for_sql(
            bucket_file_path, workflow_type="inference"
        )

        logger.info(f"Creating sampled data table for {bucket_name}")

        if bucket_count <= bucket_config.get("sample_size_to_generate_charts"):
            duckdb_connection.query(
                f"CREATE TABLE __splink__df_predict AS SELECT * FROM {read_function}('{read_path}')"
            )
        else:
            # sampling_buffer_multiplier ensures that the sample size is not less than the specified sample size
            sampling_buffer_multiplier = 1.5
            modulo_divisor = 1000000

            fraction = (
                bucket_config.get("sample_size_to_generate_charts") / bucket_count * sampling_buffer_multiplier
            )
            duckdb_connection.query(
                f"CREATE TABLE __splink__df_predict AS SELECT * FROM {read_function}('{read_path}') WHERE CAST(unique_id_l AS BIGINT) % {modulo_divisor} < {int(fraction * modulo_divisor)}"
            )

        logger.info(f"Created sampled data table for {bucket_name}")
