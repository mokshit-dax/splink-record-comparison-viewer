from mlp_consumer_match.preprocess.preprocessors.preprocess_factory import PreprocessFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="preprocess_pipeline")

class PreprocessPipeline:
    """
    A preprocessing pipeline that sequentially applies a series of transformation functions
    to a PySpark DataFrame, similar in spirit to Spark ML's Pipeline.

    Each preprocessing function is defined as a dictionary containing a single key-value pair.
    The key specifies the type of transformation (e.g., 'to_lower') and the value is a dictionary
    of parameters required for that transformation.

    Attributes:
        fn_list (list): A list of preprocessing function definitions. 
        
        For example:
            [
                {'to_lower': {'input_col_name': 'column1', 'output_col_name': 'column1_lower'}},
                ...
            ]
    """

    def __init__(self, fn_list):
        """
        Initializes the PreprocessPipeline with a list of preprocessing functions.

        Args:
            fn_list (list): A list of function definitions where each function is specified as a dictionary.
                Each dictionary must contain one key-value pair. The key is the preprocessor type (e.g., 'to_lower')
                and the value is another dictionary containing the parameters. 
                
                For example:
                    [
                        {'to_lower': {'input_col_name': 'column1', 'output_col_name': 'column1_lower'}},
                        {'to_lower': {'input_col_name': 'column2', 'output_col_name': 'column2_lower'}}
                    ]
        """
        self.fn_list = fn_list if fn_list is not None else []
        logger.debug("Initialized PreprocessPipeline with functions", function_count=len(fn_list))
        

    def _apply_preprocessor(self, df, fn):
        """
        Applies a single preprocessor transformation to the DataFrame.

        This method extracts the preprocessor type and its corresponding parameters from the provided function
        definition, instantiates the appropriate preprocessor, and applies it to the DataFrame.

        Args:
            df (pyspark.sql.DataFrame): The DataFrame to transform.
            fn (dict): A dictionary containing one preprocessor definition. For example:
                {'to_lower': {'input_col_name': 'column1', 'output_col_name': 'column1_lower'}}

        Returns:
            pyspark.sql.DataFrame: The DataFrame after applying the specified preprocessor.
        """

        # Extract the preprocessor name and its parameters
        preprocessor_name, preprocessor_params = list(fn.items())[0]
        
        # Get the preprocessor from the factory
        preprocessor = PreprocessFactory.get_preprocessor(preprocessor_name)
        
        # Apply the preprocessor to the DataFrame
        df = preprocessor.preprocess(df=df, **preprocessor_params)
        
        logger.info(f"Applied preprocessor: {preprocessor_name}, with parameters: {preprocessor_params}")
        return df


    def transform(self, df):
        """
        Sequentially applies all configured preprocessing transformations to the input DataFrame.

        The transformations are applied in the order they appear in the `fn_list`. The output of one transformation
        serves as the input to the next.

        Args:
            df (pyspark.sql.DataFrame): The input DataFrame to preprocess.

        Returns:
            pyspark.sql.DataFrame: The transformed DataFrame after all preprocessing steps have been applied.
        """
        
        for fn in self.fn_list:
            df = self._apply_preprocessor(df, fn)         

        return df
