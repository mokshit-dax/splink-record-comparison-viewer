import json

from pyspark.dbutils import DBUtils

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.preprocess.preprocess_pipeline import PreprocessPipeline
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.preprocess_metrics import PreprocessMetrics
from mlp_consumer_match.conf.preprocess_config import PreprocessConfig

from mlp_consumer_match.connection.database_api import DatabaseAPI

logger = get_logger(name="preprocess_main")


def main():
    """
    Executes the data preprocessing pipeline based on the provided configuration.

    This function performs the following steps:
      1. Initializes a Spark session.
      2. Reads input datasets as specified in the configuration.
      3. Selects a subset of columns from each dataset.
      4. Logs information about the loaded datasets (name, path, and record count).
      5. Applies a series of preprocessing transformations to each dataset using the PreprocessPipeline.
      6. Saves the transformed datasets to a designated output location.

    Returns:
        int: Returns 1 upon successful completion of the preprocessing job.
    """
    # Load config
    cfg: PreprocessConfig = ConfigLoader().get_or_load_config("preprocess")

    # Get spark connection
    spark = SparkSessionFactory().get_or_create_spark_session()
    dbutils = DBUtils(spark)

    # Initialize metrics tracker
    metrics = PreprocessMetrics(job_run_id=cfg.job_run_id, event_type="Preprocess")    
    metrics.add_metric("model_name", cfg.model_name)

    logger.info(f"Preprocess started at: {metrics.start_time}")

    # Get File System
    fs = FileSystemFactory().create_file_system_from_path_prefix(cfg.save_path)

    # Fetch database API connection
    database_api = DatabaseAPI(cfg.database_api_url)
    logger.info(f"Database API URL: {cfg.database_api_url}")

    logger.info(
        f"Model Name: {cfg.model_name}, Job Run ID: {cfg.job_run_id}, Task Run ID: {cfg.task_run_id}"
    )

    # Create Match Run Event Table Record with start_time
    database_api.create_match_run_event(
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        event_type="Preprocess"
    )
    logger.info("Created Match Run Event Table Record for Preprocess")

    # Date Partition
    logger.info(f"Date Partition: {cfg.date_partition}")

    # Set model_name and JOB_RUN_ID in the task values
    dbutils.jobs.taskValues.set(key="model_name", value=cfg.model_name)
    dbutils.jobs.taskValues.set(key="job_run_id", value=cfg.job_run_id)
    dbutils.jobs.taskValues.set(key="task_run_id", value=cfg.task_run_id)
    dbutils.jobs.taskValues.set(key="date_partition", value=cfg.date_partition)
    dbutils.jobs.taskValues.set(key="conf_path", value=ConfigLoader().get_hydra_config_path())

    # TODO: Config Validator

    salt_keys = {}
    # Read and process input datasets
    for file in cfg.source.files:
        name = file.get("file").get("name")
        path = file.get("file").get("path")
        functions_list = file.get("file").get("preprocessing_functions")

        # Create appropriate file system for each input path
        input_fs = FileSystemFactory().create_file_system_from_path_prefix(path)

        df = input_fs.read_as_spark_dataframe(path, model_name=cfg.model_name)
        df = df.cache()
        count = df.count()

        logger.info(f"Loading {name.title()} dataset: ")
        logger.info(f"Successfully loaded {name.title()} dataset from: {path}")
        logger.info(f"Columns selected for {name.title()}: {df.columns}")
        logger.info(f"Record count for {name.title()}: {count}")

        # Track dataset stats
        metrics.track_dataset_stats(
            dataset_name=name, row_count=count, column_count=len(df.columns)
        )

        # Initialize functions_list if None
        functions_list = functions_list or []
            
        # Add default salt key if not already present
        if not any(fn and fn.get('add_salt_key') is not None for fn in functions_list):
            logger.info(f"Adding default salt key to {name.title()} dataset")
            functions_list.insert(0, {'add_salt_key': {'num_salt_keys': 1}})

        salt_keys[name] = ConfigLoader().get_salt_keys_for_file(functions_list)
        
        # Process the data with the preprocessing pipeline
        logger.info(f"Applying preprocessing functions to {name.title()} dataset")
        main_preprocessor = PreprocessPipeline(fn_list=functions_list)
        transformed_df = main_preprocessor.transform(df)
        logger.info(f"Completed preprocessing for {name.title()} dataset")

        if metrics:
            metrics.track_preprocess_stats(
                dataset_name=name,
                input_count=count,
                output_count=transformed_df.count(),
                columns_selected=transformed_df.columns,
            )
        path_preprocessed = ConfigLoader().get_preprocess_path(file_name=name)

        fs.write_spark_dataframe(transformed_df, path_preprocessed)
        logger.info(
            f"Saved preprocessed {name.title()} dataset at: {path_preprocessed}"
        )

        # Unpersist the DataFrame
        df.unpersist()
        logger.info(f"Unpersisted input DataFrame for {name.title()} dataset.")

    # Set salt_key in task values and metrics
    generated_salt_key_pairs = ConfigLoader().generate_salt_key_pairs(salt_keys)
    dbutils.jobs.taskValues.set(key="salt_key", value=generated_salt_key_pairs)
    metrics.add_metric("salt_key", generated_salt_key_pairs)

    # End time
    metrics.track_total_execution_time_in_seconds()
    metrics.log_metrics_summary()

    # Make updation API call
    database_api.update_match_run_event(
        remove_end_slash=True,
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        metrics=json.dumps(metrics.get_metrics_summary()),
    )
    logger.info("Updated Match Run Event Table Record for Preprocess")
    logger.info(f"Preprocessing completed at: {metrics.end_time}")
    logger.info(f"Total preprocessing time: {metrics.metrics.get('total_execution_in_seconds', None)}")
    logger.info("Preprocessing Job Completed Successfully")


if __name__ == "__main__":
    main()
