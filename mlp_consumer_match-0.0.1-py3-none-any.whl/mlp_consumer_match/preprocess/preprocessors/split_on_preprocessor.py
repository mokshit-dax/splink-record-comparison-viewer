import pyspark.sql.functions as F

from pyspark.sql import DataFrame

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class SplitOnPreprocessor(Preprocessor):
    """
    A preprocessing class that splits a string into a list of items based on a delimeter

    This class extends the `Preprocessor` base class and implements the `preprocess` method
    to split a string column into a list of items based on a delimiter.
    
    Methods:
        preprocess(df, input_col, output_col, delimiter): Splits a string column into a list of items based on a delimiter.
    """
    def __init__(self):
        """
        Initializes the SplitOnPreprocessor class
        """
        super().__init__()

    def preprocess(self, df: DataFrame, input_col: str, output_col: str, delimiter: str) -> DataFrame:
        """ 
        Splits a string column into a list of items based on a delimiter.
        
        Args:
            df (DataFrame): Input PySpark DataFrame.
            input_col (str): string column to split
            output_col (str): output column consisting of list of items
            delimiter (str): Delimiter to split the string column on.

        Returns:
            DataFrame: DataFrame with the split columns.
        """
        
        if not output_col:
            output_col = input_col
            
        # Split the string column using the delimiter
        # Handle nulls by using empty arrays
        df = df.withColumn(
            output_col,
            F.when(
                    F.col(input_col).isNull(),
                    F.array()
                ).otherwise(
                    F.filter(
                        F.split(F.col(input_col), delimiter),
                        lambda x: F.trim(x) != ""
                    )
                )
            )
        
        return df