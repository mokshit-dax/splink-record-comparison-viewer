# combine multiple single columns into a list (append)
# conbine list columns into a single list (extend)

import pyspark.sql.functions as F

from pyspark.sql import DataFrame
from pyspark.sql.types import StringType
from typing import List

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class CombineColsPreprocessor(Preprocessor):
    """
    A preprocessing class that combines multiple columns into a single list column.

    This class extends the `Preprocessor` base class and implements the `preprocess` method
    to combine multiple columns into a single list column. It handles both single value columns
    and array columns, converting single values to arrays and merging all arrays into one.
    
    Methods:
        preprocess(df, input_cols, output_col): Combines multiple columns into a single list column.
    """
    def __init__(self):
        """
        Initializes the CombineColsPreprocessor class
        """
        super().__init__()

    def preprocess(self, df: DataFrame, input_cols: List[str], output_col: str) -> DataFrame:
        """
        Combines multiple columns into a single list column.
        
        - For string columns, converts each value to an array and handles nulls by using empty arrays
        - For array columns, keeps them as they are
        - Merges all arrays into a single array column using flatten operation

        Args:
            df (DataFrame): Input PySpark DataFrame.
            input_cols (List[str]): List of columns to combine.
            output_col (str): Name of the output column that will contain the combined list.

        Returns:
            DataFrame: DataFrame with the combined list column.
        """
        
        array_cols = [
            (
                F.when((F.col(col).isNotNull()) & (F.trim(F.col(col)) != ""), F.array(F.col(col)))
                .otherwise(F.lit([]))
                if isinstance(df.schema[col].dataType, StringType)
                else F.when(F.col(col).isNotNull(), F.col(col)).otherwise(F.lit([]))
            )
            for col in input_cols
        ]

        # Merge all arrays into a single array column
        df = df.withColumn(output_col, F.flatten(F.array(*array_cols)))
        
        return df