from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

from pyspark.sql.functions import rand, floor
from mlp_consumer_match.utils.logging.base_logger import get_logger
from pyspark.sql import DataFrame

logger = get_logger(name="add_salt_key_preprocessor")

class AddSaltKeyPreprocessor(Preprocessor):
    """
    A preprocessing class that adds salt keys to a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to add salt keys to the DataFrame.
    
    Methods:
        preprocess(df, input_cols=None): Adds salt keys to the DataFrame.
    
    """
    def __init__(self):
        """
        Initializes the AddSaltKeyPreprocessor class by calling the superclass constructor.
        Sets the number of salt keys from the preprocess config.
        """
        super().__init__()


    def preprocess(self, df: DataFrame, num_salt_keys: int) -> DataFrame:
        """
        Adds salt keys randomly from the range [1, num_salt_keys] to a DataFrame.
        Used to parition data and run inference on each partition parallely.
        
        Args:
            df (DataFrame): Input PySpark DataFrame.
            num_salt_keys (int): Number of salt keys to add.

        Returns:
            DataFrame: DataFrame with additional salt key column.
        """
        logger.info(f"Adding salt keys to DataFrame with num_salt_keys: {num_salt_keys}")
        df = df.withColumn("salt_key", floor(rand() * num_salt_keys) + 1)

        return df