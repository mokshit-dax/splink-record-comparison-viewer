import usaddress
import pandas as pd

import pyspark.sql.functions as F
import pyspark.sql.types as T

from pyspark.sql import DataFrame

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor
from mlp_consumer_match.preprocess.preprocessors.to_lower_preprocessor import ToLowerPreprocessor
from mlp_consumer_match.preprocess.preprocessors.clean_text_preprocessor import CleanTextPreprocessor
from mlp_consumer_match.preprocess.preprocessors.extract_substring_preprocessor import ExtractSubstringPreprocessor
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)

class AddressStandardizerPreprocessor(Preprocessor):
    """
    A preprocessing class that standardizes address data in specified columns of a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to apply multiple address standardization transformations.
    
    Methods:
        preprocess(df, target_atts, characters_to_remove): Cleans the specified columns.

    Steps:
        1. Lowercase the specified column
        2. Separate the specified column into multiple fields based on address components
        3. Clean the specified columns by removing specified pattern except aplha-numeric and spaces
        4. Extract substrings from the specified columns
        5. Abbreviate the specified columns
        6. Clean the specified columns by removing specified pattern except alpha-numeric
        7. Nullify empty strings in the specified columns
        8. Concatenate the specified columns
    """
    def __init__(self):
        super().__init__()
        self.separate_fields = [
            "street_no",
            "street",
            "pre_directional",
            "post_directional",
            "occupancy_type",
            "occupancy_identifier",
            "place",
            "state",
            "zip_code"
        ]

    def lower_address_fields(self, df: DataFrame, input_col: str, output_col: str):
        """
        Lowercases the specified column in a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column to lowercase
            output_col (str): Name of the column to store the lowercase values
        
        Returns:
            DataFrame: DataFrame with the lowercase column
        """
        logger.info(f"Starting Lowercase Address Field on {output_col} column")
        df = ToLowerPreprocessor().preprocess(df, input_col=input_col, output_col=output_col)
        logger.info(f"Finished Lowercase Address Field on {output_col} column")
        return df

    def separate_address_fields(self, df: DataFrame, input_col: str) -> DataFrame:
        """
        Separates the specified column into multiple fields using a Pandas UDF.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process.
            input_col (str): Name of the column to separate.
        
        Returns:
            DataFrame: DataFrame with the separated columns.
        """
        
        # Define the schema for the output of the Pandas UDF
        output_schema = T.StructType([T.StructField(field, T.StringType()) for field in self.separate_fields])

        @F.pandas_udf(output_schema)
        def separate_fields_udf(addresses: pd.Series) -> pd.DataFrame:
            parsed_data = []
            for address in addresses:
                if not address:
                    parsed_data.append({field: "" for field in self.separate_fields})
                    continue

                try:
                    parsed_address = usaddress.parse(address)
                    addr_dict = {
                        "street_no": "",
                        "street": [],
                        "pre_directional": "",
                        "post_directional": "",
                        "occupancy_type": "",
                        "occupancy_identifier": [],
                        "place": [],
                        "state": "",
                        "zip_code": "",
                    }
                    
                    for key, val in parsed_address:
                        if val == 'AddressNumber':
                            addr_dict["street_no"] = key
                        elif val in ['StreetName', 'StreetNamePreModifier', 'StreetNamePreType', 'StreetNamePostModifier', 'StreetNamePostType', 'USPSBoxType', 'BuildingName', 'LandmarkName', 'SubaddressType', 'SubaddressIdentifier']:
                            addr_dict["street"].append(key)
                        elif val == 'OccupancyType':
                            addr_dict["occupancy_type"] = key
                        elif val in ['OccupancyIdentifier', 'USPSBoxID']:
                            addr_dict["occupancy_identifier"].append(key)
                        elif val == 'StreetNamePreDirectional':
                            addr_dict["pre_directional"] = key
                        elif val == 'StreetNamePostDirectional':
                            addr_dict["post_directional"] = key
                        elif val == 'PlaceName':
                            addr_dict["place"].append(key)
                        elif val == 'StateName':
                            addr_dict["state"] = key
                        elif val == 'ZipCode':
                            addr_dict["zip_code"] = key
                            
                    addr_dict["street"] = ' '.join(addr_dict["street"])
                    addr_dict["occupancy_identifier"] = ' '.join(addr_dict["occupancy_identifier"])
                    addr_dict["place"] = ' '.join(addr_dict["place"])
                    
                    final_data = {field: addr_dict.get(field, "") for field in self.separate_fields}
                    parsed_data.append(final_data)

                except Exception as e:
                    logger.error(f"Error parsing address: {address}. Error: {e}")
                    parsed_data.append({field: "" for field in self.separate_fields})

            return pd.DataFrame(parsed_data, columns=self.separate_fields)

        logger.info(f"Starting Address Field Separation on '{input_col}' column using Pandas UDF")
        
        temp_col = f"parsed_{input_col}"
        df_with_struct = df.withColumn(temp_col, separate_fields_udf(F.col(input_col)))

        final_df = df_with_struct.select("*", *(F.col(temp_col)[field].alias(f"{input_col}_{field}") for field in self.separate_fields))
        final_df = final_df.drop(temp_col)

        logger.info("Finished Separating Address Fields")
        return final_df

    def abbreviate_address_fields(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Abbreviates the specified columns in a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to abbreviate
        
        Returns:
            DataFrame: DataFrame with the abbreviated columns
        """
        logger.info(f"Starting Address Field Abbreviation")
        abbreviator = CleanTextPreprocessor()

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_street",
            output_col=f"{output_col}_street",
            regex_transformations= {
                "\\bavenue\\b": "ave", 
                "\\bboulevard\\b": "blvd", 
                "\\bcircle\\b": "cir", 
                "\\bcourt\\b": "ct", 
                "\\bdrive\\b": "dr", 
                "\\bhighway\\b": "hwy", 
                "\\blane\\b": "ln", 
                "\\bparkway\\b": "pkwy", 
                "\\bplace\\b": "pl", 
                "\\bplaza\\b": "plz", 
                "\\broad\\b": "rd", 
                "\\bsquare\\b": "sq", 
                "\\bstreet\\b": "st"
            }   
        )

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_occupancy_type",
            output_col=f"{output_col}_occupancy_type",
            regex_transformations= {
                    # Apartment/Apt
                    "\\bappartment\\b": "apt",
                    "\\bapartmnt\\b": "apt",
                    "\\baprt\\b": "apt",
                    "\\bappt\\b": "apt",
                    "\\baptmnt\\b": "apt",
                    "\\bunit\\b": "apt",
                    "\\bun\\b": "apt",
                    "\\b#\\b": "apt",

                    # Suite/Ste
                    "\\bsuite\\b": "ste",
                    "\\bsuit\\b": "ste",
                    "\\bst\\b": "ste",
                    "\\bsu\\b": "ste",

                    # Room/Rm
                    "\\broom\\b": "rm",
                    "\\brm\\b": "rm",

                    # Floor/Fl
                    "\\bfloor\\b": "fl",
                    "\\bflr\\b": "fl",

                    # Building/Bldg
                    "\\bbuilding\\b": "bldg",
                    "\\bbld\\b": "bldg",

                    # Lot/Lot
                    "\\blot\\b": "lot",

                    # Department/Dept
                    "\\bdepartment\\b": "dept",
                    "\\bdep\\b": "dept",
                    "\\bdpt\\b": "dept",

                    # Office/Ofc
                    "\\boffice\\b": "ofc",
                    "\\boff\\b": "ofc",

                    # Other less common but possible designators
                    "\\bspace\\b": "spc",
                    "\\bspc\\b": "spc",
                    "\\bbox\\b": "box",
                    "\\bpobox\\b": "box",
                    "\\bpo box\\b": "box",
                    "\\bpo bx\\b": "box",
                    "\\bpost office box\\b": "box",
                }
        )

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_pre_directional",
            output_col=f"{output_col}_pre_directional",
            regex_transformations= { "\\beast\\b": "e", "\\bnorth\\b": "n", "\\bsouth\\b": "s", "\\bwest\\b": "w", "\\bnortheast\\b": "ne", "\\bnorthwest\\b": "nw", "\\bsoutheast\\b": "se", "\\bsouthwest\\b": "sw"}
        )

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_post_directional",
            output_col=f"{output_col}_post_directional",
            regex_transformations= { "\\beast\\b": "e", "\\bnorth\\b": "n", "\\bsouth\\b": "s", "\\bwest\\b": "w", "\\bnortheast\\b": "ne", "\\bnorthwest\\b": "nw", "\\bsoutheast\\b": "se", "\\bsouthwest\\b": "sw"}
        )

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_state",
            output_col=f"{output_col}_state",
            regex_transformations={"\\balabama\\b":"al","\\balaska\\b":"ak","\\barizona\\b":"az","\\barkansas\\b":"ar","\\bcalifornia\\b":"ca","\\bcolorado\\b":"co","\\bconnecticut\\b":"ct","\\bdelaware\\b":"de","\\bflorida\\b":"fl","\\bageorgia\\b":"ga","\\bhawaii\\b":"hi","\\bidaho\\b":"id","\\billinois\\b":"il","\\bindiana\\b":"in","\\biowa\\b":"ia","\\bkansas\\b":"ks","\\bkentucky\\b":"ky","\\blouisiana\\b":"la","\\bmaine\\b":"ma","\\bmaryland\\b":"md","\\bmassachusetts\\b":"ma","\\bmichigan\\b":"mi","\\bminnesota\\b":"mn","\\bmississippi\\b":"ms","\\bmissouri\\b":"mo","\\bmontana\\b":"mt","\\bnebraska\\b":"ne","\\bnevada\\b":"nv","\\bnew hampshire\\b":"nh","\\bnew jersey\\b":"nj","\\bnew mexico\\b":"nm","\\bnew york\\b":"ny","\\bnorth carolina\\b":"nc","\\bnorth dakota\\b":"nd","\\bohio\\b":"oh","\\boklahoma\\b":"ok","\\borregon\\b":"or","\\bpennsylvania\\b":"pa","\\brhode island\\b":"ri","\\bsouth carolina\\b":"sc","\\bsouth dakota\\b":"sd","\\btennessee\\b":"tn","\\btexas\\b":"tx","\\butah\\b":"ut","\\bvermont\\b":"vt","\\bvirginia\\b":"va","\\bwashington\\b":"wa","\\bwest virginia\\b":"wv","\\bwisconsin\\b":"wi","\\bwyoming\\b":"wy","\\bdistrict of columbia\\b":"dc"}
        )

        df = abbreviator.preprocess(
            df=df,
            input_col=f"{output_col}_place",
            output_col=f"{output_col}_place",
            regex_transformations= {"\\bnew york\\b":"ny","\\bnewyork\\b":"ny","\\bnyc\\b":"ny","\\blos angeles\\b":"la","\\bla\\b":"la","\\bchicago\\b":"chi","\\bhouston\\b":"hou","\\bphoenix\\b":"phx","\\bphiladelphia\\b":"phl","\\bsan antonio\\b":"sat","\\bsan diego\\b":"sd","\\bdallas\\b":"dal","\\bsan jose\\b":"sj","\\baustin\\b":"atx","\\bjacksonville\\b":"jax","\\bfort worth\\b":"fw","\\bcolumbus\\b":"cbus","\\bcharlotte\\b":"clt","\\bsan francisco\\b":"sf","\\bdenver\\b":"den","\\bsseattle\\b":"sea","\\bwashington\\b":"dc","\\bboston\\b":"bos","\\bnashville\\b":"bna","\\bdetroit\\b":"det","\\bmiami\\b":"mia","\\batlanta\\b":"atl","\\bminneapolis\\b":"mpls","\\bnew orleans\\b":"nola","\\blas vegas\\b":"lv","\\bbaltimore\\b":"bal","\\bst louis\\b":"stl","\\bkansas city\\b":"kc"}
        )

        logger.info(f"Finished Address Field Abbreviation")
        return df

    def clean_address_fields(self, df: DataFrame, output_col: str, pattern: str = '[^a-zA-Z0-9]') -> DataFrame:
        """
        Cleans the specified columns in a DataFrame by removing specified pattern.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to clean
            pattern (str, optional): Regular expression pattern to match characters to remove. Defaults to '[^a-zA-Z0-9]'.
        
        Returns:
            DataFrame: DataFrame with the cleaned columns
        """
        logger.info(f"Starting Address Field Cleaning [removing {pattern}]")
        for field in self.separate_fields:
            df = CleanTextPreprocessor().preprocess(
                df=df,
                input_col=f"{output_col}_{field}",
                output_col=f"{output_col}_{field}",
                regex_transformations={pattern: ''}
            )
        logger.info(f"Finished Address Field Cleaning [removed {pattern}]")
        return df

    
    def extract_substring_from_address_field(self, df: DataFrame, output_col: str, start: int, length: int) -> DataFrame:
        """
        Extracts substrings from the specified address field in a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to extract substrings from
            start (int): Start index of the substring
            length (int): End index of the substring
        
        Returns:
            DataFrame: DataFrame with the extracted substrings
        """
        logger.info(f"Starting Address Field Substring Extraction on {output_col}")
        df = ExtractSubstringPreprocessor().preprocess(
            df=df,
            input_col=output_col,
            output_col=output_col,
            start=start,
            length=length
        )
        logger.info(f"Finished Address Field Substring Extraction on {output_col}")
        return df


    def nullify_empty_address_fields(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Nullifies empty strings in the specified columns of a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to nullify empty strings
        
        Returns:
            DataFrame: DataFrame with nullified empty strings
        """
        logger.info(f"Starting Empty Address Field Nullification [nullifying empty strings]")
        cols_to_select = [
            F.when(F.col(f"{output_col}_{field}") == "", None).otherwise(F.col(f"{output_col}_{field}")).alias(f"{output_col}_{field}")
            for field in self.separate_fields
        ]
        existing_cols = [c for c in df.columns if c not in [f"{output_col}_{field}" for field in self.separate_fields]]
        df = df.select(*existing_cols, *cols_to_select)
        logger.info(f"Finished Empty Address Field Nullification [nullified empty strings]")
        return df


    def concat_address_fields(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Concatenates the specified columns in a DataFrame into a single column.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to concatenate
        
        Returns:
            DataFrame: DataFrame with the concatenated column
        """
        logger.info(f"Starting Address Field Concatenation on {self.separate_fields} columns")

        def concat_fields(street_no, street, pre_directional, post_directional, occupancy_type, occupancy_identifier, place, state, zip_code):
            parts = []
            if street_no is not None:
                parts.append(str(street_no))
            if street is not None:
                parts.append(str(street))
            if pre_directional is not None:
                parts.append(str(pre_directional))
            if post_directional is not None:
                parts.append(str(post_directional))
            if occupancy_type is not None:
                parts.append(str(occupancy_type))
            if occupancy_identifier is not None:
                parts.append(str(occupancy_identifier))
            if place is not None:
                parts.append(str(place))
            if state is not None:
                parts.append(str(state))
            if zip_code is not None:
                parts.append(str(zip_code))
            try:
                return "".join(parts) if parts else None
            except Exception as e:
                logger.error(f"Error during concatenation: {e}")
                return None

        concat_udf = F.udf(concat_fields, T.StringType())
        df = df.withColumn(output_col, concat_udf(*[F.col(f"{output_col}_{col}") for col in self.separate_fields]))
        logger.info(f"Finished Address Field Concatenation")
        return df


    def preprocess(self, df: DataFrame, input_col: str, output_col: str, abbreviate_fields: bool = True) -> DataFrame:
        """
        Preprocesses the specified column in a DataFrame by applying multiple transformations.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column to preprocess
            output_col (str): Name of the column to store the processed values
            abbreviate_fields (bool, optional): Whether to abbreviate the address fields. Defaults to True.
        
        Returns:
            DataFrame: DataFrame with the processed column
        """
        logger.info(f"Starting Address Preprocessing on {input_col} column to make {output_col}")
        if not output_col:
            output_col = input_col

        df = self.lower_address_fields(df, input_col=input_col, output_col=output_col)

        df = self.separate_address_fields(df, output_col)

        df = self.extract_substring_from_address_field(df, output_col=f"{output_col}_zip_code", start=0, length=5)

        df = self.clean_address_fields(df, output_col, pattern='[^a-zA-Z0-9\\s]')

        if abbreviate_fields:
            df = self.abbreviate_address_fields(df, output_col)

        df = self.clean_address_fields(df, output_col)

        df = self.nullify_empty_address_fields(df, output_col)

        df = self.concat_address_fields(df, output_col)

        separated_field_names = [f"{output_col}_{field}" for field in self.separate_fields]
        logger.info(f"Finished Address Standardization on {input_col} column to make {output_col} column with following separated fields: {separated_field_names}")
        return df