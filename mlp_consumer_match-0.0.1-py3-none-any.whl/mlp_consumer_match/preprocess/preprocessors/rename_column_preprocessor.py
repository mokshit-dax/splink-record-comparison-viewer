from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class RenameColumnPreprocessor(Preprocessor):
    """
    A preprocessing class that renames a specified column in a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to rename a specified column in a DataFrame.

    Methods:
        preprocess(df, input_col, output_col): Applies lowercase transformation to the input column.
    """

    def __init__(self):
        """
        Initializes the RenameColumnPreprocessor class.

        This class does not require additional initialization parameters, 
        but it calls the parent `Preprocessor` constructor.
        """
        super().__init__()


    def preprocess(self, df, input_col, output_col):
        """
        Renames the specified input column to the new column name.

        Args:
            df (DataFrame): The DataFrame containing the data to be transformed.
            input_col (str): The name of the column to be renamed.
            output_col (str): The name of the new column name.

        Returns:
            DataFrame: The transformed DataFrame with the specified column renamed.
        """
        df = df.withColumnRenamed(input_col, output_col)
        return df