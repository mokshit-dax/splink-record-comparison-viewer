import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.functions import col

from pyspark.sql import DataFrame

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class ExtractSubstringPreprocessor(Preprocessor):
    """
    A preprocessor class that extracts substrings from a specified column in a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method
    to extract substrings from a specified column using PySpark's substring function.
    
    Methods:
        preprocess(df: DataFrame, input_col: str, lower: int, upper: int) -> DataFrame:
            Extracts a substring from the specified column based on the given position range.
    """
    
    def __init__(self):
        """
        Initializes the ExtractSubstringPreprocessor class by calling the superclass constructor.
        """
        super().__init__()


    def preprocess(self, df: DataFrame, input_col: str, start: int, length: int, output_col: str = None) -> DataFrame:
        """
        Extracts a substring from the specified column based on the given position range.

        Args:
            df (DataFrame): Input DataFrame.
            input_col (str): Name of the column to extract substring from.
            start (int): Starting position of the substring (1-based index).
            length (int): Length of the substring to extract.
            output_col (str, optional): The name of the column where the transformed values will be stored.
                                    If not provided, the transformation is applied in-place on `input_col`.

        Returns:
            DataFrame: DataFrame with the modified column containing the extracted substring.
        """
        if not output_col:
            output_col = input_col

        return df.withColumn(output_col, F.col(input_col).substr(start, length))