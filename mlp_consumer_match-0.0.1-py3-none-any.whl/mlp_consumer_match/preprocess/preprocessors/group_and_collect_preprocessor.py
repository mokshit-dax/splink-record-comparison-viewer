from pyspark.sql import DataFrame
from pyspark.sql.functions import collect_set
from typing import List

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class GroupAndCollectPreprocessor(Preprocessor):
    """
    A preprocessing class that groups specified columns and collects unique values from remaining columns in a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to group specified columns and collect unique values from remaining columns using PySpark functions.

    Methods:
        preprocess(df, group_cols): Groups the DataFrame by group columns and collects unique values for the remaining columns.
    """

    def __init__(self):
        """
        Initializes the GroupAndCollectPreprocessor class.

        This class does not require additional initialization parameters, 
        but it calls the parent `Preprocessor` constructor.
        """
        super().__init__()


    def preprocess(self, df: DataFrame, group_cols: List) -> DataFrame:
        """
        Groups the DataFrame by input columns and collects unique values for the remaining columns.

        Args:
            df (DataFrame): The DataFrame containing the data to be transformed.
            group_cols (List): The name of the columns whose values should be grouped.

        Returns:
            DataFrame: The transformed DataFrame with the specified columns grouped and remaining columns collected with their unique values.
        """ 
        if not group_cols:
            return df
        
        # Convert ListConfig Type to regular list type
        group_cols_list = list(group_cols)

        # Collect unique values for each column not in group_cols 
        collected_cols = [collect_set(c).alias(c) for c in df.columns if c not in group_cols_list]
        return df.groupBy(group_cols_list).agg(*collected_cols)