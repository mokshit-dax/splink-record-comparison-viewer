import pyspark.sql.functions as F 

from pyspark.sql import DataFrame

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor
from mlp_consumer_match.preprocess.preprocessors.extract_substring_preprocessor import ExtractSubstringPreprocessor
from mlp_consumer_match.preprocess.preprocessors.clean_text_preprocessor import CleanTextPreprocessor
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)


class PhoneStandardizerPreprocessor(Preprocessor):
    """
    A preprocessing class that standardizes phone data in specified columns of a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to apply multiple phone standardization transformations.
    
    Methods:
        preprocess(df, target_atts, characters_to_remove): Cleans the specified columns.

    Steps:
        1. Clean the specified phone number by removing non-numeric characters
        2. Nullify empty strings in the specified column 
        3. Extract substrings from the specified columns (last 10 characters)
        4. Nullify invalid phone numbers in the specified column 
    """
    def __init__(self):
        super().__init__()

    def clean_phone_field(self, df: DataFrame, input_col: str, output_col: str) -> DataFrame:
        """
        Cleans the specified phone number by removing specified pattern except numeric characters.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column containing phone number to clean
            output_col (str): Name of the column to store the cleaned phone number
        
        Returns:
            DataFrame: DataFrame with the cleaned phone number
        """
        logger.info(f"Starting Clean Phone Field on '{input_col}' column")
        df = CleanTextPreprocessor().preprocess(
            df=df, 
            input_col=input_col, 
            output_col=output_col, 
            regex_transformations={'[^0-9]': ''}
        )
        logger.info(f"Finished Clean Phone Field on '{input_col}' column")
        return df

    def nullify_empty_phone_field(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Nullifies empty strings in the specified column.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to store the cleaned phone number
        
        Returns:
            DataFrame: DataFrame with the nullified empty strings
        """
        logger.info(f"Starting Empty Phone Field Nullification")
        df = df.withColumn(output_col, F.when(F.trim(F.col(output_col)) == "", None).otherwise(F.col(output_col)))
        logger.info(f"Finished Empty Phone Field Nullification")
        return df

    def nullify_invalid_phone_field(self, df: DataFrame, output_col: str, invalid_phone_pattern: str) -> DataFrame:
        """
        Nullifies invalid phone numbers in the specified column.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to store the cleaned phone number
            invalid_phone_pattern (str): Pattern to identify invalid phone numbers
        
        Returns:
            DataFrame: DataFrame with the nullified invalid phone numbers
        """
        logger.info(f"Starting Invalid Phone Field Nullification [invalid_phone_pattern={invalid_phone_pattern}]")
        df = df.withColumn(output_col, F.when(F.col(output_col).rlike(invalid_phone_pattern), None).otherwise(F.col(output_col)))
        logger.info(f"Finished Invalid Phone Field Nullification [invalid_phone_pattern={invalid_phone_pattern}]")
        return df

    def extract_substring_from_phone_field(self, df: DataFrame, output_col: str, start: int, length: int) -> DataFrame:
        """
        Extracts substrings from the specified phone number.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to store the transformed values.
            start (int): Start index of the substring to extract
            length (int): Length of the substring to extract
        
        Returns:
            DataFrame: DataFrame with the extracted substrings
        """
        logger.info(f"Starting Extract Substring from Phone Field on '{output_col}' column [start={start}, length={length}]")
        df = ExtractSubstringPreprocessor().preprocess(
            df=df, 
            input_col=output_col, 
            output_col=output_col, 
            start=start,
            length=length
        )
        logger.info(f"Finished Extract Substring from Phone Field on '{output_col}' column [start={start}, length={length}]")
        return df

    def preprocess(self, df: DataFrame, input_col: str, output_col: str = None, invalid_phone_pattern: str = r"^([0-9])\1{9}$") -> DataFrame:
        """
        Cleans the specified phone number by removing specified pattern except numeric characters.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column containing phone number to preprocess
            output_col (str, optional): Name of the column to store the transformed values.
                                  If not provided, transformations are applied in-place on `input_col`
            invalid_phone_pattern (str, optional): Pattern to identify invalid phone numbers
        
        Returns:
            DataFrame: DataFrame with the cleaned phone number
        """
        logger.info(f"Starting Phone Preprocessing on {input_col} column to make {output_col}")
        if not output_col:
            output_col = input_col

        df = self.clean_phone_field(df, input_col, output_col)

        df = self.nullify_empty_phone_field(df, output_col)
        
        df = self.extract_substring_from_phone_field(df, output_col, start=-10, length=10)

        if invalid_phone_pattern:
            df = self.nullify_invalid_phone_field(df, output_col, invalid_phone_pattern)

        logger.info(f"Finished Phone Preprocessing on {input_col} column to make {output_col}")
        return df