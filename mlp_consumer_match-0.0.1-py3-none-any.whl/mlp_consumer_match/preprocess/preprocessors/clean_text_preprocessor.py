import re

from omegaconf.listconfig import ListConfig
from omegaconf.dictconfig import DictConfig

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, regexp_replace, trim, when, lit
from typing import List, Dict, Any, Union
from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor


class CleanTextPreprocessor(Preprocessor):
    """
    A preprocessing class that cleans text data in specified columns of a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to apply multiple text cleaning transformations.
    
    Methods:
        preprocess(df, target_atts, characters_to_remove): Cleans the specified columns.
    """

    def __init__(self):
        """
        Initializes the CleanTextPreprocessor class.
        """
        super().__init__()

    def preprocess(self, df: DataFrame, input_col: str, output_col: str = None, 
                  text_transformations: Union[List[str], Dict[str, Any]] = None,
                  regex_transformations: Dict[str, Any] = None) -> DataFrame:
        """
        Cleans text data in a specified column of a DataFrame.
        
        - Removes or replaces user-defined terms/characters based on text_transformations.
        - If text_transformations is a list, removes those terms.
        - If text_transformations is a dict, replaces keys with corresponding values.
        - If regex_transformations is provided, applies regex-based transformations.
        - If no regex_transformations are specified, removes all special characters.
        - Trims extra spaces before applying transformations.

        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column containing text to preprocess
            output_col (str, optional): Name of the column to store the transformed values.
                                      If not provided, transformations are applied in-place on `input_col`
            text_transformations (Union[List[str], Dict[str, Any]], optional): 
                - If List[str]: List of words/characters to remove from the text
                - If Dict[str, Any]: Dictionary mapping values to replace (key) with their replacements (value)
            regex_transformations (Dict[str, Any], optional): 
                - Dictionary of regex patterns to replace (key) with their replacements (value)

        Returns:
            DataFrame: DataFrame with the processed text column
        """
        # Set output column to input column if not specified
        if not output_col:
            output_col = input_col

        df = df.withColumn(output_col, col(input_col))
        df = df.withColumn(output_col, trim(col(output_col)))

        # Set default regex transformations if none provided
        regex_transformations = {"(?!)": ""} if not regex_transformations else regex_transformations

        # Apply user-defined text transformations if provided
        if text_transformations:
            if isinstance(text_transformations, ListConfig):
                # Create regex pattern to remove all specified terms
                remove_pattern = r'\b(' + '|'.join(map(re.escape, text_transformations)) + r')\b'
                df = df.withColumn(output_col, regexp_replace(col(output_col), remove_pattern, ''))
            elif isinstance(text_transformations, DictConfig):
                # Apply each key-value replacement
                for old_value, new_value in text_transformations.items():
                    if new_value == "None":
                        # Replace exact matches with None
                        df = df.withColumn(output_col, when(col(output_col) == old_value, None).otherwise(col(output_col)))
                    else:
                        # Replace using regex pattern
                        pattern = rf"\\b{re.escape(old_value)}\\b"
                        df = df.withColumn(output_col, regexp_replace(col(output_col), pattern, new_value))

        # Apply regex transformations to remove special characters
        for pattern, replacement in regex_transformations.items():
            if replacement == "None":
                # Replace exact matches with None
                df = df.withColumn(output_col, when(regexp_replace(col(output_col), pattern, '') == '', None).otherwise(regexp_replace(col(output_col), pattern, '')))
            else:
                # Replace using regex pattern
                df = df.withColumn(output_col, regexp_replace(col(output_col), pattern, replacement))

        return df