import pyspark.sql.functions as F

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class ToLowerPreprocessor(Preprocessor):
    """
    A preprocessing class that converts the values of a specified column in a DataFrame to lowercase.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to transform string data into lowercase using PySpark functions.

    Methods:
        preprocess(df, input_col, output_col=None): Applies lowercase transformation to the input column.
    """

    def __init__(self):
        """
        Initializes the ToLowerPreprocessor class.

        This class does not require additional initialization parameters, 
        but it calls the parent `Preprocessor` constructor.
        """
        super().__init__()


    def preprocess(self, df, input_col, output_col=None):
        """
        Converts the values of the specified input column to lowercase and stores them in the output column.

        Args:
            df (DataFrame): The DataFrame containing the data to be transformed.
            input_col (str): The name of the column whose values should be converted to lowercase.
            output_col (str, optional): The name of the column where the transformed values will be stored.
                                        If not provided, the transformation is applied in-place on `input_col`.

        Returns:
            DataFrame: The transformed DataFrame with the specified column in lowercase.
        """
        if not output_col:
            output_col = input_col
        df = df.withColumn(output_col, F.lower(input_col))
        return df