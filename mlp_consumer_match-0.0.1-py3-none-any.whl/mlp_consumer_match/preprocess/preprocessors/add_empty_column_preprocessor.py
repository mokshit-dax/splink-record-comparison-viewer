from pyspark.sql import DataFrame
from pyspark.sql.functions import lit
from pyspark.sql.types import StringType

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)

class AddEmptyColumnPreprocessor(Preprocessor):
    def __init__(self):
        """
        Initializes the AddEmptyColumnPreprocessor class by calling the superclass constructor.
        """
        super().__init__()

    def preprocess(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Adds an empty column to the DataFrame.

        Args:
            df (DataFrame): Input PySpark DataFrame.
            output_col (str): Name of the column to add.

        Returns:
            DataFrame: DataFrame with additional empty column.
        """
        if output_col in df.columns:
            raise ValueError(f"Column {output_col} already exists in the DataFrame")

        logger.info(f"Adding empty column: {output_col}")
        df = df.withColumn(output_col, lit(None).cast(StringType()))
        logger.info(f"Columns: {df.columns}")

        return df
    