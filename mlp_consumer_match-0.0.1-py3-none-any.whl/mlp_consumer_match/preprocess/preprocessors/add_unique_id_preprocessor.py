import pyspark.sql.functions as F

from pyspark.sql import DataFrame
from typing import List

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class AddUniqueIDPreprocessor(Preprocessor):
    """
    A preprocessing class that adds a unique ID to a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to add a unique ID to the DataFrame.
    
    Methods:
        preprocess(df, input_cols=None): Adds a unique ID to the DataFrame.
    
    """
    def __init__(self):
        """
        Initializes the AddUniqueIDPreprocessor class by calling the superclass constructor.
        """
        super().__init__()

    def preprocess(self, df: DataFrame, input_cols: List[str] = None) -> DataFrame:
        """
        Adds a unique ID to a DataFrame.
        
        - If input_cols is a list of columns, the unique ID is created by concatenating the values of the columns with ":" separator.
        - If no input_cols are specified, the unique ID is created by using pyspark function to create incremental column.

        Args:
            df (DataFrame): Input PySpark DataFrame.
            input_cols (List[str], optional): List of columns to use for creating unique ID.

        Returns:
            DataFrame: DataFrame with added unique ID.
        """
        if input_cols:
            concat_expr = df[input_cols[0]].cast('string')
            for col in input_cols[1:]:
                concat_expr = F.concat(concat_expr, F.lit(':'), df[col].cast('string'))
            df = df.withColumn('unique_id', concat_expr)
        else:
            df = df.withColumn('unique_id', F.monotonically_increasing_id().cast('string'))

        return df