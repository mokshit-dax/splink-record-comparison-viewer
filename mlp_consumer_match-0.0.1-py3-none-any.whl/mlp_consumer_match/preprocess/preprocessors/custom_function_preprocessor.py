import pandas as pd
import pyspark.sql.functions as F

from pyspark.sql import DataFrame
from typing import Dict, List

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor

class CustomFunctionPreprocessor(Preprocessor):
    """
    A preprocessor class that applies a custom user-defined function (UDF) to a DataFrame.

    This class allows the execution of a dynamically defined Python function as a UDF on a specified set of columns 
    within a Spark DataFrame. The function definition and function name are provided as arguments, 
    enabling flexible data transformations.
    
    Methods:
        preprocess(df: DataFrame, input_cols: list, output_cols_mapping: Dict, function_name: str, function_def: str) -> DataFrame:
            Applies the user-defined function to the input DataFrame and adds new columns with the results.
    """
    
    def __init__(self):
        """
        Initializes the CustomFunctionPreprocessor class by calling the superclass constructor.
        """
        super().__init__()
    
    def preprocess(
        self, df: DataFrame, input_cols: List, output_cols_mapping: Dict, function_name: str, function_def: str) -> DataFrame:
        """
        Applies a dynamically defined user function to a DataFrame and adds new columns with the computed values.

        Args:
            df (DataFrame): The input Spark DataFrame.
            input_cols (list): List of input column names that will be passed to the function.
            output_cols_mapping (dict): A dictionary mapping output column names to their corresponding types.
            function_name (str): The name of the function to execute.
            function_def (str): The string definition of the function to execute (must be a valid Python function).

        Returns:
            DataFrame: A new DataFrame with the output columns containing the results of the function.
        """

        def construct_schema(output_cols):
            schema_str = ", ".join([f"`{name}` {col_type.upper()}" for name, col_type in output_cols.items()])
            return schema_str
        
        local_scope = {}
        exec(function_def, globals(), local_scope)

        custom_function = local_scope[function_name]

        schema = construct_schema(output_cols_mapping)
                    
        @F.pandas_udf(schema)
        def custom_udf(*cols):
            X = pd.concat([pd.Series(col) for col in cols], axis=1)
            X.columns = input_cols

            results = []
            for idx, row in X.iterrows():
                result = custom_function(*row.values)
                results.append(result)

            result_df = pd.DataFrame(results, columns=list(output_cols_mapping.keys()))

            return result_df
        
        df = df.withColumn("predictions", custom_udf(*[F.col(c) for c in input_cols]))

        for col_name in output_cols_mapping.keys():
            df = df.withColumn(col_name, F.col("predictions")[col_name])

        df = df.drop("predictions")

        return df