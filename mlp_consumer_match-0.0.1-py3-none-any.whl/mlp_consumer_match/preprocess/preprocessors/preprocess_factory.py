from mlp_consumer_match.preprocess.preprocessors.add_nicknames_preprocessor import AddNicknamesPreprocessor
from mlp_consumer_match.preprocess.preprocessors.clean_text_preprocessor import CleanTextPreprocessor
from mlp_consumer_match.preprocess.preprocessors.custom_function_preprocessor import CustomFunctionPreprocessor
from mlp_consumer_match.preprocess.preprocessors.rename_column_preprocessor import RenameColumnPreprocessor
from mlp_consumer_match.preprocess.preprocessors.to_lower_preprocessor import ToLowerPreprocessor
from mlp_consumer_match.preprocess.preprocessors.group_and_collect_preprocessor import GroupAndCollectPreprocessor
from mlp_consumer_match.preprocess.preprocessors.add_unique_id_preprocessor import AddUniqueIDPreprocessor
from mlp_consumer_match.preprocess.preprocessors.add_salt_key_preprocessor import AddSaltKeyPreprocessor
from mlp_consumer_match.preprocess.preprocessors.extract_substring_preprocessor import ExtractSubstringPreprocessor
from mlp_consumer_match.preprocess.preprocessors.combine_cols_preprocessor import CombineColsPreprocessor
from mlp_consumer_match.preprocess.preprocessors.split_on_preprocessor import SplitOnPreprocessor
from mlp_consumer_match.preprocess.preprocessors.add_empty_column_preprocessor import AddEmptyColumnPreprocessor
from mlp_consumer_match.preprocess.preprocessors.address_standardizer_preprocessor import AddressStandardizerPreprocessor
from mlp_consumer_match.preprocess.preprocessors.phone_standardizer_preprocessor import PhoneStandardizerPreprocessor
from mlp_consumer_match.preprocess.preprocessors.business_name_standardizer_preprocessor import BusinessNameStandardizerPreprocessor

class PreprocessFactory:
    """
    A factory class for creating preprocessor instances based on the specified type.
    """

    @staticmethod
    def get_preprocessor(preprocessor_type):
        """
        Returns an instance of the specified preprocessor type.

        Args:
            preprocessor_type (str): The type of preprocessor to instantiate.

        Returns:
            An instance of the corresponding preprocessor class.

        Raises:
            ValueError: If the preprocessor type is not recognized.
        """
        preprocessor_mapping = {
            'to_lower': ToLowerPreprocessor(),
            'rename_column': RenameColumnPreprocessor(),
            'clean_text': CleanTextPreprocessor(),
            'add_nicknames': AddNicknamesPreprocessor(),
            'group_and_collect': GroupAndCollectPreprocessor(),
            'custom_function': CustomFunctionPreprocessor(),
            'add_unique_id': AddUniqueIDPreprocessor(),
            'add_salt_key': AddSaltKeyPreprocessor(),
            'extract_substring': ExtractSubstringPreprocessor(),
            'combine_cols': CombineColsPreprocessor(),
            'split_on': SplitOnPreprocessor(),
            'add_empty_column': AddEmptyColumnPreprocessor(),
            'address_standardizer': AddressStandardizerPreprocessor(),
            'phone_standardizer': PhoneStandardizerPreprocessor(),
            'business_name_standardizer': BusinessNameStandardizerPreprocessor(),
        }

        if preprocessor_type not in preprocessor_mapping:
            raise ValueError(f"Preprocessor type '{preprocessor_type}' is not recognized.")

        return preprocessor_mapping[preprocessor_type]