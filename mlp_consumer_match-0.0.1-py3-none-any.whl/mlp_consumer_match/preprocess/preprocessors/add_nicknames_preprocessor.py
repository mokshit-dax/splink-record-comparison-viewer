import pandas as pd

from nicknames import NickNamer
from pyspark.sql import DataFrame
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import ArrayType, StringType

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor
from mlp_consumer_match.conf.config_loader import ConfigLoader


class AddNicknamesPreprocessor(Preprocessor):
    """
    A preprocessor class that adds a column of nicknames to a DataFrame based on a specified input column.

    This class reads a nicknames file from an S3 path, processes it to create a `NickNamer` instance,
    and uses it to generate possible nicknames and canonical forms for each name in the DataFrame.

    Methods:
        preprocess(df: DataFrame, input_col: str) -> DataFrame:
            Adds a 'nicknames' column to the DataFrame based on the given input column containing names.
    """

    def __init__(self):
        """
        Initializes the AddNicknamesPreprocessor class by calling the superclass constructor.
        """
        super().__init__()
        self.nn = NickNamer.from_csv(ConfigLoader().get_nicknames_file_path())

    def preprocess(self, df: DataFrame, input_col: str) -> DataFrame:
        """
        Adds a column of nicknames to the DataFrame based on the specified input column.

        Args:
            df (DataFrame): Input DataFrame.
            input_col (str): Name of the column containing first names.

        Returns:
            DataFrame: DataFrame with an added 'nicknames' column, containing a list of possible nicknames.
        """
        @pandas_udf(ArrayType(StringType()))
        def generate_nicknames(names: pd.Series) -> pd.Series:
            return names.apply(
                lambda x: (
                    list(self.nn.nicknames_of(x) | self.nn.canonicals_of(x))
                    if pd.notnull(x)
                    else []
                )
            )

        # Apply the UDF to add the nicknames column
        df = df.withColumn("nicknames", generate_nicknames(df[input_col]))

        return df
