import pyspark.sql.functions as F
from pyspark.sql import DataFrame

from mlp_consumer_match.preprocess.preprocessors.preprocessor import Preprocessor
from mlp_consumer_match.preprocess.preprocessors.to_lower_preprocessor import ToLowerPreprocessor
from mlp_consumer_match.preprocess.preprocessors.clean_text_preprocessor import CleanTextPreprocessor
from mlp_consumer_match.preprocess.preprocessors.split_on_preprocessor import SplitOnPreprocessor
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)

class BusinessNameStandardizerPreprocessor(Preprocessor):
    """
    A preprocessing class that standardizes business name data in specified columns of a DataFrame.

    This class extends the `Preprocessor` base class and implements the `preprocess` method 
    to apply multiple business name standardization transformations.
    
    Methods:
        preprocess(df, target_atts): Cleans the specified columns.

    Steps:
        1. Lowercase the specified column
        2. Remove commonly occuring terms like Ltd., Corp from the specified column
        3. Clean the specified columns by removing specified pattern except alpha-numeric, if list then preserve commas
        4. Split the specified columns on commas if list
        5. Nullify empty strings in the specified columns
    """
    def __init__(self):
        super().__init__()

    def _lower_business_name_fields(self, df: DataFrame, input_col: str, output_col: str):
        """
        Lowercases the specified column in a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column to lowercase
            output_col (str): Name of the column to store the lowercase values
        
        Returns:
            DataFrame: DataFrame with the lowercase column
        """
        temp_col = f"{output_col}_temp_lower"
        logger.info(f"Starting Lowercase Business Name Field on {temp_col} column")
        df = ToLowerPreprocessor().preprocess(df, input_col=input_col, output_col=temp_col)
        logger.info(f"Finished Lowercase Business Name Field on {temp_col} column")
        return df

    def _remove_common_terms(self, df: DataFrame, output_col: str) -> DataFrame:
        """
        Removes commonly occuring business terms from the specified columns in a DataFrame.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to remove common terms from
        
        Returns:
            DataFrame: DataFrame with the removed common terms
        """
        logger.info(f"Starting Common Business Name Term Removal")
        cleaner = CleanTextPreprocessor()

        df = cleaner.preprocess(
            df=df,
            input_col=f"{output_col}_temp_lower",
            output_col=f"{output_col}_temp_cleaned",
            regex_transformations = {
                "(?i)(^|[^a-zA-Z0-9])&($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])advisors($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])and($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])assoc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])associates($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])attorney($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])capital($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])co($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])company($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])consulting($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])corp($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])corporation($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])cpa($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])dds($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])development($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])digital($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])dr($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])doctor($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])enterprises($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])esq($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])estate($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])financial($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])foundation($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])global($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])group($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])grp($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])health($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])healthcare($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])holdings($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])housing($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])inc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])incorporated($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])industries($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])international($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])investments($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])labs($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])law($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])limited($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])llc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])llp($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])logistics($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])lp($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])ltd($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])management($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])md($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])medical($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])mgmt($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])national($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])of($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])organization($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])partners($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])partnership($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])pc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])plc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])pllc($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])properties($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])property($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])real estate($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])realty($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])service($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])services($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])solutions($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])systems($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])tech($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])technologies($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])the($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])transport($|[^a-zA-Z0-9])": "",
                "(?i)(^|[^a-zA-Z0-9])ventures($|[^a-zA-Z0-9])": ""
            }
        )

        logger.info(f"Finished Business Name Common Terms Removal")
        return df

    def _clean_business_name_fields(self, df: DataFrame, output_col: str, is_list: bool = False, delimiter: str = ',') -> DataFrame:
        """
        Cleans the specified columns in a DataFrame by removing specified pattern.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to clean
            is_list (bool, optional): Whether the column is a list. Defaults to False.
            delimiter (str, optional): Delimiter to use for splitting lists. Defaults to ','.
        
        Returns:
            DataFrame: DataFrame with the cleaned columns
        """
        # Determine pattern based on whether it's a list or not
        if is_list:
            pattern = f"[^a-zA-Z0-9{delimiter}]+"  # Preserve commas and spaces for lists
            logger.info(f"Starting Business Name Field Cleaning [removing {pattern}, preserving {delimiter}]")
        else:
            pattern = "[^a-zA-Z0-9]+"   # Remove all non-alphanumeric
            logger.info(f"Starting Business Name Field Cleaning [removing {pattern}]")

        df = CleanTextPreprocessor().preprocess(
                df=df,
                input_col=f"{output_col}_temp_cleaned",
                output_col=f"{output_col}_temp_cleaned",
                regex_transformations={pattern: ''},
            )
        logger.info(f"Finished Business Name Field Cleaning [removed {pattern}]")
        return df

    def _split_business_name_lists(self, df: DataFrame, output_col: str, delimiter: str = ',') -> DataFrame:
        """
        Splits the specified columns in a DataFrame by commas.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to split
            delimiter (str, optional): Delimiter to use for splitting lists. Defaults to ','.
        
        Returns:
            DataFrame: DataFrame with the split columns
        """
        logger.info(f"Starting Business Name List Splitting [splitting on {delimiter}]")
        df = SplitOnPreprocessor().preprocess(
                df=df,
                input_col=f"{output_col}_temp_cleaned",
                output_col=output_col,
                delimiter=delimiter
            )
        logger.info(f"Finished Business Name List Splitting [split on {delimiter}]")
        return df

    def _nullify_empty_business_name_fields(self, df: DataFrame, output_col: str, is_list: bool = False) -> DataFrame:
        """
        Nullifies empty strings in the specified columns of a DataFrame.
        For list columns, it also removes empty strings from the array.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            output_col (str): Name of the column to nullify empty strings
            is_list (bool, optional): Whether the column is a list. Defaults to False.
        
        Returns:
            DataFrame: DataFrame with nullified empty strings
        """
        if is_list:
            # For list columns, remove empty strings from arrays and nullify empty arrays
            logger.info(f"Starting Empty Business Name Field Nullification for list column [removing empty strings from arrays]")
            df = df.withColumn(
                output_col,
                F.when(
                    F.size(F.filter(F.col(output_col), lambda x: x != "")) == 0,
                    None
                ).otherwise(
                    F.filter(F.col(output_col), lambda x: x != "")
                )
            )
            logger.info(f"Finished Empty Business Name Field Nullification for list column")
        else:
            # For string columns, nullify empty strings
            logger.info(f"Starting Empty Business Name Field Nullification [nullifying empty strings]")
            temp_col = f"{output_col}_temp_cleaned"
            df = df.withColumn(
                output_col,
                F.when(F.col(temp_col) == "", None).otherwise(F.col(temp_col))
            )
            logger.info(f"Finished Empty Business Name Field Nullification [nullified empty strings]")
        
        return df

    def preprocess(self, df: DataFrame, input_col: str, output_col: str, is_list: bool = False, delimiter: str = ',') -> DataFrame:
        """
        Preprocesses the specified column in a DataFrame by applying multiple transformations.
        
        Args:
            df (DataFrame): Input PySpark DataFrame to process
            input_col (str): Name of the column to preprocess
            output_col (str): Name of the column to store the processed values
            is_list (bool, optional): Whether the column is a list. Defaults to False.
            delimiter (str, optional): Delimiter to use for splitting lists. Defaults to ','.
        
        Returns:
            DataFrame: DataFrame with the processed column
        """
        logger.info(f"Starting Business Name Standardization on {input_col} column to make {output_col}")
        if not output_col:
            output_col = input_col

        df = self._lower_business_name_fields(df, input_col=input_col, output_col=output_col)

        df = self._remove_common_terms(df, output_col)

        df = self._clean_business_name_fields(df, output_col, is_list=is_list, delimiter=delimiter)

        if is_list:
            df = self._split_business_name_lists(df, output_col, delimiter=delimiter)

        df = self._nullify_empty_business_name_fields(df, output_col, is_list=is_list)

        # Drop temporary columns
        temp_cols = [f"{output_col}_temp_lower", f"{output_col}_temp_cleaned"]
        existing_temp_cols = [col for col in temp_cols if col in df.columns]
        if existing_temp_cols:
            df = df.drop(*existing_temp_cols)

        logger.info(f"Finished Business Name Standardization on {input_col} column to make {output_col} column")
        return df