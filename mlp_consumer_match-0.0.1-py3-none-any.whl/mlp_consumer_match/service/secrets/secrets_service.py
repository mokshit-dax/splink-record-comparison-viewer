class SecretsService:
    """
    Base class for secrets service.
    """
    def __init__(self):
        pass

    def get_secret(self, **kwargs):
        """
        Get secret from the secrets service.
        """
        raise NotImplementedError("Subclasses must implement this method")