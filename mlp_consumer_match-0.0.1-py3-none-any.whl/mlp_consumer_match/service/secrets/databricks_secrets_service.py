from pyspark.dbutils import DBUtils

from mlp_consumer_match.connection.spark_session_factory import SparkSessionFactory
from mlp_consumer_match.service.secrets.secrets_service import SecretsService
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="databricks_secrets_service")

class DatabricksSecretsService(SecretsService):
    """
    Databricks secrets service.
    """
    def __init__(self, secret_scope: str, secret_key: str):
        """
        Initializes a new instance of the DatabricksSecretsService class.

        Args:
            secret_scope (str): The scope of the secret.
            secret_key (str): The key of the secret.
        """
        super().__init__()
        self.secret_scope = secret_scope
        self.secret_key = secret_key

        self.spark = SparkSessionFactory().get_or_create_spark_session()
        self.dbutils = DBUtils(self.spark)

    @staticmethod
    def help():
        """
        Returns a help message for the DatabricksSecretsService class stating the parameters required.
        """
        return f"""DatabricksSecretsService(secret_scope, secret_key)

        \tParameters:
        \t\tsecret_scope (str): The scope of the secret in Databricks workspace.
        \t\tsecret_key (str): The key of the secret in Databricks workspace.
        """

    def get_secret(self):
        """
        Get secret from Databricks secrets service.

        Returns:
            str: The secret value.
        """
        secret = self.dbutils.secrets.get(scope=self.secret_scope, key=self.secret_key)
        logger.info(f"Databricks secret retrieved successfully")
        return secret