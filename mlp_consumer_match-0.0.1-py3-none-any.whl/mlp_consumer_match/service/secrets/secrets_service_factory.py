from mlp_consumer_match.service.secrets.databricks_secrets_service import DatabricksSecretsService

class SecretsServiceFactory:
    """
    Factory class for secrets service.
    """
    @staticmethod
    def get_secrets_service(**kwargs):
        """
        Returns the secrets service based on the provided parameters.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            SecretsService: The secrets service.
        """
        if ('secret_scope' in kwargs and kwargs['secret_scope']) and ('secret_key' in kwargs and kwargs['secret_key']):
            return DatabricksSecretsService(secret_scope=kwargs['secret_scope'], secret_key=kwargs['secret_key'])
        raise ValueError("Invalid secret service parameters\n" + SecretsServiceFactory.help())

    @staticmethod
    def help():
        """
        Returns the help message.
        """
        return f"""
        Available secret services:
            1) {DatabricksSecretsService.help()}
        """