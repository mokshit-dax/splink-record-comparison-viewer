import yaml

from mlp_consumer_match.connection.database_api import DatabaseAPI
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.convert_to_json import convert_to_json
from mlp_consumer_match.conf.config_loader import PreprocessConfig
from mlp_consumer_match.workflow_lifecycle.workflow_status import WorkflowStatus

logger = get_logger(__name__)


def main():
    """
    Initializes the workflow lifecycle.
    """
    preprocess_config: PreprocessConfig = ConfigLoader().get_or_load_config("preprocess")

    logger.info(f"Host: {preprocess_config.databricks_host_url}")
    logger.info(f"Job Run ID: {preprocess_config.job_run_id}")
    logger.info(f"Model Name: {preprocess_config.model_name}")

    # Fetch database API connection
    database_api = DatabaseAPI(preprocess_config.database_api_url)

    # Fetch workflowType from Match Config Table Record
    match_config_record = database_api.fetch(
        table_name="match_config", extension_id=preprocess_config.match_config_id
    )
    workflow_type = match_config_record.get("workflow_type")
    logger.info(
        f"Fetched workflow_type [{workflow_type}] from Match Config Table Record"
    )

    # Fetch workflow (train/inference) config
    try:
        workflow_config = ConfigLoader().get_or_load_config(workflow_type.lower())
    except ValueError as e:
        logger.error(f"Invalid workflow_type [{workflow_type}]: {e}")
        raise
    logger.info(f"Workflow Config fetched for [{workflow_type}]")

    # Create Match Run Detail Table Record with start_time, status, chartData, errorMessage
    database_api.create_match_run_detail(
        run_id=preprocess_config.job_run_id,
        match_config_id=preprocess_config.match_config_id,
        status=WorkflowStatus.RUNNING,
    )
    logger.info("Created Match Run Detail Table Record")

    # Update Match Config Table Record with configYAML, updated_at

    database_api.update_match_config(
        match_config_id=preprocess_config.match_config_id,
        workflow_type=workflow_type,
        model_version=workflow_config.get("model_version"),
        config_yaml=yaml.dump(
            convert_to_json(
                {
                    "preprocess": preprocess_config,
                    f"{workflow_type.lower()}": workflow_config,
                }
            ),
            sort_keys=False,
        ),
    )
    logger.info("Updated Match Config Table Record with configYAML, updated_at")

if __name__ == "__main__":
    main()
