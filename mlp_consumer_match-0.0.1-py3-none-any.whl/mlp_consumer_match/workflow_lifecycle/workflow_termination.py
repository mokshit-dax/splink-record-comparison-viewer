from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.workflow_lifecycle.workflow_error_collector import WorkflowErrorCollector
from mlp_consumer_match.service.secrets.secrets_service_factory import SecretsServiceFactory
from mlp_consumer_match.connection.database_api import DatabaseAPI
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import PreprocessConfig
from mlp_consumer_match.workflow_lifecycle.workflow_status import WorkflowStatus

logger = get_logger(__name__)

def main():
    """
    Main function for termination.

    This function performs the following steps:
      1. Collects failures and skips from the job run.
      2. Updates the match run detail table with end_time, status, chartData, errorMessage (if any).
      3. Updates the match config table with model_version, updated_at.
    """
    preprocess_config: PreprocessConfig = ConfigLoader().get_or_load_config("preprocess")
    params = {key: value for key, value in preprocess_config.items() if value}

    logger.info(f"Host: {preprocess_config.databricks_host_url}")
    logger.info(f"Job Run ID: {preprocess_config.job_run_id}")

    # Fetch secrets
    secrets_service = SecretsServiceFactory().get_secrets_service(**params)

    # Fetch database API connection
    database_api = DatabaseAPI(preprocess_config.database_api_url)

    # Fetch workflowType from Match Config Table Record
    match_config_record = database_api.fetch(table_name="match_config", extension_id=preprocess_config.match_config_id)
    workflow_type = match_config_record.get("workflow_type")
    logger.info(f"Fetched workflow_type [{workflow_type}] from Match Config Table Record")
    
    # Collect failures and skips throughout the job run tasks
    error_collector = WorkflowErrorCollector(preprocess_config.databricks_host_url, secrets_service.get_secret(), preprocess_config.job_run_id)
    failures, skips = error_collector.collect_failures_and_skips()
    logger.info("Collected failures and skips throughout the job run tasks")

    failed_message = ""
    for failure in failures:
        failed_message = "Following tasks have failed:\n" if not failed_message else failed_message
        failed_message += f"- {failure['task_key']}\n"
        failed_message += f"    Task Run ID: {failure['task_run_id']}\n"
        failed_message += f"    Status: {failure['status']}\n"
        failed_message += f"    Started At: {failure['started_at']}\n"
        failed_message += f"    Failed At: {failure['failed_at']}\n"
        failed_message += f"    Error Message: {failure['error']}\n"

    skipped_message = ""
    for skip in skips:
        skipped_message = "Following tasks have been skipped:\n" if not skipped_message else skipped_message
        skipped_message += f"- {skip}\n"

    error_message = failed_message + skipped_message


    if error_message:
        logger.error(f"Workflow failed with error message: \n{error_message}")

    # Update Match Run Detail Table with end_time, status, chartData, errorMessage (if any)
    match_run_detail_record = {
        "error_message": error_message,
        "status": WorkflowStatus.FAILED if error_message else WorkflowStatus.SUCCEEDED,
    }
    
    if workflow_type.lower() == "inference":
        logger.info("Inference Output:")
        prediction_path = ConfigLoader().get_prediction_path(include_salt_key_dir=True, include_salt_key_glob_pattern=False)
        buckets_path = ConfigLoader().get_bucket_path()
        clusters_path = ConfigLoader().get_cluster_base_path()
        
        logger.info(f"\nPrediction Path: {prediction_path}\nBuckets Path: {buckets_path}\nClusters Path: {clusters_path}")
        
        match_run_detail_record["output"] = {
            'prediction_path': prediction_path,
        }
        if buckets_path:
            match_run_detail_record["output"]["buckets_path"] = buckets_path
        
        if clusters_path:
            match_run_detail_record["output"]["clusters_path"] = clusters_path

    database_api.update_match_run_detail(
        run_id=preprocess_config.job_run_id,
        **match_run_detail_record,
    )
    logger.info("Updated Match Run Detail Table with end_time, status, errorMessage")



if __name__ == "__main__":
    main()