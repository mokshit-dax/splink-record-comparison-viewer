import requests
from datetime import datetime, timezone
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(__name__)

class WorkflowErrorCollector:
    """
    Workflow Error Collector class for collecting failures and skips from the job run,
    including errors from triggered jobs, except for the task specified in skip_task.
    """
    def __init__(self, host: str, token: str, job_run_id: str, skip_tasks: list[str] = ["termination_task"]):
        """
        Initializes a new instance of the WorkflowErrorCollector class.

        Args:
            host (str): The host URL of the Databricks workspace.
            token (str): The Databricks API token.
            job_run_id (str): The ID of the job run.
            skip_tasks (list[str], optional): The tasks to skip when collecting errors. Defaults to ["termination_task"].
        """
        self.failures = []
        self.skips = []
        self.host = host
        self.token = token
        self._seen = set()
        self.skip_tasks = skip_tasks
        self.job_run_id = job_run_id

    def _record_failure(self, task_key: str, task_run_id: str, status: str, started_ms: int, ended_ms: int, error: str):
        """
        Record a failure if we haven't already.

        Args:
            task_key (str): The task key.
            task_run_id (str): The task run ID.
            status (str): The status of the task.
            started_ms (int): The start time of the task in milliseconds since the epoch.
            ended_ms (int): The end time of the task in milliseconds since the epoch.
            error (str): The error message.

        Returns:
            None
        """
        key = (task_key, task_run_id)
        if key in self._seen:
            return
        self._seen.add(key)
        self.failures.append({
            "task_key": task_key,
            "task_run_id": task_run_id,
            "status": status,
            "started_at": self._to_iso(started_ms),
            "failed_at": self._to_iso(ended_ms),
            "error": error
        })

    def _to_iso(self, ms: int) -> str | None:
        """
        Convert ms since epoch → ISO8601 UTC or None.

        Args:
            ms (int): The number of milliseconds since the epoch.

        Returns:
            str: The ISO8601 UTC timestamp or None.
        """
        try:
            return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat()
        except:
            return None

    def fetch_job_run_tasks(self, run_id: str = None) -> list:
        """
        Fetch job run metadata including per-task entries.

        Args:
            run_id (str, optional): The ID of the job run. Defaults to None.

        Returns:
            list: List of tasks in the parent run.
        """
        run_id = self.job_run_id if not run_id else run_id
        resp = requests.get(
            f"{self.host}/api/2.2/jobs/runs/get?run_id={run_id}",
            headers={"Authorization": f"Bearer {self.token}"}
        )
        resp.raise_for_status()
        payload = resp.json()

        run_block = payload.get("run", payload)
        tasks_list = run_block.get("tasks", payload.get("tasks", []))
        return tasks_list


    def fetch_error(self, task_run_id: str) -> str | None:
        """
        Fetch the exact exception text from the notebook run-output endpoint.

        Args:
            task_run_id (str): The ID of the task run.

        Returns:
            str: The exact exception text from the notebook run-output endpoint.
        """
        resp = requests.get(
            f"{self.host}/api/2.2/jobs/runs/get-output",
            params={"run_id": task_run_id},
            headers={"Authorization": f"Bearer {self.token}"}
        )
        resp.raise_for_status()
        return resp.json().get("error")


    def collect_failures_and_skips_from_task(self, task: dict):
        """
        Collect failures and skips from the task.

        Args:
            task (dict): The task to collect failures and skips from.

        Returns:
            bool: True if the task was kept, False otherwise.
        """
        key = task.get("task_key")
        if key in self.skip_tasks:
            return False

        st = task.get("state", {})
        rs = st.get("result_state")
        task_run_id = task.get("run_id")

        if rs == "UPSTREAM_FAILED":
            self.skips.append(key)
            return False

        if rs != "SUCCESS":
            err = self.fetch_error(task_run_id)
            if err is not None:
                self.failures.append({
                    "task_key": key,
                    "task_run_id": task_run_id,
                    "status": rs,
                    "started_at": self._to_iso(task['start_time']),
                    "failed_at": self._to_iso(task['end_time']),
                    "error": err
                })
            
        return True


    def get_job_id_from_triggered_job_runs(self, task):
        """
        Fetches the job ID from the triggered job runs.

        Args:
            task (dict): The task to fetch the job ID from.

        Returns:
            int: The job ID.
        """
        return task.get("for_each_task", {}).get("task", {}).get("run_job_task", {}).get("job_id", None)


    def fetch_job_runs_by_parent_job_run_id(self, job_id: int, parent_job_run_id: int) -> list[dict]:
      """
      Fetches all runs for a specified Databricks job ID and filters them based on the provided parent_job_run_id in the job parameters.

      Args:
          job_id (int): The ID of the job to retrieve runs for.
          parent_job_run_id (int): The ID of the parent job run.

      Returns:
          list[dict]: A list of job runs that match the specified parent_job_run_id.
      """
      headers = {
          "Authorization": f"Bearer {self.token}"
      }
      runs = []
      params = {
          "job_id": job_id,
          "limit": 25  # Adjust the limit as needed (maximum is 100)
      }
      next_page_token = None

      while True:
          if next_page_token:
              params["page_token"] = next_page_token

          response = requests.get(
              f"{self.host}/api/2.2/jobs/runs/list",
              headers=headers,
              params=params
          )
          response.raise_for_status()
          payload = response.json()
          all_runs = payload.get("runs", [])

          for run in all_runs:
              run_params = run.get("job_parameters", [])
              job_run_id_value = None
              for param in run_params:
                  if param.get("name") == "job_run_id":
                      job_run_id_value = param.get("value")
                      break
              if job_run_id_value == str(parent_job_run_id):
                  runs.append(run)

          next_page_token = payload.get("next_page_token")
          if not next_page_token:
              break
      return runs


    def collect_failures_and_skips(self) -> tuple[list, list]:
        """
        Collect failures and skips from the job run.

        Returns:
            tuple: A tuple containing the list of failures and the list of skips.

        Failures:
            list: List of failures.
            attributes of each failure:
                task_key (str): The task key.
                status (str): The status of the task.
                started_at (str): The start time of the task.
                failed_at (str): The end time of the task.
                error (str): The error message.

        Skips:
            list: List of skips.
            attributes of each skip:
                task_key (str): The task key.
        """
        try:
            logger.info("Starting error collection")
            parent_tasks = self.fetch_job_run_tasks()

            for t in parent_tasks:
                # first collect failures/skips in the parent
                if not self.collect_failures_and_skips_from_task(t):
                    continue

                # then dive into any triggered child runs
                triggered_job_id = self.get_job_id_from_triggered_job_runs(t)
                if not triggered_job_id:
                    continue

                triggered_runs = self.fetch_job_runs_by_parent_job_run_id(triggered_job_id, self.job_run_id)
                for run in triggered_runs:
                    run_id = run["run_id"]
                    logger.info(f"Processing run with run_id: {run_id}")
                    for child_task in self.fetch_job_run_tasks(run_id):
                        kept = self.collect_failures_and_skips_from_task(child_task)
                        if not kept:
                            continue

            logger.info("Error collection completed")
            return self.failures, self.skips

        except Exception as e:
            logger.error(f"Failed to collect failures and skips: {e}")
            return [], []