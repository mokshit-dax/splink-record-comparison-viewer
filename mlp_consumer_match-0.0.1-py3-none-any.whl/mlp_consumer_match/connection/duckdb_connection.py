import duckdb
from mlp_consumer_match.utils.logging.base_logger import get_logger

logger = get_logger(name="duckdb_connection")


class DuckDBConnection:
    """
    Singleton class that manages a DuckDB connection. Ensures only one connection
    is created and reused across the application.

    Attributes:
        _instance (DuckDBConnection): The singleton instance of the DuckDBConnection class.
        _db_path (str): The path to the DuckDB database.
        connection (duckdb.DuckDBPyConnection): The DuckDB connection object.
    """

    _instance = None
    _db_path = None

    def __new__(cls, db_path = None):
        """
        Create a new connection if one doesn't already exist, or return the existing one.

        Args:
            db_path (str, optional): The path to the DuckDB database.

        Raises:
            ValueError: If db_path is not provided when creating the first instance.
        """
        if cls._instance is None:
            if db_path is None:
                logger.error("db_path must be provided for the first instance")
                raise
                # raise ValueError("db_path must be provided for the first instance")
            
            logger.info("Setting up new duckdb connection")
            cls._instance = super(DuckDBConnection, cls).__new__(cls)
            cls._db_path = db_path
            cls._instance.connection = duckdb.connect(db_path)

        return cls._instance


    def get_connection(self):
        """
        Returns the current DuckDB connection.

        Returns:
            duckdb.DuckDBPyConnection: The DuckDB connection object.
        """
        logger.info("Returning existing duckdb connection")
        return self.connection

    def close(self):
        """
        Closes the DuckDB connection.
        """
        logger.info("Closing duckdb connection")
        self.connection.close()