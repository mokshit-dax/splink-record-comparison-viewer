from pyspark.sql import SparkSession

class SparkSessionFactory:
    _spark_session = None  # Class-level attribute to hold the Spark session

    def __new__(cls, spark_session=None):
        """
        Overrides the __new__ method to implement the singleton pattern for Spark sessions.

        Parameters:
            spark_session (pyspark.sql.SparkSession, optional): An existing SparkSession instance.
                If provided, it will be stored as the singleton instance. Otherwise, if no session
                exists yet, a new SparkSession will be created.

        Returns:
            SparkSessionFactory: An instance of SparkSessionFactory with the singleton SparkSession set.
        """
        instance = super().__new__(cls)
        if spark_session is not None:
            cls._spark_session = spark_session
        elif cls._spark_session is None:
            cls._spark_session = SparkSession.builder.getOrCreate()
        return instance

    def get_or_create_spark_session(self):
        """
        Getter method to return the stored Spark session.
        """
        return self._spark_session

