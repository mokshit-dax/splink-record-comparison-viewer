import json

from mlp_consumer_match.inference.inference_pipeline import InferencePipeline
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.utils.metrics.inference_metrics import InferenceMetrics
from mlp_consumer_match.connection.database_api import DatabaseAPI

logger = get_logger(__name__)

def main():
    """
    Executes the inference pipeline for a matchai model.

    This function performs the following steps:
      1. Retrieves Spark connection and job metadata.
      2. Loads preprocessed data file paths from the specified save path.
      3. Initializes InferencePipeline with the provided configuration, file paths, file path prefix, model name, and job metadata.
      4. Runs predict on the model and saves the results to prediction path.
    
    Returns:
        int: Returns 1 upon successful completion of the inference job.
    """
    # Load config
    cfg = ConfigLoader().get_or_load_config("inference")

    # Initialize metrics tracker
    metrics = InferenceMetrics(job_run_id=cfg.job_run_id, event_type="Inference")
    metrics.add_metric("model_name", cfg.model_name)

    logger.info(f"Inference started at: {metrics.start_time}")

    # Fetch model_name and job_run_id from dbutils
    logger.info("Loading Job parameters")
    logger.info(f"Model_name={cfg.model_name}")
    logger.info(f"Job_run_id={cfg.job_run_id}")
    logger.info(f"Date_partition={cfg.date_partition}")

    # Fetch Database API connection
    database_api = DatabaseAPI(cfg.database_api_url)

    # Create Match Run Event Record in Database
    database_api.create_match_run_event(
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        event_type="Inference",
    )
    logger.info("Created Match Run Event Table Record for Inference")
    
    # Initialize InferencePipeline
    inference_pipeline = InferencePipeline(
        cfg, 
        metrics=metrics
    )

    # Run predict on the model and save results
    logger.info("Starting model inference")
    result = inference_pipeline.predict()
    assert "failed" not in str(result).lower()
    
    # End time
    metrics.track_total_execution_time_in_seconds()
    
    # Add metrics
    metrics.log_metrics_summary()
    logger.info(f"Inference completed at: {metrics.end_time}")
    logger.info(f"Total inference time: {metrics.metrics.get('total_execution_in_seconds', None)}")

    database_api.update_match_run_event(
        remove_end_slash=True,
        run_id=cfg.job_run_id,
        task_id=cfg.task_run_id,
        metrics=json.dumps(metrics.get_metrics_summary()),
    )
    logger.info("Updated Match Run Event Table Record for Inference")
    
    logger.info("Inference Job Completed Successfully")

if __name__ == "__main__":
    main()
