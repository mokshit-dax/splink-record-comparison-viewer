import mlflow
import json
import time

from mlp_consumer_match.conf.inference_config import InferenceConfig
from mlp_consumer_match.inference.inference import Inference
from mlp_consumer_match.utils.file_system.file_system_factory import FileSystemFactory
from mlp_consumer_match.utils.logging.base_logger import get_logger
from mlp_consumer_match.conf.config_loader import ConfigLoader
from mlp_consumer_match.train.mlflow.loaders.mlflow_model_loader_factory import MLflowModelLoaderFactory

logger = get_logger(name="inference_pipeline")


class InferencePipeline(Inference):
    """
    A pipeline for running inference.

    This class implements the inference pipeline for consumer matching, handling data loading,
    model loading, preprocessing, model prediction, and result storage.

    Attributes:
        config (InferenceConfig): Configuration settings for the inference pipeline
    """

    def __init__(self, cfg: InferenceConfig, metrics=None):
        """
        Initializes a new instance of the InferencePipeline class. 

        Args:
            cfg (InferenceConfig): Configuration containing model inference parameters.
            metrics: Metrics tracking object for monitoring pipeline performance.
        """
        logger.info("Initializing InferencePipeline")
        self.cfg = cfg
        self.metrics = metrics

        self.linker = None

        # Get File System
        self.fs = FileSystemFactory().create_file_system_from_path_prefix(self.cfg.save_path)
        self.files = self.fs.ls(f"{ConfigLoader().get_preprocess_path()}/")
        logger.info(f"File paths: {self.files}")

        # Model Details
        self.mlflow_model_save_path = ConfigLoader().get_mlflow_model_save_path(self.cfg.model_name, workflow_type="inference")
        logger.info(f"Model save path: {self.mlflow_model_save_path}")

        # MLflow Details
        mlflow.set_tracking_uri(self.cfg.mlflow_tracking_uri)
        logger.info(f"MLflow tracking uri: {self.cfg.mlflow_tracking_uri}")

        mlflow.set_registry_uri(self.cfg.mlflow_registry_uri)
        logger.info(f"MLflow registry uri: {self.cfg.mlflow_registry_uri}")


        # Include salt key in prediction path
        self.prediction_path = ConfigLoader().get_salt_key_prediction_path(include_partition=True)

        logger.info(f"Prediction path: {self.prediction_path}")

        if self.cfg.pre_inference_filters:
            self.pre_inference_filters = {filter.get('filter').get('name'): " WHERE " + filter.get('filter').get('where') for filter in self.cfg.pre_inference_filters}
        else:
            self.pre_inference_filters = {}
        logger.info(f"Pre-inference filters: {self.pre_inference_filters}")

        logger.info(f"Partition: {self.cfg.partition}")

        # Load Model
        self.model = (
            MLflowModelLoaderFactory().create_mlflow_model_loader_from_registry_uri(
                registry_uri=self.cfg.mlflow_registry_uri,
                model_name=self.cfg.model_name,
                model_version_tag=self.cfg.model_version,
            )
        )
        
        self._load_model()


    def predict(self):
        """
        Generate predictions for input data using the trained linker model.

        Returns:
            list: A list with the status of the prediction process.
        """
        params = {
            "partition": str(self.cfg.partition),
            "prediction_path": self.prediction_path,
            "salt_key": str(self.cfg.salt_key)
        }

        file_objects = []
        for file in self.files:
            file_objects.append(
                json.dumps({
                    'name': file.name,
                    'path': file.path,
                    'pre_inference_filter': self.pre_inference_filters.get(file.name, '')
                })
            )
        
        return self.linker.predict(data=file_objects, params=params)[0] # noqa
        
    def _load_model(self):
        """
        Load the trained linker model from MLflow.
        """
        logger.info("Loading model from MLflow")
        start_time = time.time()
        
        self.linker = self.model.load_model()
        
        end_time = time.time()
        load_time = end_time - start_time
        
        if self.metrics:
            self.metrics.track_model_load(
                model_name=self.cfg.model_name,
                model_version=self.model._get_model_version_from_tag(tag_key="model_version"),
                load_time_seconds=load_time
            )
            
        logger.info("Model loaded")
